//! A bounded source-boundary experiment in scoped symbolic disequality.
//!
//! Every query gets a fresh graph: its opaque word leaves carry one private
//! scope, corresponding to the exact parent Assumption recorded in the receipt.
//! Mask is ordinary congruence, never injective. Each fixed wrapping translation
//! gets a separate unary injective constructor. A false Eq imports only a parent
//! disequality. Only a proved disequality of the exact target operands exports a
//! false Boolean Eq at the source initialization boundary. No local assumptions
//! or word equalities enter EggCC's main graph.

use std::{
    collections::BTreeSet,
    path::Path,
    sync::atomic::{AtomicUsize, Ordering},
};

use egglog::{new_experimental_egraph_with_options, DisequalityEncoding, Error};
use serde_json::json;

use crate::schema::{Assumption, BaseType, BinaryOp, Constant, Expr, RcExpr, TreeProgram, Type};

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum Word {
    Slot(usize),
    Constant(i64),
    Mask(Box<Word>, Box<Word>),
    Shift(i64, Box<Word>),
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum Transport {
    Slot(usize),
    Unknown,
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum Shape {
    Scalar(Transport),
    Tuple(Vec<Transport>),
}

struct Invariant {
    scope: Assumption,
    index: usize,
    value: i64,
}

/// Expand exact tuple projections and If input bindings. A slot survives an If
/// only when BOTH branches forward that same lexical input slot. Arithmetic is
/// deliberately unknown: even `slot + 0` is outside this structural proof.
fn transport(expr: &RcExpr, scope: &Assumption, input: &[Transport]) -> Option<Shape> {
    match expr.as_ref() {
        Expr::Arg(Type::TupleT(fields), ctx) if ctx == scope && fields.len() == input.len() => {
            Some(Shape::Tuple(input.to_vec()))
        }
        Expr::Get(tuple, index) => {
            let Shape::Tuple(values) = transport(tuple, scope, input)? else {
                return None;
            };
            Some(Shape::Scalar(values.get(*index)?.clone()))
        }
        Expr::Single(value) => {
            let Shape::Scalar(value) = transport(value, scope, input)? else {
                return None;
            };
            Some(Shape::Tuple(vec![value]))
        }
        Expr::Concat(left, right) => {
            let Shape::Tuple(mut values) = transport(left, scope, input)? else {
                return None;
            };
            let Shape::Tuple(right) = transport(right, scope, input)? else {
                return None;
            };
            values.extend(right);
            Some(Shape::Tuple(values))
        }
        Expr::Empty(_, ctx) if ctx == scope => Some(Shape::Tuple(Vec::new())),
        Expr::Const(_, _, ctx) if ctx == scope => Some(Shape::Scalar(Transport::Unknown)),
        Expr::Bop(..) | Expr::Uop(..) | Expr::Top(..) => Some(Shape::Scalar(Transport::Unknown)),
        Expr::If(pred, branch_input, yes, no) => {
            if pred.get_ctx() != scope || branch_input.get_ctx() != scope {
                return None;
            }
            let Shape::Tuple(values) = transport(branch_input, scope, input)? else {
                return None;
            };
            let yes_ctx = Assumption::InIf(true, pred.clone(), branch_input.clone());
            let no_ctx = Assumption::InIf(false, pred.clone(), branch_input.clone());
            match (
                transport(yes, &yes_ctx, &values)?,
                transport(no, &no_ctx, &values)?,
            ) {
                (Shape::Tuple(a), Shape::Tuple(b)) if a.len() == b.len() => Some(Shape::Tuple(
                    a.into_iter()
                        .zip(b)
                        .map(|(x, y)| if x == y { x } else { Transport::Unknown })
                        .collect(),
                )),
                (Shape::Scalar(a), Shape::Scalar(b)) => {
                    Some(Shape::Scalar(if a == b { a } else { Transport::Unknown }))
                }
                _ => None,
            }
        }
        _ => None,
    }
}

/// Induction admitted only for a literal initial projection and unchanged
/// same-index body output. DoWhile body output 0 is its predicate, so slot i is
/// carried by body output i+1. Other-index forwarding and updates are rejected.
fn loop_invariants(program: &TreeProgram) -> Vec<Invariant> {
    let mut stack = vec![program.entry.clone()];
    stack.extend(program.functions.clone());
    let mut seen = BTreeSet::new();
    let mut result = Vec::new();
    while let Some(expr) = stack.pop() {
        if !seen.insert(std::rc::Rc::as_ptr(&expr)) {
            continue;
        }
        stack.extend(expr.children_exprs());
        let Expr::DoWhile(initial, body) = expr.as_ref() else {
            continue;
        };
        let Type::TupleT(fields) = body.get_arg_type() else {
            continue;
        };
        let scope = body.get_ctx();
        let slots = (0..fields.len()).map(Transport::Slot).collect::<Vec<_>>();
        let Some(Shape::Tuple(outputs)) = transport(body, scope, &slots) else {
            continue;
        };
        if outputs.len() != fields.len() + 1 {
            continue;
        }
        for (index, ty) in fields.iter().enumerate() {
            if ty != &BaseType::IntT || outputs[index + 1] != Transport::Slot(index) {
                continue;
            }
            let Some(value) = project(initial, index) else {
                continue;
            };
            let Expr::Const(Constant::Int(value), _, ctx) = value.as_ref() else {
                continue;
            };
            if ctx != initial.get_ctx() {
                continue;
            }
            result.push(Invariant {
                scope: scope.clone(),
                index,
                value: *value,
            });
        }
    }
    result
}

/// Transport a proved loop constant through exact enclosing If inputs.
fn constant_slot(scope: &Assumption, index: usize, invariants: &[Invariant]) -> Option<i64> {
    if let Some(value) = invariants
        .iter()
        .find(|x| x.scope == *scope && x.index == index)
    {
        return Some(value.value);
    }
    let Assumption::InIf(_, _, input) = scope else {
        return None;
    };
    let value = project(input, index)?;
    match value.as_ref() {
        Expr::Const(Constant::Int(k), _, ctx) if ctx == input.get_ctx() => Some(*k),
        Expr::Get(arg, i) => {
            let Expr::Arg(Type::TupleT(fields), ctx) = arg.as_ref() else {
                return None;
            };
            if fields.get(*i) != Some(&BaseType::IntT) || ctx != input.get_ctx() {
                return None;
            }
            constant_slot(ctx, *i, invariants)
        }
        _ => None,
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Mode {
    Off,
    SeedOnly,
    AnnotationOff,
    QueryOff,
    Manual,
    Encoding,
    BridgeOff,
}

impl Mode {
    fn from_env() -> Self {
        match std::env::var("EGGCC_SCOPED_MODE")
            .as_deref()
            .unwrap_or("off")
        {
            "off" => Self::Off,
            "seed-only" => Self::SeedOnly,
            "annotation-off" => Self::AnnotationOff,
            "query-off" => Self::QueryOff,
            "manual" => Self::Manual,
            "encoding" => Self::Encoding,
            "bridge-off" => Self::BridgeOff,
            other => panic!("Unknown EGGCC_SCOPED_MODE: {other}"),
        }
    }
}

fn tuple_length(expr: &RcExpr) -> Option<usize> {
    match expr.as_ref() {
        Expr::Single(_) => Some(1),
        Expr::Concat(a, b) => Some(tuple_length(a)? + tuple_length(b)?),
        Expr::Empty(_, _) => Some(0),
        Expr::Arg(Type::TupleT(fields), _) => Some(fields.len()),
        _ => None,
    }
}

/// Exact structural projection through the branch's declared input tuple.
/// Unsupported expressions remain unknown; they are never treated as fresh values.
fn project(expr: &RcExpr, index: usize) -> Option<RcExpr> {
    match expr.as_ref() {
        Expr::Single(value) if index == 0 => Some(value.clone()),
        Expr::Concat(left, right) => {
            let length = tuple_length(left)?;
            if index < length {
                project(left, index)
            } else {
                project(right, index - length)
            }
        }
        Expr::Arg(Type::TupleT(fields), _) if index < fields.len() => {
            Some(RcExpr::new(Expr::Get(expr.clone(), index)))
        }
        _ => None,
    }
}

/// Translate only total pure integer expressions in one exact lexical scope.
/// A child Get is interpreted through its actual If input, never by matching
/// tuple position across unrelated scopes.
fn translate(
    expr: &RcExpr,
    scope: &Assumption,
    child: Option<(&Assumption, &RcExpr)>,
    invariants: &[Invariant],
) -> Option<Word> {
    match expr.as_ref() {
        Expr::Const(Constant::Int(value), _, ctx)
            if ctx == scope || child.is_some_and(|(c, _)| c == ctx) =>
        {
            Some(Word::Constant(*value))
        }
        Expr::Arg(Type::Base(BaseType::IntT), ctx) if ctx == scope && child.is_none() => {
            Some(Word::Slot(0))
        }
        Expr::Get(arg, index) => {
            let Expr::Arg(Type::TupleT(fields), ctx) = arg.as_ref() else {
                return None;
            };
            if fields.get(*index) != Some(&BaseType::IntT) {
                return None;
            }
            if let Some((child_ctx, input)) = child {
                if ctx != child_ctx {
                    return None;
                }
                translate(&project(input, *index)?, scope, None, invariants)
            } else if ctx == scope {
                Some(
                    constant_slot(ctx, *index, invariants)
                        .map(Word::Constant)
                        .unwrap_or(Word::Slot(*index)),
                )
            } else {
                None
            }
        }
        Expr::Bop(BinaryOp::Bitand, a, b) => Some(Word::Mask(
            Box::new(translate(a, scope, child, invariants)?),
            Box::new(translate(b, scope, child, invariants)?),
        )),
        Expr::Bop(BinaryOp::Add, a, b) => {
            let x = translate(a, scope, child, invariants)?;
            let y = translate(b, scope, child, invariants)?;
            match (x, y) {
                (Word::Constant(k), v) | (v, Word::Constant(k)) => {
                    Some(Word::Shift(k, Box::new(v)))
                }
                _ => None,
            }
        }
        _ => None,
    }
}

fn collect(word: &Word, terms: &mut BTreeSet<Word>) {
    if !terms.insert(word.clone()) {
        return;
    }
    match word {
        Word::Mask(a, b) => {
            collect(a, terms);
            collect(b, terms);
        }
        Word::Shift(_, a) => collect(a, terms),
        _ => {}
    }
}

fn render(word: &Word, leaves: &[Word], shifts: &[i64]) -> String {
    match word {
        Word::Slot(_) | Word::Constant(_) => format!(
            "(Leaf{} (ThisScope))",
            leaves.iter().position(|x| x == word).unwrap()
        ),
        Word::Mask(a, b) => format!(
            "(Mask {} {})",
            render(a, leaves, shifts),
            render(b, leaves, shifts)
        ),
        Word::Shift(k, a) => format!(
            "(Shift{} {})",
            shifts.iter().position(|x| x == k).unwrap(),
            render(a, leaves, shifts)
        ),
    }
}

/// A fair explicit finite closure over precisely the committed symbolic terms.
/// It implements both generic reverse congruence and marked unary forward steps.
fn manual(terms: &[Word], seed: (&Word, &Word)) -> BTreeSet<(Word, Word)> {
    let mut known = BTreeSet::from([
        (seed.0.clone(), seed.1.clone()),
        (seed.1.clone(), seed.0.clone()),
    ]);
    loop {
        let before = known.len();
        for a in terms {
            for b in terms {
                if known.contains(&(a.clone(), b.clone())) {
                    match (a, b) {
                        (Word::Mask(x, m), Word::Mask(y, n)) if m == n => {
                            known.insert((x.as_ref().clone(), y.as_ref().clone()));
                        }
                        (Word::Mask(x, m), Word::Mask(y, n)) if x == y => {
                            known.insert((m.as_ref().clone(), n.as_ref().clone()));
                        }
                        (Word::Shift(k, x), Word::Shift(l, y)) if k == l => {
                            known.insert((x.as_ref().clone(), y.as_ref().clone()));
                        }
                        _ => {}
                    }
                }
                if let (Word::Shift(k, x), Word::Shift(l, y)) = (a, b) {
                    if k == l && known.contains(&(x.as_ref().clone(), y.as_ref().clone())) {
                        known.insert((a.clone(), b.clone()));
                    }
                }
            }
        }
        if known.len() == before {
            return known;
        }
    }
}

/// Successful queries publish a unit relation. An absent relation means
/// unknown-or-error; parser/runtime errors propagate and prohibit export.
fn query(graph: &mut egglog::EGraph, name: &str, a: &str, b: &str) -> Result<bool, Error> {
    graph.parse_and_run_program(
        None,
        &format!(
            "(relation {name} ())\n(ruleset {name}-query)\n\
         (rule ((known-disequal? {a} {b})) (({name})) :ruleset {name}-query :naive)\n\
         (run-schedule (run {name}-query))"
        ),
    )?;
    Ok(graph.get_size(name) > 0)
}

fn prove(
    parent: (&Word, &Word),
    target: (&Word, &Word),
    mode: Mode,
) -> Result<(bool, serde_json::Value), Error> {
    let mut terms = BTreeSet::new();
    for word in [parent.0, parent.1, target.0, target.1] {
        collect(word, &mut terms);
    }
    let terms = terms.into_iter().collect::<Vec<_>>();
    let leaves = terms
        .iter()
        .filter(|x| matches!(x, Word::Slot(_) | Word::Constant(_)))
        .cloned()
        .collect::<Vec<_>>();
    let shifts = terms
        .iter()
        .filter_map(|x| {
            if let Word::Shift(k, _) = x {
                Some(*k)
            } else {
                None
            }
        })
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();
    let mut program =
        "(datatype Scope (ThisScope))\n(datatype Word)\n(constructor Mask (Word Word) Word)\n"
            .to_owned();
    for i in 0..leaves.len() {
        program.push_str(&format!("(constructor Leaf{i} (Scope) Word)\n"));
    }
    for i in 0..shifts.len() {
        program.push_str(&format!(
            "(constructor Shift{i} (Word) Word {})\n",
            if mode == Mode::AnnotationOff {
                ""
            } else {
                ":injective"
            }
        ));
    }
    for word in &terms {
        program.push_str(&format!("{}\n", render(word, &leaves, &shifts)));
    }
    let pa = render(parent.0, &leaves, &shifts);
    let pb = render(parent.1, &leaves, &shifts);
    let ta = render(target.0, &leaves, &shifts);
    let tb = render(target.1, &leaves, &shifts);
    program.push_str(&format!(
        "(disequal {pa} {pb})\n(run-schedule (saturate injectivity))\n"
    ));
    let mut graph = new_experimental_egraph_with_options(false, DisequalityEncoding::Nee);
    graph.parse_and_run_program(None, &program)?;
    let bottom = match graph.parse_and_run_program(None, "(check-contradiction)") {
        Ok(_) => true,
        Err(Error::CheckError(..)) => false,
        Err(error) => return Err(error),
    };
    let (mut parent_known, mut child_known, mut target_known) = (None, None, None);
    if !bottom && mode != Mode::SeedOnly {
        if mode == Mode::Manual {
            let known = manual(&terms, parent);
            parent_known = Some(known.contains(&(parent.0.clone(), parent.1.clone())));
            if let (Word::Mask(x, _), Word::Mask(y, _)) = parent {
                child_known = Some(known.contains(&(x.as_ref().clone(), y.as_ref().clone())));
            }
            target_known = Some(known.contains(&(target.0.clone(), target.1.clone())));
        } else {
            parent_known = Some(query(&mut graph, "ParentKnown", &pa, &pb)?);
            if let (Word::Mask(x, _), Word::Mask(y, _)) = parent {
                child_known = Some(query(
                    &mut graph,
                    "ChildKnown",
                    &render(x, &leaves, &shifts),
                    &render(y, &leaves, &shifts),
                )?);
            }
            if mode != Mode::QueryOff {
                target_known = Some(query(&mut graph, "TargetKnown", &ta, &tb)?);
            }
        }
    }
    let export = !bottom && target_known == Some(true) && mode != Mode::BridgeOff;
    Ok((
        export,
        json!({"mode":format!("{mode:?}"),"encoding":"NEE","program":program,
        "scope":"fresh graph's ThisScope denotes exactly receipt parent_context", "leaves":format!("{leaves:?}"),
        "shift_constants":shifts,"parent": [pa,pb],"target":[ta,tb],"bottom":bottom,
        "parent_known":parent_known,"child_known":child_known,"target_known":target_known,
        "absent_witness":"unknown-or-error","export":export}),
    ))
}

/// Analyze exact source If predicates before main-egraph insertion. Existing
/// source sharing is visited once, and no contextual expressions are rewritten.
pub(crate) fn analyze(program: &TreeProgram) -> Vec<RcExpr> {
    let mode = Mode::from_env();
    if mode == Mode::Off {
        return Vec::new();
    }
    static BOUNDARY: AtomicUsize = AtomicUsize::new(0);
    let boundary = BOUNDARY.fetch_add(1, Ordering::Relaxed);
    let mut attempted = 0;
    let types = program.typecheck();
    let invariants = loop_invariants(program);
    let mut stack = vec![program.entry.clone()];
    stack.extend(program.functions.clone());
    let mut seen = BTreeSet::new();
    let mut exports = Vec::new();
    while let Some(expr) = stack.pop() {
        if !seen.insert(std::rc::Rc::as_ptr(&expr)) {
            continue;
        }
        stack.extend(expr.children_exprs());
        let Expr::If(target, _, _, _) = expr.as_ref() else {
            continue;
        };
        let Expr::Bop(BinaryOp::Eq, a, b) = target.as_ref() else {
            continue;
        };
        if types.get(&std::rc::Rc::as_ptr(target)) != Some(&Type::Base(BaseType::BoolT)) {
            continue;
        }
        let child_ctx = target.get_ctx();
        let Assumption::InIf(false, parent, input) = child_ctx else {
            continue;
        };
        let Expr::Bop(BinaryOp::Eq, pa, pb) = parent.as_ref() else {
            continue;
        };
        let scope = parent.get_ctx();
        let Some(pa) = translate(pa, scope, None, &invariants) else {
            continue;
        };
        let Some(pb) = translate(pb, scope, None, &invariants) else {
            continue;
        };
        if !matches!((&pa, &pb), (Word::Mask(..), Word::Mask(..))) {
            continue;
        }
        let Some(ta) = translate(a, scope, Some((child_ctx, input)), &invariants) else {
            continue;
        };
        let Some(tb) = translate(b, scope, Some((child_ctx, input)), &invariants) else {
            continue;
        };
        if !matches!((&ta, &tb), (Word::Shift(..), Word::Shift(..))) {
            continue;
        }
        let result = prove((&pa, &pb), (&ta, &tb), mode);
        attempted += 1;
        let (export, mut receipt) = match result {
            Ok(value) => value,
            Err(error) => (
                false,
                json!({"mode":format!("{mode:?}"),"analysis_error":format!("{error:?}"),"export":false}),
            ),
        };
        receipt["parent_context"] = json!(scope.to_string());
        receipt["child_context"] = json!(child_ctx.to_string());
        receipt["source_parent"] = json!(parent.to_string());
        receipt["branch_input"] = json!(input.to_string());
        receipt["source_target"] = json!(target.to_string());
        receipt["boundary"] =
            json!("contextualized source initialization before main-graph facts or saturation");
        receipt["source_boundary_invocation"] = json!(boundary);
        receipt["loop_invariants"] = json!(invariants.iter().map(|x|json!({
            "scope":x.scope.to_string(),"input_slot":x.index,"body_output_slot":x.index+1,
            "literal_initial_value":x.value,"proof":"exact input literal; both-branch structural same-index passthrough"
        })).collect::<Vec<_>>());
        if let Ok(directory) = std::env::var("EGGCC_SCOPED_EVIDENCE") {
            static NEXT: AtomicUsize = AtomicUsize::new(0);
            std::fs::create_dir_all(&directory).unwrap();
            let path = Path::new(&directory).join(format!(
                "query-{:04}.json",
                NEXT.fetch_add(1, Ordering::Relaxed)
            ));
            assert!(!path.exists(), "refusing to overwrite scoped evidence");
            std::fs::write(path, serde_json::to_vec_pretty(&receipt).unwrap()).unwrap();
        }
        if export {
            exports.push(target.clone())
        }
    }
    if let Ok(directory) = std::env::var("EGGCC_SCOPED_EVIDENCE") {
        std::fs::create_dir_all(&directory).unwrap();
        let path = Path::new(&directory).join(format!("boundary-{boundary:04}.json"));
        assert!(
            !path.exists(),
            "refusing to overwrite scoped boundary evidence"
        );
        std::fs::write(
            path,
            serde_json::to_vec_pretty(&json!({
                "source_boundary_invocation": boundary, "mode": format!("{mode:?}"),
                "attempted": attempted, "exports": exports.len(),
            }))
            .unwrap(),
        )
        .unwrap();
    }
    exports
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn loop_constant_requires_literal_and_same_index_passthrough() {
        use crate::ast::*;
        use crate::{parallel, tuplet};
        let cases = [
            (
                parallel!(int(7), int(8)),
                parallel!(tfalse(), getat(0), getat(1)),
                Some(7),
            ),
            (
                parallel!(int(9), int(8)),
                parallel!(tfalse(), getat(0), getat(1)),
                Some(9),
            ),
            (
                parallel!(arg(), int(8)),
                parallel!(tfalse(), getat(0), getat(1)),
                None,
            ),
            (
                parallel!(int(7), int(8)),
                parallel!(tfalse(), add(getat(0), int(1)), getat(1)),
                None,
            ),
            (
                parallel!(int(7), int(8)),
                parallel!(tfalse(), getat(1), getat(1)),
                None,
            ),
        ];
        for (input, body, expected) in cases {
            let function = function(
                "main",
                base(intt()),
                tuplet!(intt(), intt()),
                dowhile(input, body),
            )
            .func_with_arg_types()
            .func_add_ctx()
            .0;
            let program = function.func_to_program();
            let found = loop_invariants(&program);
            assert_eq!(
                found.iter().find(|x| x.index == 0).map(|x| x.value),
                expected
            );
            assert_eq!(
                found.iter().find(|x| x.index == 1).map(|x| x.value),
                Some(8)
            );
        }
    }

    #[test]
    fn branch_input_transport_is_typed_and_context_exact() {
        use crate::ast::*;
        use crate::{parallel, tuplet};
        let parent_scope = Assumption::InFunc("parent".to_owned());
        let input = parallel!(int(7), int(8))
            .with_arg_types(base(intt()), tuplet!(intt(), intt()))
            .add_ctx(parent_scope.clone())
            .0;
        let predicate = eq(int(0), int(1))
            .with_arg_types(base(intt()), base(boolt()))
            .add_ctx(parent_scope.clone())
            .0;
        let child_scope = Assumption::InIf(false, predicate.clone(), input.clone());
        let value = RcExpr::new(Expr::Get(
            RcExpr::new(Expr::Arg(tuplet!(intt(), intt()), child_scope.clone())),
            0,
        ));
        assert_eq!(
            translate(&value, &parent_scope, Some((&child_scope, &input)), &[]),
            Some(Word::Constant(7))
        );
        let sibling = Assumption::InIf(true, predicate, input.clone());
        assert_eq!(
            translate(&value, &parent_scope, Some((&sibling, &input)), &[]),
            None
        );
        let invalid = RcExpr::new(Expr::Get(
            RcExpr::new(Expr::Arg(tuplet!(boolt(), intt()), child_scope.clone())),
            0,
        ));
        assert_eq!(
            translate(&invalid, &parent_scope, Some((&child_scope, &input)), &[]),
            None
        );
    }
    fn words() -> (Word, Word, Word, Word) {
        let x = Word::Slot(0);
        let y = Word::Slot(1);
        let m = Word::Slot(2);
        (
            Word::Mask(Box::new(x.clone()), Box::new(m.clone())),
            Word::Mask(Box::new(y.clone()), Box::new(m)),
            Word::Shift(7, Box::new(x)),
            Word::Shift(7, Box::new(y)),
        )
    }
    #[test]
    fn generic_chain_and_causal_controls() {
        let (a, b, x, y) = words();
        for mode in [
            Mode::Encoding,
            Mode::Manual,
            Mode::AnnotationOff,
            Mode::SeedOnly,
            Mode::QueryOff,
            Mode::BridgeOff,
        ] {
            let (export, receipt) = prove((&a, &b), (&x, &y), mode).unwrap();
            assert_eq!(
                export,
                matches!(mode, Mode::Encoding | Mode::Manual),
                "{receipt}"
            );
            if mode == Mode::Encoding {
                assert_eq!(receipt["child_known"], true);
                assert_eq!(receipt["target_known"], true)
            }
            if mode == Mode::AnnotationOff {
                assert_eq!(receipt["child_known"], true);
                assert_eq!(receipt["target_known"], false)
            }
        }
    }
    #[test]
    fn unsupported_laws_and_infeasible_seed_do_not_export() {
        let (a, b, x, y) = words();
        let other_mask = Word::Mask(Box::new(Word::Slot(1)), Box::new(Word::Slot(3)));
        let other_shift = Word::Shift(8, Box::new(Word::Slot(1)));
        for (left, right, tx, ty) in [
            (&a, &other_mask, &x, &y),
            (&a, &b, &x, &other_shift),
            (&a, &a, &x, &y),
        ] {
            let (export, receipt) = prove((left, right), (tx, ty), Mode::Encoding).unwrap();
            assert!(!export, "{receipt}");
        }
    }
}
