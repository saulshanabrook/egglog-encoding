//! An implementation of egglog-style queries on top of core-relations.
//!
//! This module translates a well-typed egglog-esque query into the abstractions
//! from the `core-relations` crate. The main higher-level functionality that it
//! implements are seminaive evaluation, default values, and merge functions.
//!
//! This crate is essentially involved in desugaring: it elaborates the encoding
//! of core egglog functionality, but it does not implement algorithms for
//! joins, union-finds, etc.

use std::{
    fmt::Debug,
    hash::Hash,
    iter, mem,
    ops::{Index, IndexMut},
    sync::{Arc, Mutex},
};

use crate::core_relations::{
    BaseValue, BaseValueId, BaseValues, ColumnId, Constraint, ContainerValue, ContainerValues,
    CounterId, Database, DisplacedTable, ExecutionState, ExternalContext, ExternalFunction,
    ExternalFunctionBatch, ExternalFunctionId, FlatTable, MergeVal, Offset, PlanStrategy,
    SortedWritesTable, TableId, TableIdentity, TaggedRowBuffer, Value, WrappedTable,
    make_external_func,
};
use crate::numeric_id::{DenseIdMap, DenseIdMapWithReuse, NumericId, define_id};
use egglog_concurrency::{ReadOptimizedLock, ThreadPool};
use egglog_core_relations as core_relations;
use egglog_numeric_id as numeric_id;
use egglog_reports::{IterationReport, ReportLevel, RuleSetReport};
use hashbrown::HashMap;
use indexmap::IndexSet;
use log::info;
use once_cell::sync::Lazy;
use smallvec::SmallVec;
use std::collections::BTreeMap;
use web_time::{Duration, Instant};

const FRESH_ID_RESERVATION_SIZE: usize = 256;

pub mod macros;
pub(crate) mod rule;
#[cfg(test)]
mod tests;

pub use rule::{Function, QueryEntry, RuleBuilder};
use thiserror::Error;

/// A live registry of action handles for use by typed primitives.
///
/// Maps table name to [`TableAction`] (plus the shared [`UnionAction`]
/// and the default-panic external-function id) and is owned by the
/// bridge `EGraph`. The state wrappers (`PureState`/`ReadState`/
/// `WriteState`/`FullState`) live in the `egglog` crate; they read
/// from this registry at invoke time to back name-indexed action
/// methods. Held by the bridge `EGraph` inside an `Arc<ReadOptimizedLock<_>>`.
#[derive(Clone)]
pub struct ActionRegistry {
    table_actions: hashbrown::HashMap<String, TableAction>,
    union_action: UnionAction,
    default_panic_id: ExternalFunctionId,
}

/// Shared live directory of table-operation handles.
pub type SharedActionRegistry = Arc<ReadOptimizedLock<ActionRegistry>>;

// Keep this instantiation safe even with the lock’s currently weaker Sync bound.
const _: fn() = || {
    fn assert_send_sync<T: Send + Sync>() {}
    assert_send_sync::<ActionRegistry>();
};

impl ActionRegistry {
    pub(crate) fn new(union_action: UnionAction, default_panic_id: ExternalFunctionId) -> Self {
        Self {
            table_actions: hashbrown::HashMap::new(),
            union_action,
            default_panic_id,
        }
    }

    pub(crate) fn register_table(&mut self, name: String, action: TableAction) {
        assert!(
            action.identity.is_some(),
            "registered table must be installed"
        );
        self.table_actions.insert(name, action);
    }

    /// Look up the [`TableAction`] for a table by name, or `None` if
    /// no table with that name has been registered. The registry may become
    /// obsolete because of `push`/`pop`, so a hit may name a table a given
    /// execution state no longer has; check it with [`TableAction::is_live`]
    /// before use.
    pub fn lookup_table(&self, name: &str) -> Option<&TableAction> {
        self.table_actions.get(name)
    }

    /// Snapshot the names and row counts of the registered tables that exist
    /// in `state`.
    pub fn table_sizes(&self, state: &ExecutionState) -> Vec<(&str, usize)> {
        self.table_actions
            .iter()
            .filter(|(_, action)| action.is_live(state))
            .map(|(name, action)| (name.as_str(), action.row_count(state)))
            .collect()
    }

    /// The shared [`UnionAction`] for this EGraph's union-find.
    pub fn union_action(&self) -> &UnionAction {
        &self.union_action
    }

    /// The default panic external function id, used by the egglog
    /// crate's `ActionView::panic`.
    pub fn default_panic_id(&self) -> ExternalFunctionId {
        self.default_panic_id
    }
}

#[derive(Debug, Copy, Clone, Eq, PartialEq, Hash)]
pub enum ColumnTy {
    Id,
    Base(BaseValueId),
}

define_id!(pub RuleId, u32, "An egglog-style rule");
define_id!(pub FunctionId, u32, "An id representing an egglog function");
define_id!(pub(crate) Timestamp, u32, "An abstract timestamp used to track execution of egglog rules");
impl Timestamp {
    fn to_value(self) -> Value {
        Value::new(self.rep())
    }
}

/// The state associated with an egglog program.
#[derive(Clone)]
pub struct EGraph {
    db: Database,
    uf_table: TableId,
    id_counter: CounterId,
    timestamp_counter: CounterId,
    rules: DenseIdMapWithReuse<RuleId, RuleInfo>,
    funcs: DenseIdMap<FunctionId, FunctionInfo>,
    panic_message: SideChannel<String>,
    /// This is a cache of all the different panic messages that we may use while executing rules
    /// against the EGraph. Oftentimes, these messages are generated dynamically: keeping this map
    /// around allows us to cache external function ids with repeat panic messages and they can
    /// also serve as a debugging tool in the case that the number of panic messages grows without
    /// bound.
    panic_funcs: HashMap<String, ExternalFunctionId>,
    report_level: ReportLevel,
    /// Live registry of name-indexed action handles. Shared (via
    /// `Arc<ReadOptimizedLock<_>>`) with state wrappers and primitive callbacks
    /// in the egglog crate so name-indexed action methods on
    /// `WriteState` / `FullState` can resolve table actions at
    /// invoke time. Mutated in place from [`add_table`](EGraph::add_table).
    action_registry: SharedActionRegistry,
    /// Table each row-inserting external function writes, by name. A merge body
    /// calling one declares the same write dependency an explicit `set` on that
    /// table would (see [`MergeFn::fill_deps`]).
    // Avoid introducing another randomly seeded hash table: row iteration order
    // in proof extraction can depend on the seed sequence of existing maps.
    external_write_deps: BTreeMap<ExternalFunctionId, String>,
    /// Lowering data for the encoding's write primitives, keyed by the runtime
    /// id their call sites resolve to. See [`EGraph::mint_insert_plan`].
    ///
    /// Each spec names its table rather than holding a [`TableId`], and the
    /// lowering resolves the name once, when the rule is built. The external
    /// path re-resolves it per call, so the two agree only because a table
    /// name is bound at most once (the typechecker rejects a redefinition).
    mint_specs: BTreeMap<ExternalFunctionId, MintSpec>,
    set_if_empty_specs: BTreeMap<ExternalFunctionId, SetIfEmptySpec>,
    view_col_specs: BTreeMap<ExternalFunctionId, ViewColSpec>,
    threads: usize,
    thread_pool: Option<Arc<ThreadPool>>,
}

pub type Result<T> = std::result::Result<T, anyhow::Error>;

fn normalize_thread_count(threads: usize) -> usize {
    #[cfg(target_family = "wasm")]
    {
        if threads > 1 {
            panic!("cannot use more than 1 thread on wasm");
        }
        1
    }
    #[cfg(not(target_family = "wasm"))]
    {
        if threads == 0 {
            std::thread::available_parallelism()
                .map(usize::from)
                .unwrap_or(1)
        } else {
            threads
        }
    }
}

fn install_thread_pool<R>(thread_pool: Option<Arc<ThreadPool>>, f: impl FnOnce() -> R) -> R {
    match thread_pool {
        Some(thread_pool) => thread_pool.install(f),
        None => egglog_concurrency::without_current_pool(f),
    }
}

impl Default for EGraph {
    fn default() -> Self {
        Self::new(1)
    }
}

/// Properties of a function added to an [`EGraph`].
pub struct FunctionConfig {
    /// The function's schema: `n_keys` key (input) columns followed by [`FunctionConfig::n_vals`]
    /// value (output) columns.
    pub schema: Vec<ColumnTy>,
    /// The number of value (output) columns; the remaining leading columns are keys. Must be at
    /// least 1 and at most `schema.len()`. A tuple-output function has more than one.
    pub n_vals: usize,
    /// Opt-in identity-column guard. `Some(k)` marks the first `k` value columns (`k` in
    /// `1..=n_vals`) as *identity*: when a key collision leaves those columns unchanged the merge is
    /// skipped and the existing row is kept (a subsume-flag change still applies). `None` (the
    /// default) runs the merge on every collision, preserving arbitrary/non-idempotent merge
    /// semantics. Only opt in for merges that are idempotent on equal inputs (`merge(x, x) == x`).
    pub n_identity_vals: Option<usize>,
    /// The behavior of the function when lookups are made on keys not currently present.
    pub default: DefaultVal,
    /// How to resolve FD conflicts for the function.
    pub merge: MergeFn,
    /// The function's name
    pub name: String,
    /// Whether or not subsumption is enabled for this function.
    pub can_subsume: bool,
}

#[derive(Debug, Copy, Clone, Eq, PartialEq)]
enum TableStorage {
    SortedWrites,
    Flat,
}

impl EGraph {
    /// Create an e-graph configured to use `threads` worker threads.
    ///
    /// Passing `1` keeps execution serial and does not allocate a thread pool.
    /// Passing `0` uses the host's available parallelism.
    pub fn new(threads: usize) -> Self {
        let threads = normalize_thread_count(threads);
        let thread_pool = (threads > 1).then(|| Arc::new(ThreadPool::new(threads)));
        let (mut db, uf_table, id_counter, ts_counter) =
            install_thread_pool(thread_pool.clone(), || {
                let mut db = Database::new();
                let uf_table = db.add_table_named(
                    DisplacedTable::default(),
                    "$uf".into(),
                    iter::empty(),
                    iter::empty(),
                );
                let id_counter = db.add_reservable_counter(FRESH_ID_RESERVATION_SIZE);
                let ts_counter = db.add_counter();
                // Start the timestamp counter at 1.
                db.inc_counter(ts_counter);
                (db, uf_table, id_counter, ts_counter)
            });

        // Register a default panic external function so the typed
        // state wrappers' `panic()` method has an id to call. This
        // also seeds `panic_funcs` so a later `new_panic` with the
        // same message reuses the id.
        let panic_message: SideChannel<String> = Default::default();
        let mut panic_funcs: HashMap<String, ExternalFunctionId> = Default::default();
        let default_panic_msg = "primitive panicked".to_string();
        let default_panic_id = db.add_external_function(Box::new(Panic(
            default_panic_msg.clone(),
            panic_message.clone(),
        )));
        panic_funcs.insert(default_panic_msg, default_panic_id);

        let union_action = UnionAction {
            table: uf_table,
            timestamp: ts_counter,
        };
        let action_registry = Arc::new(ReadOptimizedLock::new(ActionRegistry::new(
            union_action,
            default_panic_id,
        )));

        Self {
            db,
            uf_table,
            id_counter,
            timestamp_counter: ts_counter,
            rules: Default::default(),
            funcs: Default::default(),
            panic_message,
            panic_funcs,
            report_level: Default::default(),
            action_registry,
            external_write_deps: Default::default(),
            mint_specs: Default::default(),
            set_if_empty_specs: Default::default(),
            view_col_specs: Default::default(),
            threads,
            thread_pool,
        }
    }

    /// Return a copy of this e-graph configured with a different thread count.
    pub fn with_num_threads(mut self, threads: usize) -> Self {
        self.set_num_threads(threads);
        self
    }

    /// Set the number of worker threads used by this e-graph.
    ///
    /// Passing `1` disables the pool. Passing `0` uses available parallelism.
    pub fn set_num_threads(&mut self, threads: usize) {
        let threads = normalize_thread_count(threads);
        self.threads = threads;
        self.thread_pool = (threads > 1).then(|| Arc::new(ThreadPool::new(threads)));
    }

    /// Return the configured thread count.
    pub fn num_threads(&self) -> usize {
        self.threads
    }

    fn thread_pool(&self) -> Option<Arc<ThreadPool>> {
        self.thread_pool.clone()
    }

    fn next_ts(&self) -> Timestamp {
        Timestamp::from_usize(self.db.read_counter(self.timestamp_counter))
    }

    fn inc_ts(&mut self) {
        self.db.inc_counter(self.timestamp_counter);
    }

    /// Get a mutable reference to the underlying table of base values for this
    /// `EGraph`.
    pub fn base_values_mut(&mut self) -> &mut BaseValues {
        self.db.base_values_mut()
    }

    /// Get a mutable reference to the underlying table of containers for this
    /// `EGraph`.
    pub fn container_values_mut(&mut self) -> &mut ContainerValues {
        self.db.container_values_mut()
    }

    /// Get a reference to the underlying table of containers for this `EGraph`.
    pub fn container_values(&self) -> &ContainerValues {
        self.db.container_values()
    }

    /// Intern the given container value into the EGraph.
    pub fn get_container_value<C: ContainerValue>(&mut self, val: C) -> Value {
        self.register_container_ty::<C>();
        let thread_pool = self.thread_pool();
        install_thread_pool(thread_pool, || {
            self.db.with_execution_state(None, |state| {
                state.clone().container_values().register_val(val, state)
            })
        })
    }

    /// Register the given [`ContainerValue`] type with this EGraph.
    ///
    /// The given container will use the EGraph's union-find to manage rebuilding and the merging
    /// of containers with a common id.
    pub fn register_container_ty<C: ContainerValue>(&mut self) {
        let uf_table = self.uf_table;
        let ts_counter = self.timestamp_counter;
        self.db.container_values_mut().register_type::<C>(
            self.id_counter,
            move |state, old, new| {
                if old != new {
                    let next_ts = Value::from_usize(state.read_counter(ts_counter));
                    state.stage_insert(uf_table, &[old, new, next_ts]);
                    std::cmp::min(old, new)
                } else {
                    old
                }
            },
        );
    }

    /// Get a reference to the underlying table of base values for this `EGraph`.
    pub fn base_values(&self) -> &BaseValues {
        self.db.base_values()
    }

    /// Create a [`QueryEntry`] for a base value.
    pub fn base_value_constant<T>(&self, x: T) -> QueryEntry
    where
        T: BaseValue,
    {
        QueryEntry::Const {
            val: self.base_values().get(x),
            ty: ColumnTy::Base(self.base_values().get_ty::<T>()),
        }
    }

    /// Register a low-level external function. The callback receives a
    /// raw `&mut ExecutionState`.
    ///
    /// # Seminaive-safety trust boundary
    ///
    /// Like [`EGraph::with_execution_state`], this is a raw escape —
    /// the registered function has unrestricted access and is not
    /// tracked by the per-context validity system. Prefer building
    /// primitives via the higher-level `egglog::Primitive` /
    /// `egglog::EGraph::add_primitive` API, which enforces #772's
    /// seminaive-safety contract.
    pub fn register_external_func(
        &mut self,
        func: Box<dyn ExternalFunction + 'static>,
    ) -> ExternalFunctionId {
        self.db.add_external_function(func)
    }

    /// Register the term encoder's `set-if-empty` canonicalize op for the FD
    /// view table named `view_name` (`n_keys` key columns), returning the
    /// [`ExternalFunctionId`] its mint sites resolve to.
    ///
    /// Invoked as `(keys…, vals…)`, it returns the view's first output column
    /// (the e-class) for `keys`: the existing row's when the key is present, and
    /// otherwise the first of `vals` after staging `(keys, vals)`. A second
    /// invocation with the same key inside one action batch sees the first one's
    /// staged row, so the two agree — see
    /// [`TableAction::lookup_or_insert_vals`].
    pub fn register_set_if_empty(
        &mut self,
        view_name: String,
        n_keys: usize,
        out_arity: usize,
    ) -> ExternalFunctionId {
        let registry = self.action_registry.clone();
        let spec_name = view_name.clone();
        let id = self.register_external_func(Box::new(make_external_func(
            move |state: &mut ExecutionState, args: &[Value]| {
                let registry = registry.read();
                let action = registry.lookup_table(&view_name)?;
                // Too few vals and the row is staged short of its value columns;
                // too many and the surplus lands on the timestamp.
                debug_assert_eq!(
                    args.len(),
                    n_keys + out_arity,
                    "set-if-empty on view `{view_name}` takes {n_keys} keys and \
                     {out_arity} values"
                );
                let keys = &args[..n_keys];
                Some(action.lookup_or_insert_vals(state, keys, &args[n_keys..]))
            },
        )));
        self.set_if_empty_specs.insert(
            id,
            SetIfEmptySpec {
                view_name: spec_name,
                n_keys,
                out_arity,
            },
        );
        id
    }

    /// Register a reader for output column `col_idx` of the FD view named
    /// `view_name` (`n_keys` key columns): `(keys, fallback) -> column`, returning
    /// that output column for `keys` or `fallback` when the key is absent. The term
    /// encoder reads its proof column with `col_idx = 1`.
    pub fn register_view_column_read(
        &mut self,
        view_name: String,
        n_keys: usize,
        col_idx: usize,
    ) -> ExternalFunctionId {
        let registry = self.action_registry.clone();
        let spec_name = view_name.clone();
        let id = self.register_external_func(Box::new(make_external_func(
            move |state: &mut ExecutionState, args: &[Value]| {
                let registry = registry.read();
                let action = registry.lookup_table(&view_name)?;
                let fallback = args[n_keys];
                Some(
                    action
                        .lookup_value_col(state, &args[..n_keys], col_idx)
                        .unwrap_or(fallback),
                )
            },
        )));
        self.view_col_specs.insert(
            id,
            ViewColSpec {
                view_name: spec_name,
                n_keys,
                col_idx,
            },
        );
        id
    }

    /// Register the term encoder's mint op for the term-node relation named
    /// `table_name`, returning the [`ExternalFunctionId`] its call sites resolve
    /// to.
    ///
    /// Invoked as `(args…)`, it mints a fresh id — from the same counter as
    /// `get-fresh!`, so never one already in use — stages the row
    /// `(args…, fresh, vals…)`, and returns `fresh`.
    pub fn register_mint_row(
        &mut self,
        table_name: String,
        n_args: usize,
        vals: Vec<Value>,
    ) -> ExternalFunctionId {
        #[derive(Clone)]
        struct MintRows {
            registry: SharedActionRegistry,
            table_name: String,
            n_args: usize,
            counter: CounterId,
            vals: Vec<Value>,
        }

        impl ExternalFunction for MintRows {
            fn invoke(&self, state: &mut ExecutionState, args: &[Value]) -> Option<Value> {
                let registry = self.registry.read();
                let action = registry.lookup_table(&self.table_name)?;
                debug_assert_eq!(
                    args.len(),
                    self.n_args,
                    "mint into `{}` takes {} arguments",
                    self.table_name,
                    self.n_args
                );
                let fresh = Value::from_usize(state.inc_counter(self.counter));
                action.insert(
                    state,
                    args.iter()
                        .copied()
                        .chain([fresh])
                        .chain(self.vals.iter().copied()),
                );
                Some(fresh)
            }

            fn invoke_batch(&self, state: &mut ExecutionState, batch: ExternalFunctionBatch<'_>) {
                if batch.is_empty() {
                    return;
                }
                let registry = self.registry.read();
                let Some(action) = registry.lookup_table(&self.table_name) else {
                    batch.map(|_| None);
                    return;
                };
                // Mint ids before borrowing the table buffer, in the same order
                // as scalar calls. Reuse the row scratch and notify only once.
                let fresh: Vec<_> = (0..batch.len())
                    .map(|_| Value::from_usize(state.inc_counter(self.counter)))
                    .collect();
                let mut fresh = fresh.into_iter();
                let ts = Value::from_usize(state.read_counter(action.timestamp));
                let mut row = SmallVec::<[Value; 8]>::new();
                state.stage_batch(action.table, |buffer| {
                    batch.map(|args| {
                        debug_assert_eq!(args.len(), self.n_args);
                        let fresh = fresh.next().unwrap();
                        row.clear();
                        row.extend_from_slice(args);
                        row.push(fresh);
                        row.extend_from_slice(&self.vals);
                        action.table_math.write_table_row(
                            &mut row,
                            RowVals {
                                timestamp: ts,
                                subsume: action.table_math.subsume.then_some(NOT_SUBSUMED),
                                ret_val: None,
                            },
                        );
                        buffer.stage_insert(&row);
                        Some(fresh)
                    });
                });
            }
        }

        let dep = table_name.clone();
        let spec = MintSpec {
            table_name: table_name.clone(),
            n_args,
            vals: vals.clone(),
            counter: self.id_counter,
        };
        let id = self.register_external_func(Box::new(MintRows {
            registry: self.action_registry.clone(),
            table_name,
            n_args,
            counter: self.id_counter,
            vals,
        }));
        self.external_write_deps.insert(id, dep);
        self.mint_specs.insert(id, spec);
        id
    }

    /// The batched-instruction lowering of a `mint-<Relation>!` primitive
    /// called with `n_args` arguments, or `None` if `func` is not one, its
    /// table is not installed yet, or the call does not fill the row. A `None`
    /// here is not an error: the call site stays on the per-row external path,
    /// which validates the same shape itself.
    pub(crate) fn mint_insert_plan(
        &self,
        func: ExternalFunctionId,
        n_args: usize,
    ) -> Option<MintInsertPlan> {
        let spec = self.mint_specs.get(&func)?;
        let registry = self.action_registry.read();
        let action = registry.lookup_table(&spec.table_name)?;
        let math = action.table_math;
        // The row is `args ++ [fresh] ++ vals`, so the minted id sits at
        // `n_args` and the three together must cover every function column.
        if n_args != spec.n_args || n_args + 1 + spec.vals.len() != math.func_cols {
            return None;
        }
        Some(MintInsertPlan {
            table: action.table,
            tail: spec.vals.clone(),
            counter: spec.counter,
            math,
            minted_col: ColumnId::from_usize(n_args),
        })
    }

    /// The instruction lowering of a `set-if-empty-<View>!` primitive called
    /// with `n_args` arguments, or `None` if `func` is not one, its table is not
    /// installed yet, or the call does not supply exactly one value per value
    /// column. A short row would push the timestamp into a value column.
    pub(crate) fn set_if_empty_plan(
        &self,
        func: ExternalFunctionId,
        n_args: usize,
    ) -> Option<SetIfEmptyPlan> {
        let spec = self.set_if_empty_specs.get(&func)?;
        let registry = self.action_registry.read();
        let action = registry.lookup_table(&spec.view_name)?;
        let math = action.table_math;
        if math.num_keys() != spec.n_keys
            || math.n_vals() != spec.out_arity
            || n_args != spec.n_keys + spec.out_arity
        {
            return None;
        }
        Some(SetIfEmptyPlan {
            table: action.table,
            n_keys: spec.n_keys,
            ret_val_col: ColumnId::from_usize(math.ret_val_col()),
            subsume: math.subsume,
        })
    }

    /// The instruction lowering of a view-column read called with `n_args`
    /// arguments (the keys plus the fallback), or `None` if `func` is not one or
    /// its table is not installed yet.
    pub(crate) fn view_col_plan(
        &self,
        func: ExternalFunctionId,
        n_args: usize,
    ) -> Option<ViewColPlan> {
        let spec = self.view_col_specs.get(&func)?;
        let registry = self.action_registry.read();
        let action = registry.lookup_table(&spec.view_name)?;
        let math = action.table_math;
        if math.num_keys() != spec.n_keys
            || spec.col_idx >= math.n_vals()
            || n_args != spec.n_keys + 1
        {
            return None;
        }
        Some(ViewColPlan {
            table: action.table,
            n_keys: spec.n_keys,
            dst_col: ColumnId::from_usize(math.num_keys() + spec.col_idx),
        })
    }

    /// The table an external function inserts into, for the merge dependency
    /// graph. `None` for a function that writes no table, or one whose table is
    /// not declared yet.
    fn external_write_table(&self, func: ExternalFunctionId) -> Option<TableId> {
        let name = self.external_write_deps.get(&func)?;
        Some(self.action_registry.read().lookup_table(name)?.table)
    }

    pub fn free_external_func(&mut self, func: ExternalFunctionId) {
        self.external_write_deps.remove(&func);
        self.mint_specs.remove(&func);
        self.set_if_empty_specs.remove(&func);
        self.view_col_specs.remove(&func);
        self.db.free_external_function(func);
    }

    /// Generate a fresh id.
    pub fn fresh_id(&mut self) -> Value {
        Value::from_usize(self.db.inc_counter(self.id_counter))
    }

    /// The global counter that mints fresh ids (backing [`fresh_id`](Self::fresh_id)
    /// and `DefaultVal::FreshId`). Exposed so a primitive can mint ids in the same space during
    /// rule execution — used by the term/proof encoding's `get-fresh!` primitive.
    pub fn id_counter(&self) -> CounterId {
        self.id_counter
    }

    /// Look up the canonical value for `val` in the union-find.
    ///
    /// If the value has never been inserted into the union-find, `val` is returned.
    fn get_canon_in_uf(&self, val: Value) -> Value {
        let table = self.db.get_table(self.uf_table);
        let row = table.get_row(&[val]);
        row.map(|row| row.vals[1]).unwrap_or(val)
    }

    /// Get the canonical representation for `val` based on type.
    ///
    /// For [`ColumnTy::Id`], it looks up the union find; otherwise,
    /// it returns the value itself.
    pub fn get_canon_repr(&self, val: Value, ty: ColumnTy) -> Value {
        match ty {
            ColumnTy::Id => self.get_canon_in_uf(val),
            ColumnTy::Base(_) => val,
        }
    }

    /// Load the given values into the database.
    ///
    /// # Panics
    /// This method panics if the values do not match the arity of the function.
    ///
    /// NB: this is not an efficient interface for bulk loading. We should add
    /// one that allows us to pass through a series of RowBuffers before
    /// incrementing the timestamp.
    pub fn add_values(&mut self, values: impl IntoIterator<Item = (FunctionId, Vec<Value>)>) {
        let mut extended_row = Vec::<Value>::new();
        let mut bufs = DenseIdMap::default();
        for (func, row) in values.into_iter() {
            let table_info = &self.funcs[func];
            let schema_math = table_info.schema_math();
            let table_id = table_info.table;
            extended_row.extend_from_slice(&row);
            schema_math.write_table_row(
                &mut extended_row,
                RowVals {
                    timestamp: self.next_ts().to_value(),
                    subsume: schema_math.subsume.then_some(NOT_SUBSUMED),
                    ret_val: None, // already filled in.
                },
            );
            let buf = bufs.get_or_insert(table_id, || self.db.new_buffer(table_id));
            buf.stage_insert(&extended_row);
            extended_row.clear();
        }
        // Flush the buffers.
        mem::drop(bufs);
        self.flush_updates();
    }

    /// A term-oriented means of adding data to the database: hand back a "term
    /// id" for the given function and keys for the function.
    ///
    /// # Panics
    /// This method panics if the values do not match the arity of the function.
    pub fn add_term(&mut self, func: FunctionId, inputs: &[Value]) -> Value {
        let info = &self.funcs[func];
        let schema_math = info.schema_math();
        let mut extended_row = Vec::new();
        extended_row.extend_from_slice(inputs);
        let res = self.fresh_id();
        schema_math.write_table_row(
            &mut extended_row,
            RowVals {
                timestamp: self.next_ts().to_value(),
                ret_val: Some(res),
                subsume: schema_math.subsume.then_some(NOT_SUBSUMED),
            },
        );
        extended_row[schema_math.ret_val_col()] = res;
        let table_id = self.funcs[func].table;
        self.db.new_buffer(table_id).stage_insert(&extended_row);
        self.flush_updates();
        self.get_canon_in_uf(res)
    }

    /// Lookup a function row by key, returning its keys followed by all value
    /// columns and excluding internal row metadata.
    pub fn lookup_row(&self, func: FunctionId, key: &[Value]) -> Option<Vec<Value>> {
        let info = &self.funcs[func];
        let schema_math = info.schema_math();
        let table_id = info.table;
        let table = self.db.get_table(table_id);
        let row = table.get_row(key)?;
        Some(row.vals[..schema_math.func_cols].to_vec())
    }

    /// Lookup the first value associated with a function `func` and the given
    /// arguments (`key`).
    pub fn lookup_id(&self, func: FunctionId, key: &[Value]) -> Option<Value> {
        self.lookup_row(func, key).map(|row| row[key.len()])
    }

    pub fn approx_table_size(&self, table: FunctionId) -> usize {
        self.db.estimate_size(self.funcs[table].table, None)
    }

    pub fn table_size(&self, table: FunctionId) -> usize {
        self.db.get_table(self.funcs[table].table).len()
    }

    /// Whether a function uses the internal append-and-scan storage.
    #[doc(hidden)]
    pub fn table_is_flat(&self, table: FunctionId) -> bool {
        let table = self.db.get_table(self.funcs[table].table);
        if table.as_any().is::<FlatTable>() {
            true
        } else {
            assert!(
                table.as_any().is::<SortedWritesTable>(),
                "function table uses an unknown storage implementation"
            );
            false
        }
    }

    /// Remove every row from the given function's backing table.
    ///
    /// This is the bulk counterpart to staging a `remove` for every key in the
    /// table: the underlying `Database::clear_table` drops the row buffer in
    /// O(1)-in-row-count time and bumps the table's major generation, which
    /// lazily invalidates any cached subsets or indexes a later reader might
    /// consult. Any rows staged for this table by an in-flight
    /// `MutationBuffer` are dropped along with the table contents.
    ///
    /// Callers that have staged inserts/removes for *other* tables that they
    /// want flushed first should call [`EGraph::flush_updates`] before
    /// clearing.
    pub fn clear_table(&mut self, func: FunctionId) {
        let table_id = self.funcs[func].table;
        self.db.clear_table(table_id);
    }

    /// Read the contents of the given function.
    ///
    /// The callback `f` is called with each row and its subsumption status.
    pub fn for_each(&self, table: FunctionId, mut f: impl FnMut(ScanEntry<'_>)) {
        self.for_each_while(table, |row| {
            f(row);
            true
        });
    }

    /// Iterate over the rows of a function table, calling `f` on each row. If `f` returns `false`
    /// the function returns early and stops reading rows from the table.
    pub fn for_each_while(&self, table: FunctionId, mut f: impl FnMut(ScanEntry<'_>) -> bool) {
        let info = &self.funcs[table];
        let table = self.funcs[table].table;
        let schema_math = info.schema_math();
        let imp = self.db.get_table(table);
        let all = imp.all();
        let mut cur = Offset::new(0);
        let mut buf = TaggedRowBuffer::new(imp.spec().arity());
        // This somewhat awkward iteration strategy is forced on us by the `scan_bounded` API. We
        // should look into ways to avoid this cludge where the loop body effectively must be
        // repeated at the end. The obvious and idiomatic ways to do this all require
        // `dyn`-compatibility on `Table` or dynamic dispatch per row.
        macro_rules! drain_buf {
            ($buf:expr) => {
                for (_, row) in $buf.iter() {
                    let subsumed =
                        schema_math.subsume && row[schema_math.subsume_col()] == SUBSUMED;
                    if !f(ScanEntry {
                        vals: &row[0..schema_math.func_cols],
                        subsumed,
                    }) {
                        return;
                    }
                }
                $buf.clear();
            };
        }
        while let Some(next) = imp.scan_bounded(all.as_ref(), cur, 32, &mut buf) {
            drain_buf!(buf);
            cur = next;
        }
        drain_buf!(buf);
    }

    /// A basic method for dumping the state of the database to `log::info!`.
    ///
    /// For large tables, this is unlikely to give particularly useful output.
    pub fn dump_debug_info(&self) {
        info!("=== View Tables ===");
        for (id, info) in self.funcs.iter() {
            let table = self.db.get_table(info.table);
            self.scan_table(table, |row| {
                info!(
                    "View Table {name} / {id:?} / {table:?}: {row:?}",
                    name = info.name,
                    table = info.table
                )
            });
        }
    }

    /// A helper for scanning the entries in a table.
    fn scan_table(&self, table: &WrappedTable, mut f: impl FnMut(&[Value])) {
        const BATCH_SIZE: usize = 128;
        let all = table.all();
        let mut cur = Offset::new(0);
        let mut out = TaggedRowBuffer::new(table.spec().arity());
        while let Some(next) = table.scan_bounded(all.as_ref(), cur, BATCH_SIZE, &mut out) {
            out.iter().for_each(|(_, row)| f(row));
            out.clear();
            cur = next;
        }
        out.iter().for_each(|(_, row)| f(row));
    }

    /// Register a function in this EGraph.
    /// The [`FunctionId`] the next [`EGraph::add_table`] will assign. Lets a caller build a
    /// self-referential merge (one that names the table it is about to create) before calling
    /// `add_table`; the id is deterministic as long as no other function is added in between.
    pub fn peek_next_function_id(&self) -> FunctionId {
        self.funcs.next_id()
    }

    pub fn add_table(&mut self, config: FunctionConfig) -> FunctionId {
        self.add_table_with_storage(config, TableStorage::SortedWrites, None)
    }

    /// Add a function whose name-indexed read APIs expose a logical row layout
    /// different from its physical table schema.
    ///
    /// This is public only so the sibling `egglog` crate can install the views
    /// generated by term/proof encoding. It is not a general-purpose storage
    /// option.
    #[doc(hidden)]
    pub fn add_table_with_read_projection(
        &mut self,
        config: FunctionConfig,
        kind: TableKind,
        input_arity: usize,
        output_arity: usize,
    ) -> FunctionId {
        self.add_table_with_storage(
            config,
            TableStorage::SortedWrites,
            Some(TableReadProjection {
                kind,
                input_arity,
                output_arity,
            }),
        )
    }

    /// Add a trusted internal function backed by append-and-scan storage.
    ///
    /// The caller must guarantee that the function is only directly inserted
    /// and scanned: lookup, removal, conflict resolution, and rebuilding are
    /// unsupported. In particular, any id columns must be immutable snapshots
    /// that never require canonicalization. Violating that contract can panic
    /// or leave stale ids in the table.
    ///
    /// This is public only so the sibling `egglog` crate can install its
    /// internal proof-record tables. It is hidden because it is a semantic
    /// trust boundary, not a general-purpose storage option.
    #[doc(hidden)]
    pub fn add_internal_flat_table(&mut self, config: FunctionConfig) -> FunctionId {
        self.add_table_with_storage(config, TableStorage::Flat, None)
    }

    fn add_table_with_storage(
        &mut self,
        config: FunctionConfig,
        storage: TableStorage,
        read_projection: Option<TableReadProjection>,
    ) -> FunctionId {
        let FunctionConfig {
            schema,
            n_vals,
            n_identity_vals,
            default,
            merge,
            name,
            can_subsume,
        } = config;
        assert!(
            !schema.is_empty(),
            "must have at least one column in schema"
        );
        // `n_vals` (value-column count) is declared by the caller, not inferred from the merge, so a
        // tuple-output function whose merge isn't a top-level `Columns` can't silently mis-split its
        // key and value columns. `to_callback` cross-checks that the merge produces exactly `n_vals`
        // columns, and `check_value_col_indices` that its `OldCol`/`NewCol` stay in range.
        assert!(
            (1..=schema.len()).contains(&n_vals),
            "function {name} declares {n_vals} value columns but has {} columns total",
            schema.len()
        );
        if let Some(k) = n_identity_vals {
            assert!(
                (1..=n_vals).contains(&k),
                "function {name} declares {k} identity columns but has {n_vals} value columns"
            );
        }
        if storage == TableStorage::Flat {
            assert_eq!(
                n_vals, 1,
                "flat function `{name}` must have exactly one inert value column"
            );
            assert!(
                n_identity_vals.is_none(),
                "flat function `{name}` cannot declare identity value columns"
            );
            assert!(
                matches!(default, DefaultVal::Fail),
                "flat function `{name}` cannot provide a lookup default"
            );
            assert!(
                matches!(&merge, MergeFn::AssertEq),
                "flat function `{name}` cannot provide merge behavior"
            );
            assert!(
                !can_subsume,
                "flat function `{name}` cannot support subsumption"
            );
        }
        merge.check_value_col_indices(n_vals, &name);
        let to_rebuild: Vec<ColumnId> = schema
            .iter()
            .enumerate()
            .filter(|(_, ty)| matches!(ty, ColumnTy::Id))
            .map(|(i, _)| ColumnId::from_usize(i))
            .collect();
        let n_keys = schema.len() - n_vals;
        let physical_kind = match default {
            DefaultVal::FreshId => TableKind::Constructor,
            DefaultVal::Fail | DefaultVal::Const(_) => TableKind::Function,
        };
        let read_projection = read_projection.unwrap_or(TableReadProjection {
            kind: physical_kind,
            input_arity: n_keys,
            output_arity: n_vals,
        });
        assert!(
            read_projection.output_arity > 0
                && read_projection.input_arity + read_projection.output_arity <= schema.len()
                && (read_projection.kind != TableKind::Constructor
                    || read_projection.output_arity == 1),
            "invalid read projection for table `{name}`"
        );
        let schema_math = SchemaMath {
            subsume: can_subsume,
            n_keys,
            func_cols: schema.len(),
            n_identity_vals,
        };
        let n_args = schema_math.num_keys();
        let n_cols = schema_math.table_columns();
        let next_func_id = self.funcs.next_id();
        let name: Arc<str> = name.into();
        // Knot-tying for a self-referential merge (e.g. the term encoder's single-table UF `@UF`,
        // whose `:merge` does a `TableInsert` into its OWN table): merge resolution (`fill_deps` /
        // `to_callback` -> `TableAction::new`) reads `self.funcs[self_id].table`, so the new
        // `FunctionInfo` must already be in `self.funcs` before the merge is built. Reserve the
        // table id (the next `add_table_named` assigns exactly this id) and push the `FunctionInfo`
        // up front, then build the merge and the backing table. Non-self-referential merges resolve
        // the same either way.
        let table_id = self.db.next_table_id();
        let res = self.funcs.push(FunctionInfo {
            table: table_id,
            schema: schema.clone(),
            n_keys,
            n_identity_vals,
            incremental_rebuild_rules: Default::default(),
            nonincremental_rebuild_rule: RuleId::new(!0),
            default_val: default,
            can_subsume,
            name: name.clone(),
            read_projection,
        });
        // Not a debug_assert: a mismatch here silently mis-maps every future reference to this
        // function's table (see the knot-tying comment above), so pay the one-time check in release.
        assert_eq!(
            res, next_func_id,
            "peek_next_function_id / add_table id reservation is out of sync"
        );

        let mut read_deps = IndexSet::<TableId>::new();
        let mut write_deps = IndexSet::<TableId>::new();
        merge.fill_deps(self, &mut read_deps, &mut write_deps);
        // A self-referential merge may only *write* back into its own table (the pre-seeded
        // write buffer handles that); *reading* self during its own merge is unsupported and would
        // otherwise panic deep inside merge execution.
        assert!(
            !read_deps.contains(&table_id),
            "self-referential merge for `{name}` may only write to its own table, not read it"
        );
        let assigned_table_id = match storage {
            TableStorage::SortedWrites => {
                let merge_fn = merge.to_callback(schema_math, &name, self);
                let table = install_thread_pool(self.thread_pool(), || {
                    SortedWritesTable::new(
                        n_args,
                        n_cols,
                        Some(ColumnId::from_usize(schema.len())),
                        to_rebuild,
                        merge_fn,
                    )
                });
                self.db.add_table_named(
                    table,
                    name.clone(),
                    read_deps.iter().copied(),
                    write_deps.iter().copied(),
                )
            }
            TableStorage::Flat => {
                let table = install_thread_pool(self.thread_pool(), || FlatTable::new(n_cols));
                self.db.add_table_named(
                    table,
                    name.clone(),
                    read_deps.iter().copied(),
                    write_deps.iter().copied(),
                )
            }
        };
        assert_eq!(
            assigned_table_id, table_id,
            "reserved table id did not match the id assigned by add_table_named"
        );
        let (incremental_rebuild_rules, nonincremental_rebuild_rule) = match storage {
            TableStorage::SortedWrites => (
                self.incremental_rebuild_rules(res, &schema),
                self.nonincremental_rebuild(res, &schema),
            ),
            // The fallback rebuild scheduler expects one bookkeeping rule per
            // function. Flat proof records are immutable, so give them an
            // inert rule instead of generating keyed remove/reinsert actions.
            TableStorage::Flat => (Vec::new(), self.inert_rebuild_rule(res)),
        };
        let info = &mut self.funcs[res];
        info.incremental_rebuild_rules = incremental_rebuild_rules;
        info.nonincremental_rebuild_rule = nonincremental_rebuild_rule;
        let action = TableAction::new(self, res);
        let table_name = self.funcs[res].name.to_string();
        self.action_registry
            .lock()
            .register_table(table_name, action);
        res
    }

    /// A handle to the live [`ActionRegistry`] for this EGraph.
    /// The handle is shared (`Arc<ReadOptimizedLock<_>>`); cloning the outer
    /// `Arc` does not duplicate the underlying registry. Used by the
    /// egglog crate's primitive machinery to thread the registry into
    /// state wrappers at invoke time.
    pub fn action_registry(&self) -> &SharedActionRegistry {
        &self.action_registry
    }

    /// Run the given rules for one iteration and return its report.
    ///
    /// `context` is visible to any external function the rules reach; pass
    /// `None` if there is nothing to share.
    ///
    /// If a rule action raises an egglog-level panic, actions completed before
    /// it remain applied. A successful recovery rebuild leaves the e-graph
    /// canonical and reusable; it does not roll effects back or guarantee that
    /// the failed action will be retried. If rebuilding also fails, the returned
    /// error reports both failures and the e-graph has no reuse guarantee.
    ///
    /// If the given rules are malformed, this method can return an error.
    pub fn run_rules(
        &mut self,
        rules: &[RuleId],
        context: ExternalContext<'_>,
    ) -> Result<IterationReport> {
        let thread_pool = self.thread_pool();
        install_thread_pool(thread_pool, || self.run_rules_inner(rules, context))
    }

    /// Run `rules` for one iteration like [`EGraph::run_rules`], but without
    /// rebuilding afterwards. Unions made by the rules are recorded in the
    /// union-find but ids in the tables are not canonicalized until
    /// [`EGraph::rebuild_now`] is called; until then, rebuilding may increase
    /// or decrease table sizes. This lets a runner apply rules one at a time
    /// and rebuild at most once per iteration, as egg does.
    ///
    /// Completed actions are not rolled back on error, and this method does not
    /// rebuild on either success or error; the caller retains responsibility
    /// for calling [`EGraph::rebuild_now`].
    pub fn run_rules_no_rebuild(
        &mut self,
        rules: &[RuleId],
        context: ExternalContext<'_>,
    ) -> Result<IterationReport> {
        let thread_pool = self.thread_pool();
        install_thread_pool(thread_pool, || {
            let ts = self.next_ts();
            let (assembly_time, rule_set_report) = run_rules_impl(
                &mut self.db,
                &mut self.rules,
                rules,
                ts,
                self.report_level,
                context,
            )?;
            if let Some(message) = self.panic_message.lock().unwrap().take() {
                return Err(PanicError(message).into());
            }
            self.inc_ts();
            Ok(IterationReport {
                assembly_time,
                rule_set_report,
                rebuild_time: Duration::ZERO,
            })
        })
    }

    /// Flush the pending update buffers without rebuilding, for use with
    /// [`EGraph::run_rules_no_rebuild`]. Returns `true` if the database is
    /// updated.
    pub fn flush_updates_no_rebuild(&mut self) -> bool {
        let thread_pool = self.thread_pool();
        install_thread_pool(thread_pool, || {
            let updated = self.db.merge_all();
            self.inc_ts();
            updated
        })
    }

    /// Canonicalize the database after deferred-rebuild runs. Returns the time
    /// spent rebuilding.
    pub fn rebuild_now(&mut self) -> Result<Duration> {
        let thread_pool = self.thread_pool();
        install_thread_pool(thread_pool, || {
            let timer = Instant::now();
            self.rebuild()?;
            if let Some(message) = self.panic_message.lock().unwrap().take() {
                return Err(PanicError(message).into());
            }
            Ok(timer.elapsed())
        })
    }

    fn run_rules_inner(
        &mut self,
        rules: &[RuleId],
        context: ExternalContext<'_>,
    ) -> Result<IterationReport> {
        let ts = self.next_ts();

        let uf_size_before = self.db.get_table(self.uf_table).len();
        let (assembly_time, rule_set_report) = run_rules_impl(
            &mut self.db,
            &mut self.rules,
            rules,
            ts,
            self.report_level,
            context,
        )?;
        let panic_message = self.panic_message.lock().unwrap().take();
        if let Some(message) = panic_message {
            let action_error = PanicError(message);

            // Some actions may already have changed the database. Canonicalize
            // those effects before surfacing the catchable egglog error.
            let rebuild_error = self.rebuild().err();
            let rebuild_panic = self.panic_message.lock().unwrap().take();
            let recovery_error = match (rebuild_error, rebuild_panic) {
                (None, None) => return Err(action_error.into()),
                (Some(error), None) => error.to_string(),
                (None, Some(message)) => PanicError(message).to_string(),
                (Some(error), Some(message)) => {
                    format!("{error}; {}", PanicError(message))
                }
            };
            return Err(anyhow::anyhow!(
                "{action_error}; rebuilding after the failed rule action also failed: {recovery_error}"
            ));
        }

        let mut iteration_report = IterationReport {
            assembly_time,
            rule_set_report,
            rebuild_time: Duration::ZERO,
        };
        let uf_size_after = self.db.get_table(self.uf_table).len();
        if uf_size_before == uf_size_after {
            // No new unions: skip the full rebuild but still advance the
            // timestamp so that seminaive evaluation sees a fresh epoch.
            // Rebuilding is only necessary when new unions have been made because ids may need to be updated.
            // Adding terms doesn't necessarily touch the union-find, only doing a union between existing ids does.
            self.inc_ts();
            return Ok(iteration_report);
        }

        let rebuild_timer = Instant::now();
        self.rebuild()?;
        iteration_report.rebuild_time = rebuild_timer.elapsed();

        if let Some(message) = self.panic_message.lock().unwrap().take() {
            return Err(PanicError(message).into());
        }

        Ok(iteration_report)
    }

    fn rebuild(&mut self) -> Result<()> {
        let do_parallel = egglog_concurrency::current_num_threads() > 1;
        if self.db.get_table(self.uf_table).rebuilder(&[]).is_some() {
            // The UF implementation supports "native"  rebuilding.
            let mut tables = Vec::with_capacity(self.funcs.next_id().index());
            for (_, func) in self.funcs.iter() {
                tables.push(func.table);
            }
            loop {
                // Order matters here: we need to rebuild containers first and then rebuild the
                // tables. Why?
                //
                // Say we have a sort that can map to and from a vector containing only itself:
                // (sort X)
                // (function to-vec (X) (Vec X) :no-merge)
                // (constructor from-vec (Vec X) X)
                // (constructor Num (i64) X)
                // (constructor Add (X X) X)
                //
                // Along with rules:
                // (rule ((= x (Num i))) ((set (to-vec x) (vec-of x))))
                // (rule ((= x (Add i j))) ((set (to-vec x) (vec-of x))))
                // (rule ((= x (from-vec v))) ((set (to-vec x) v))
                // (rewrite (Add (Num i) (Num j)) (Num (+ i j)))
                //
                // These rules, while redundant, should be safe. However, if we rebuild tables
                // before containers some schedules can cause us to violate the `:no-merge`
                // directive, which asserts that all values written for a key are equal.
                //
                // Suppose we start off with x1=(Num 1), x2=(Num 3), and x3=(Add (Num 1) (Num 2)) as
                // expressions, with `to-vec` and `from-vec` entries for all three expressions.
                // We'll call (to-vec xi) vi for all i.
                //
                // Now suppose we run the `rewrite` above: now, x3 = x2. But v3 will only equal v2
                // _after_ we rebuild the `Vec` container. That means that if we rebuild `to-vec`
                // we will collapse the the rows for x3 and x2, but then fail to merge v3 and v2
                // because they are not (yet) equal.
                //
                // Rebuilding containers first will find that v3 and v2 are equal, and the rest of
                // the rules can proceed.
                let container_rebuild = self.db.rebuild_containers(self.uf_table);
                let next_ts = self.next_ts().to_value();
                let table_rebuild = self.db.apply_rebuild(self.uf_table, &tables, next_ts);
                // Container rebuild can make a parent row newly matchable without
                // changing the row's stored id. Re-timestamp those parents so
                // seminaive sees the newly enabled match on the next pass.
                let dirty_ids: Vec<Value> = container_rebuild.dirty_ids().iter().copied().collect();
                let refreshed_rows = self
                    .db
                    .refresh_rows_for_values(&tables, &dirty_ids, next_ts);
                self.inc_ts();
                if !table_rebuild && !refreshed_rows && !container_rebuild.changed() {
                    break;
                }
            }
            return Ok(());
        }
        if do_parallel {
            return self.rebuild_parallel();
        }
        let start = Instant::now();

        // The database changed. Rebuild. New entries should land after the given rules.
        let mut changed = true;
        while changed {
            changed = false;
            // We need to iterate rebuilding to a fixed point. Future scans
            // should look only at the latest updates.
            self.inc_ts();
            let ts = self.next_ts();
            for (_, info) in self.funcs.iter_mut() {
                let last_rebuilt_at = self.rules[info.nonincremental_rebuild_rule].last_run_at;
                let table_size = self.db.estimate_size(info.table, None);
                let uf_size = self.db.estimate_size(
                    self.uf_table,
                    Some(Constraint::GeConst {
                        col: ColumnId::new(2),
                        val: last_rebuilt_at.to_value(),
                    }),
                );
                if incremental_rebuild(uf_size, table_size, false) {
                    marker_incremental_rebuild(|| -> Result<()> {
                        // Run each of the incremental rules serially.
                        //
                        // This is to avoid recanonicalizing the same row multiple
                        // times.
                        for rule in &info.incremental_rebuild_rules {
                            changed |= run_rules_impl(
                                &mut self.db,
                                &mut self.rules,
                                &[*rule],
                                ts,
                                ReportLevel::TimeOnly,
                                None,
                            )?
                            .1
                            .changed;
                        }
                        // Reset the rule we did not run. These two should be equivalent.
                        self.rules[info.nonincremental_rebuild_rule].last_run_at = ts;
                        Ok(())
                    })?;
                } else {
                    marker_nonincremental_rebuild(|| -> Result<()> {
                        changed |= run_rules_impl(
                            &mut self.db,
                            &mut self.rules,
                            &[info.nonincremental_rebuild_rule],
                            ts,
                            ReportLevel::TimeOnly,
                            None,
                        )?
                        .1
                        .changed;
                        for rule in &info.incremental_rebuild_rules {
                            self.rules[*rule].last_run_at = ts;
                        }
                        Ok(())
                    })?;
                }
            }
        }
        log::info!("rebuild took {:?}", start.elapsed());
        Ok(())
    }

    /// A variant of `rebuild` that attempts to combine rebuild rules into
    /// larger rulesets to increase parallelism. This kind of preprocessing can
    /// slow processing down in a single-threaded setting, so it is only used
    /// when the number of active threads is greater than 1.
    fn rebuild_parallel(&mut self) -> Result<()> {
        let start = Instant::now();
        #[derive(Default)]
        struct RebuildState {
            nonincremental: Vec<FunctionId>,
            incremental: DenseIdMap<usize, SmallVec<[FunctionId; 2]>>,
        }

        impl RebuildState {
            fn clear(&mut self) {
                self.nonincremental.clear();
                self.incremental.iter_mut().for_each(|(_, v)| v.clear());
            }
        }

        let mut changed = true;
        let mut state = RebuildState::default();
        let mut scratch = Vec::new();
        while changed {
            changed = false;
            state.clear();
            self.inc_ts();
            // First, figure out which functions will be rebuilt nonincrementally,
            // vs. incrementally. Group them together.
            for (func, info) in self.funcs.iter_mut() {
                let last_rebuilt_at = self.rules[info.nonincremental_rebuild_rule].last_run_at;
                let table_size = self.db.estimate_size(info.table, None);
                let uf_size = self.db.estimate_size(
                    self.uf_table,
                    Some(Constraint::GeConst {
                        col: ColumnId::new(2),
                        val: last_rebuilt_at.to_value(),
                    }),
                );
                if incremental_rebuild(uf_size, table_size, true) {
                    for (i, _) in info.incremental_rebuild_rules.iter().enumerate() {
                        state.incremental.get_or_default(i).push(func);
                    }
                } else {
                    state.nonincremental.push(func);
                }
            }
            let ts = self.next_ts();
            for func in state.nonincremental.iter().copied() {
                scratch.push(self.funcs[func].nonincremental_rebuild_rule);
                for rule in &self.funcs[func].incremental_rebuild_rules {
                    self.rules[*rule].last_run_at = ts;
                }
            }
            changed |= run_rules_impl(
                &mut self.db,
                &mut self.rules,
                &scratch,
                ts,
                ReportLevel::TimeOnly,
                None,
            )?
            .1
            .changed;
            scratch.clear();
            let ts = self.next_ts();
            for (i, funcs) in state.incremental.iter() {
                for func in funcs.iter().copied() {
                    let info = &mut self.funcs[func];
                    scratch.push(info.incremental_rebuild_rules[i]);
                    self.rules[info.nonincremental_rebuild_rule].last_run_at = ts;
                }
                changed |= run_rules_impl(
                    &mut self.db,
                    &mut self.rules,
                    &scratch,
                    ts,
                    ReportLevel::TimeOnly,
                    None,
                )?
                .1
                .changed;
                scratch.clear();
            }
        }
        log::info!("rebuild took {:?}", start.elapsed());
        Ok(())
    }

    fn incremental_rebuild_rules(&mut self, table: FunctionId, schema: &[ColumnTy]) -> Vec<RuleId> {
        schema
            .iter()
            .enumerate()
            .filter_map(|(i, ty)| match ty {
                ColumnTy::Id => {
                    Some(self.incremental_rebuild_rule(table, schema, ColumnId::from_usize(i)))
                }
                ColumnTy::Base(_) => None,
            })
            .collect()
    }

    fn inert_rebuild_rule(&mut self, table: FunctionId) -> RuleId {
        self.new_rule(&format!("inert rebuild {table:?}"), false)
            .build()
    }

    fn incremental_rebuild_rule(
        &mut self,
        table: FunctionId,
        schema: &[ColumnTy],
        col: ColumnId,
    ) -> RuleId {
        let subsume = self.funcs[table].can_subsume;
        let table_id = self.funcs[table].table;
        let uf_table = self.uf_table;
        // Two atoms, one binding a whole tuple, one binding a displaced column
        let mut rb = self.new_rule(&format!("incremental rebuild {table:?}, {col:?}"), true);
        rb.set_plan_strategy(PlanStrategy::MinCover);
        let mut vars = Vec::<QueryEntry>::with_capacity(schema.len());
        for ty in schema {
            vars.push(rb.new_var(*ty).into());
        }
        let canon_val: QueryEntry = rb.new_var(ColumnTy::Id).into();
        let subsume_var = subsume.then(|| rb.new_var(ColumnTy::Id));
        rb.add_atom_with_timestamp_and_func(
            table_id,
            Some(table),
            subsume_var.clone().map(QueryEntry::from),
            &vars,
        );
        rb.add_atom_with_timestamp_and_func(
            uf_table,
            None,
            None,
            &[vars[col.index()].clone(), canon_val.clone()],
        );
        rb.set_focus(1); // Set the uf atom as the sole focus.

        // Now canonicalize the entire row.
        let mut canon = Vec::<QueryEntry>::with_capacity(schema.len());
        for (i, (var, ty)) in vars.iter().zip(schema.iter()).enumerate() {
            canon.push(if i == col.index() {
                canon_val.clone()
            } else if let ColumnTy::Id = ty {
                rb.lookup_uf(var.clone()).unwrap().into()
            } else {
                var.clone()
            })
        }

        // Remove the old row and insert the new one.
        rb.rebuild_row(table, &vars, &canon, subsume_var);
        rb.build()
    }

    fn nonincremental_rebuild(&mut self, table: FunctionId, schema: &[ColumnTy]) -> RuleId {
        let can_subsume = self.funcs[table].can_subsume;
        let table_id = self.funcs[table].table;
        let mut rb = self.new_rule(&format!("nonincremental rebuild {table:?}"), false);
        rb.set_plan_strategy(PlanStrategy::MinCover);
        let mut vars = Vec::<QueryEntry>::with_capacity(schema.len());
        for ty in schema {
            vars.push(rb.new_var(*ty).into());
        }
        let subsume_var = can_subsume.then(|| rb.new_var(ColumnTy::Id));
        rb.add_atom_with_timestamp_and_func(
            table_id,
            Some(table),
            subsume_var.clone().map(QueryEntry::from),
            &vars,
        );
        let mut lhs = SmallVec::<[QueryEntry; 4]>::new();
        let mut rhs = SmallVec::<[QueryEntry; 4]>::new();
        let mut canon = Vec::<QueryEntry>::with_capacity(schema.len());
        for (var, ty) in vars.iter().zip(schema.iter()) {
            canon.push(if let ColumnTy::Id = ty {
                lhs.push(var.clone());
                let canon_var = QueryEntry::from(rb.lookup_uf(var.clone()).unwrap());
                rhs.push(canon_var.clone());
                canon_var
            } else {
                var.clone()
            })
        }
        rb.check_for_update(&lhs, &rhs).unwrap();
        rb.rebuild_row(table, &vars, &canon, subsume_var);
        rb.build()
    }

    /// Gives the user a handle to the underlying ExecutionState. Useful for staging updates
    /// to the database.
    ///
    /// The staged updates are not immediately reflected in the EGraph, so you may want to
    /// manually flush the updates using [`EGraph::flush_updates`].
    ///
    /// `context` is visible to any external function the closure reaches; pass
    /// `None` if there is nothing to share.
    ///
    /// # Seminaive-safety trust boundary
    ///
    /// This method hands out a raw `&mut ExecutionState`, which bypasses
    /// the egglog crate's `Read` / `Write` capability wrappers
    /// (`PureState`, `WriteState`, `ReadState`, `FullState`) that
    /// enforce #772's seminaive-safety model. Treat it as top-level
    /// / global-action context: appropriate for one-shot database
    /// manipulation from outside any rule, not for use inside
    /// primitive implementations.
    pub fn with_execution_state<R>(
        &self,
        context: ExternalContext<'_>,
        f: impl FnOnce(&mut ExecutionState<'_>) -> R,
    ) -> R {
        let thread_pool = self.thread_pool();
        install_thread_pool(thread_pool, || self.db.with_execution_state(context, f))
    }

    /// Like [`EGraph::with_execution_state`], but also reports whether `f`
    /// staged any mutation. A read-only closure leaves the flag `false`, so
    /// callers can skip a [`EGraph::flush_updates`] that would otherwise be a
    /// no-op merge plus a spurious timestamp bump.
    pub fn with_execution_state_tracked<R>(
        &self,
        context: ExternalContext<'_>,
        f: impl FnOnce(&mut ExecutionState<'_>) -> R,
    ) -> (R, bool) {
        let thread_pool = self.thread_pool();
        install_thread_pool(thread_pool, || {
            self.db.with_execution_state_tracked(context, f)
        })
    }

    /// Flush the pending update buffers to the EGraph.
    /// Returns `true` if the database is updated.
    pub fn flush_updates(&mut self) -> bool {
        let thread_pool = self.thread_pool();
        install_thread_pool(thread_pool, || self.flush_updates_inner())
    }

    fn flush_updates_inner(&mut self) -> bool {
        let uf_size_before = self.db.get_table(self.uf_table).len();
        let updated = self.db.merge_all();
        self.inc_ts();
        let uf_size_after = self.db.get_table(self.uf_table).len();
        if uf_size_before != uf_size_after {
            // Rebuilding is only necessary when new unions have been made because ids may need to be updated.
            // Adding terms doesn't necessarily touch the union-find, only doing a union between existing ids does.
            self.rebuild().unwrap();
        }
        updated
    }

    pub fn set_report_level(&mut self, level: ReportLevel) {
        self.report_level = level;
    }
}

#[derive(Clone)]
struct RuleInfo {
    last_run_at: Timestamp,
    query: rule::Query,
    cached_plan: Option<CachedPlanInfo>,
    desc: Arc<str>,
}

#[derive(Clone)]
struct CachedPlanInfo {
    plan: Arc<core_relations::CachedPlan>,
    /// A mapping from index into a [`rule::Query`]'s atoms to the atoms in the underlying cached
    /// plan.
    atom_mapping: Vec<core_relations::AtomId>,
}

#[derive(Clone)]
struct FunctionInfo {
    table: TableId,
    schema: Vec<ColumnTy>,
    /// The number of key (input) columns. The remaining columns of `schema` are value/return
    /// columns (one for most functions, more for tuple-output functions).
    n_keys: usize,
    /// Opt-in identity-column guard (see [`FunctionConfig::n_identity_vals`]).
    n_identity_vals: Option<usize>,
    incremental_rebuild_rules: Vec<RuleId>,
    nonincremental_rebuild_rule: RuleId,
    default_val: DefaultVal,
    can_subsume: bool,
    name: Arc<str>,
    /// User-visible row projection. This equals the physical layout unless the
    /// table is an encoded view with internal columns.
    read_projection: TableReadProjection,
}

impl FunctionInfo {
    fn schema_math(&self) -> SchemaMath {
        SchemaMath {
            subsume: self.can_subsume,
            n_keys: self.n_keys,
            func_cols: self.schema.len(),
            n_identity_vals: self.n_identity_vals,
        }
    }
}

impl FunctionInfo {
    fn ret_ty(&self) -> ColumnTy {
        self.schema.last().copied().unwrap()
    }
}

/// How defaults are computed for the given function.
#[derive(Copy, Clone)]
pub enum DefaultVal {
    /// Generate a fresh UF id.
    FreshId,
    /// Cause an egglog-level panic if a lookup fails.
    Fail,
    /// Insert a constant of some kind.
    Const(Value),
}

/// How to resolve FD conflicts for a table.
pub enum MergeFn {
    /// Panic if the old and new values don't match.
    AssertEq,
    /// Use congruence to resolve FD conflicts.
    UnionId,
    /// The output of a merge is determined by applying the given ExternalFunction to the result
    /// of the argument merge functions.
    Primitive(ExternalFunctionId, Vec<MergeFn>),
    /// The output of a merge is determined by looking up the value for the given function and the
    /// given arguments in the egraph.
    Function(FunctionId, Vec<MergeFn>),
    /// Always return the old value for the given function (this column's old value).
    Old,
    /// Always return the new value for the given function (this column's new value).
    New,
    /// The old value of the `i`th value column. Used by tuple-output merges, where a column's
    /// merge may reference any output column of the old row.
    OldCol(usize),
    /// The new value of the `i`th value column.
    NewCol(usize),
    /// The value bound by a preceding `let` action in a [`MergeFn::Block`], identified by its slot
    /// (0-based, assigned in block order). Reads the per-invocation merge environment.
    LetVar(usize),
    /// Always overwrite the new value for the given function with a constant. This is more useful
    /// as a "base case" in a more complicated merge function (e.g. one that clamps a value between
    /// 1 and 100) than it is as a standalone merge function.
    Const(Value),
    /// A merge for a tuple-output function: one [`MergeFn`] per value column. Each inner
    /// `MergeFn` produces that column's merged value and may reference any column via
    /// [`MergeFn::OldCol`] / [`MergeFn::NewCol`]. The length determines the number of value
    /// columns of the function.
    Columns(Vec<MergeFn>),
    /// Look up (minting on miss, like a constructor) the value of a function call, as a merge value
    /// expression — e.g. building a proof term. `args` evaluate to the key columns; uses
    /// `lookup_or_insert` on the target's own merge.
    Lookup(FunctionId, Vec<MergeFn>),
    /// A value-producing action block: run `actions` for their effects, then evaluate `result` to
    /// the merged value(s). This is the merge form for merges that perform side effects (e.g.
    /// staging a union). Ordinary merges have no actions. Only valid at the top level of a merge.
    Block {
        actions: Vec<MergeAction>,
        result: Box<MergeFn>,
    },
}

/// A side effect run by a [`MergeFn::Block`] before its result is evaluated.
pub enum MergeAction {
    /// `(set (f keys...) vals...)` inside a merge: stage a full row (`args` = keys ++ values) into
    /// the function's table, respecting that table's own merge.
    Set(FunctionId, Vec<MergeFn>),
    /// `(let x <value>)` inside a merge: evaluate `value` and bind it to `slot` of the merge
    /// environment (slots are assigned in block order), so later actions and the result can read it
    /// via [`MergeFn::LetVar`].
    Let { slot: usize, value: MergeFn },
    /// `(union a b)` inside a merge: union the two eclasses (stages into the union-find). Only
    /// meaningful for eq-sort outputs; action-block merges are rejected under proofs, so this never
    /// runs against the proof union-find.
    Union(MergeFn, MergeFn),
}

impl MergeFn {
    fn fill_deps(
        &self,
        egraph: &EGraph,
        read_deps: &mut IndexSet<TableId>,
        write_deps: &mut IndexSet<TableId>,
    ) {
        use MergeFn::*;
        match self {
            Primitive(id, args) => {
                args.iter()
                    .for_each(|arg| arg.fill_deps(egraph, read_deps, write_deps));
                write_deps.insert(egraph.uf_table);
                // A primitive that inserts rows writes its table just as a
                // `set` on it would, and the merge must be ordered and
                // buffered against that table the same way.
                if let Some(table) = egraph.external_write_table(*id) {
                    write_deps.insert(table);
                }
            }
            Function(func, args) => {
                read_deps.insert(egraph.funcs[*func].table);
                write_deps.insert(egraph.funcs[*func].table);
                args.iter()
                    .for_each(|arg| arg.fill_deps(egraph, read_deps, write_deps));
            }
            UnionId => {
                write_deps.insert(egraph.uf_table);
            }
            Columns(cols) => {
                cols.iter()
                    .for_each(|col| col.fill_deps(egraph, read_deps, write_deps));
            }
            Lookup(func, args) => {
                read_deps.insert(egraph.funcs[*func].table);
                write_deps.insert(egraph.funcs[*func].table);
                args.iter()
                    .for_each(|arg| arg.fill_deps(egraph, read_deps, write_deps));
            }
            Block { actions, result } => {
                actions
                    .iter()
                    .for_each(|a| a.fill_deps(egraph, read_deps, write_deps));
                result.fill_deps(egraph, read_deps, write_deps);
            }
            AssertEq | Old | New | OldCol(..) | NewCol(..) | LetVar(..) | Const(..) => {}
        }
    }

    /// Assert that every `OldCol(i)`/`NewCol(i)` references a real value column (`i < n_vals`).
    /// An out-of-range index would otherwise read a timestamp/subsume column or panic during merge
    /// execution; this surfaces the mistake at table-creation time with a clear message.
    fn check_value_col_indices(&self, n_vals: usize, name: &str) {
        use MergeFn::*;
        let check = |i: usize, kind: &str| {
            assert!(
                i < n_vals,
                "merge for `{name}` references {kind}({i}), but the function has only {n_vals} value column(s)"
            );
        };
        match self {
            OldCol(i) => check(*i, "OldCol"),
            NewCol(i) => check(*i, "NewCol"),
            Primitive(_, args) | Function(_, args) | Columns(args) | Lookup(_, args) => args
                .iter()
                .for_each(|a| a.check_value_col_indices(n_vals, name)),
            Block { actions, result } => {
                actions
                    .iter()
                    .for_each(|a| a.check_value_col_indices(n_vals, name));
                result.check_value_col_indices(n_vals, name);
            }
            AssertEq | Old | New | UnionId | LetVar(..) | Const(..) => {}
        }
    }

    fn to_callback(
        &self,
        schema_math: SchemaMath,
        function_name: &str,
        egraph: &mut EGraph,
    ) -> Box<core_relations::MergeFn> {
        // Split the merge into side-effect actions (run once) and one value expression per value
        // column. Only a top-level `Block` carries actions; `Columns` gives the per-column values.
        let (action_srcs, col_srcs): (&[MergeAction], Vec<&MergeFn>) = match self {
            MergeFn::Block { actions, result } => (actions.as_slice(), result.columns()),
            other => (&[], other.columns()),
        };
        let actions: Vec<ResolvedMergeAction> = action_srcs
            .iter()
            .map(|a| a.resolve(function_name, egraph))
            .collect();
        let resolved: Vec<ResolvedMergeFn> = col_srcs
            .iter()
            .map(|c| c.resolve(function_name, egraph))
            .collect();
        assert_eq!(
            resolved.len(),
            schema_math.n_vals(),
            "merge for {function_name} must have one entry per value column"
        );

        Box::new(move |state, cur, new, out| {
            // Identity/payload columns: when a collision leaves every identity value column
            // unchanged it is not a real value conflict, so keep the existing value columns (and
            // skip the actions) instead of running the merge — which would, e.g., stage a spurious
            // union. A subsume-flag change is still applied below, so this stays correct for
            // subsumable functions. Inert unless the function declares payload columns.
            let identity_unchanged = match schema_math.n_identity_vals {
                Some(k) => {
                    let id_lo = schema_math.n_keys;
                    cur[id_lo..id_lo + k] == new[id_lo..id_lo + k]
                }
                None => false,
            };

            let timestamp = new[schema_math.ts_col()];

            // Environment for `let`-bound values, filled by `Let` actions in slot order and read by
            // `LetVar` in later actions / the result. Empty (no allocation) unless the block uses
            // `let`.
            let mut env = SmallVec::<[Value; 4]>::new();

            // Run the block's side effects once, before computing the merged values.
            if !identity_unchanged {
                for action in &actions {
                    action.run(state, cur, new, schema_math.n_keys, timestamp, &mut env);
                }
            }

            let mut changed = false;

            // Compute each merged value column. `cur` and `new` are full rows, so a tuple-output
            // column's merge may reference any output column via `OldCol`/`NewCol`.
            let mut merged_vals = SmallVec::<[Value; 4]>::new();
            for (i, col_merge) in resolved.iter().enumerate() {
                let out_val = if identity_unchanged {
                    cur[schema_math.val_col(i)]
                } else {
                    col_merge.run(state, cur, new, schema_math.n_keys, i, timestamp, &env)
                };
                changed |= cur[schema_math.val_col(i)] != out_val;
                merged_vals.push(out_val);
            }

            let subsume = schema_math.subsume.then(|| {
                let cur = cur[schema_math.subsume_col()];
                let new = new[schema_math.subsume_col()];
                let out = combine_subsumed(cur, new);
                changed |= cur != out;
                out
            });
            if changed {
                out.extend_from_slice(new);
                for (i, val) in merged_vals.iter().enumerate() {
                    out[schema_math.val_col(i)] = *val;
                }
                schema_math.write_table_row(
                    out,
                    RowVals {
                        timestamp,
                        subsume,
                        ret_val: None,
                    },
                );
            }

            changed
        })
    }

    /// Resolve this merge into one [`ResolvedMergeFn`] per value column. Single-value merges
    /// (the common case) resolve to a one-element vector; [`MergeFn::Columns`] resolves to one
    /// entry per column.
    /// The per-value-column value expressions of this merge (`Columns` → its entries; any other
    /// merge is a single column). `Block` is peeled off by `to_callback` and never reaches here.
    fn columns(&self) -> Vec<&MergeFn> {
        match self {
            MergeFn::Columns(cols) => cols.iter().collect(),
            other => vec![other],
        }
    }

    fn resolve(&self, function_name: &str, egraph: &mut EGraph) -> ResolvedMergeFn {
        match self {
            MergeFn::Const(v) => ResolvedMergeFn::Const(*v),
            MergeFn::Old => ResolvedMergeFn::Old,
            MergeFn::New => ResolvedMergeFn::New,
            MergeFn::OldCol(i) => ResolvedMergeFn::OldCol(*i),
            MergeFn::NewCol(i) => ResolvedMergeFn::NewCol(*i),
            MergeFn::LetVar(slot) => ResolvedMergeFn::LetVar(*slot),
            MergeFn::Columns(_) => {
                panic!("nested Columns merge is not supported (Columns must be top-level)")
            }
            MergeFn::AssertEq => ResolvedMergeFn::AssertEq {
                panic: egraph.new_panic(format!(
                    "Illegal merge attempted for function {function_name}"
                )),
            },
            MergeFn::UnionId => ResolvedMergeFn::UnionId {
                uf_table: egraph.uf_table,
            },
            // NB: The primitive and function-based merge functions heap allocate a single callback
            // for each layer of nesting. This introduces a bit of overhead, particularly for cases
            // that look like `(f old new)` or `(f new old)`. We could special-case common cases in
            // this function if that overhead shows up.
            MergeFn::Primitive(prim, args) => ResolvedMergeFn::Primitive {
                prim: *prim,
                args: args
                    .iter()
                    .map(|arg| arg.resolve(function_name, egraph))
                    .collect::<Vec<_>>(),
                panic: egraph.new_panic(format!(
                    "Merge function for {function_name} primitive call failed"
                )),
            },
            MergeFn::Function(func, args) => {
                let func_info = &egraph.funcs[*func];
                assert_eq!(
                    func_info.schema.len(),
                    args.len() + 1,
                    "Merge function for {function_name} must match function arity for {}",
                    func_info.name
                );
                ResolvedMergeFn::Function {
                    func: TableAction::new(egraph, *func),
                    panic: egraph.new_panic(format!(
                        "Lookup on {} failed in the merge function for {function_name}",
                        func_info.name
                    )),
                    args: args
                        .iter()
                        .map(|arg| arg.resolve(function_name, egraph))
                        .collect::<Vec<_>>(),
                }
            }
            MergeFn::Lookup(func, args) => ResolvedMergeFn::Lookup {
                table: TableAction::new(egraph, *func),
                args: args
                    .iter()
                    .map(|arg| arg.resolve(function_name, egraph))
                    .collect::<Vec<_>>(),
            },
            MergeFn::Block { .. } => {
                panic!("nested Block merge is not supported (Block must be top-level)")
            }
        }
    }
}

/// This enum is taking the place of a
/// `Box<dyn Fn(&mut ExecutionState, Value, Value, Value) -> Value + Send + Sync>`
/// to avoid extra boxes. It stores the data needed to run a `MergeFn` without
/// holding onto any references, so it can be `move`d inside the `core_relations::MergeFn`.
enum ResolvedMergeFn {
    Const(Value),
    Old,
    New,
    OldCol(usize),
    NewCol(usize),
    /// Read slot `.0` of the per-invocation merge environment (a preceding `let`).
    LetVar(usize),
    AssertEq {
        panic: ExternalFunctionId,
    },
    UnionId {
        uf_table: TableId,
    },
    Primitive {
        prim: ExternalFunctionId,
        args: Vec<ResolvedMergeFn>,
        panic: ExternalFunctionId,
    },
    Function {
        func: TableAction,
        args: Vec<ResolvedMergeFn>,
        panic: ExternalFunctionId,
    },
    /// Look up / mint a function value inside a merge value expression (mint on miss, like a
    /// constructor), via `lookup_or_insert`.
    Lookup {
        table: TableAction,
        args: Vec<ResolvedMergeFn>,
    },
}

/// A resolved side effect run by a [`MergeFn::Block`] before its result is evaluated.
enum ResolvedMergeAction {
    /// `(set (f keys...) vals...)`: stage the full row `args` into `table`, respecting its merge.
    Set {
        table: TableAction,
        args: Vec<ResolvedMergeFn>,
    },
    /// `(let x <value>)`: evaluate `value` and push it onto the environment (its slot equals the
    /// current environment length, since `let`s run in slot order).
    Let { slot: usize, value: ResolvedMergeFn },
    /// `(union a b)`: stage a union of the two eclasses into the union-find.
    Union {
        a: ResolvedMergeFn,
        b: ResolvedMergeFn,
        uf_table: TableId,
    },
}

impl MergeAction {
    fn fill_deps(
        &self,
        egraph: &EGraph,
        read_deps: &mut IndexSet<TableId>,
        write_deps: &mut IndexSet<TableId>,
    ) {
        match self {
            MergeAction::Set(func, args) => {
                write_deps.insert(egraph.funcs[*func].table);
                args.iter()
                    .for_each(|arg| arg.fill_deps(egraph, read_deps, write_deps));
            }
            MergeAction::Let { value, .. } => value.fill_deps(egraph, read_deps, write_deps),
            MergeAction::Union(a, b) => {
                a.fill_deps(egraph, read_deps, write_deps);
                b.fill_deps(egraph, read_deps, write_deps);
                write_deps.insert(egraph.uf_table);
            }
        }
    }

    fn check_value_col_indices(&self, n_vals: usize, name: &str) {
        match self {
            MergeAction::Set(_, args) => args
                .iter()
                .for_each(|a| a.check_value_col_indices(n_vals, name)),
            MergeAction::Let { value, .. } => value.check_value_col_indices(n_vals, name),
            MergeAction::Union(a, b) => {
                a.check_value_col_indices(n_vals, name);
                b.check_value_col_indices(n_vals, name);
            }
        }
    }

    fn resolve(&self, function_name: &str, egraph: &mut EGraph) -> ResolvedMergeAction {
        match self {
            MergeAction::Set(func, args) => ResolvedMergeAction::Set {
                table: TableAction::new(egraph, *func),
                args: args
                    .iter()
                    .map(|arg| arg.resolve(function_name, egraph))
                    .collect::<Vec<_>>(),
            },
            MergeAction::Let { slot, value } => ResolvedMergeAction::Let {
                slot: *slot,
                value: value.resolve(function_name, egraph),
            },
            MergeAction::Union(a, b) => ResolvedMergeAction::Union {
                a: a.resolve(function_name, egraph),
                b: b.resolve(function_name, egraph),
                uf_table: egraph.uf_table,
            },
        }
    }
}

impl ResolvedMergeAction {
    fn run(
        &self,
        state: &mut ExecutionState,
        cur: &[Value],
        new: &[Value],
        n_keys: usize,
        ts: Value,
        env: &mut SmallVec<[Value; 4]>,
    ) {
        // Action value expressions use explicit `OldCol`/`NewCol`, so `self_col` is irrelevant
        // (pass 0).
        match self {
            ResolvedMergeAction::Set { table, args } => {
                // `insert` respects the target table's own merge.
                let row = args
                    .iter()
                    .map(|arg| arg.run(state, cur, new, n_keys, 0, ts, env))
                    .collect::<Vec<_>>();
                table.insert(state, row.into_iter());
            }
            ResolvedMergeAction::Let { slot, value } => {
                let v = value.run(state, cur, new, n_keys, 0, ts, env);
                // `let`s run in slot order, so the new binding lands at `slot`.
                debug_assert_eq!(*slot, env.len());
                env.push(v);
            }
            ResolvedMergeAction::Union { a, b, uf_table } => {
                let av = a.run(state, cur, new, n_keys, 0, ts, env);
                let bv = b.run(state, cur, new, n_keys, 0, ts, env);
                if av != bv {
                    state.stage_insert(*uf_table, &[av, bv, ts]);
                }
            }
        }
    }
}

impl ResolvedMergeFn {
    /// Compute the merged value for value column `self_col`.
    ///
    /// `cur` and `new` are the full conflicting rows. `n_keys` is the number of key columns, so
    /// value column `i` lives at `cur[n_keys + i]`. `Old`/`New` refer to `self_col`'s value, while
    /// `OldCol`/`NewCol` reference an explicit column — this lets a tuple-output column's merge
    /// read any other output column. `env` holds `let`-bound values (read by `LetVar`).
    #[allow(clippy::too_many_arguments)]
    fn run(
        &self,
        state: &mut ExecutionState,
        cur: &[Value],
        new: &[Value],
        n_keys: usize,
        self_col: usize,
        ts: Value,
        env: &[Value],
    ) -> Value {
        match self {
            ResolvedMergeFn::Const(v) => *v,
            ResolvedMergeFn::Old => cur[n_keys + self_col],
            ResolvedMergeFn::New => new[n_keys + self_col],
            ResolvedMergeFn::OldCol(i) => cur[n_keys + i],
            ResolvedMergeFn::NewCol(i) => new[n_keys + i],
            ResolvedMergeFn::LetVar(slot) => env[*slot],
            ResolvedMergeFn::AssertEq { panic } => {
                let (cur, new) = (cur[n_keys + self_col], new[n_keys + self_col]);
                if cur != new {
                    let res = state.call_external_func(*panic, &[]);
                    assert_eq!(res, None);
                }
                cur
            }
            ResolvedMergeFn::UnionId { uf_table } => {
                let (cur, new) = (cur[n_keys + self_col], new[n_keys + self_col]);
                if cur != new {
                    state.stage_insert(*uf_table, &[cur, new, ts]);
                    // We pick the minimum when unioning. This matches the original egglog
                    // behavior. THIS MUST MATCH THE UNION-FIND IMPLEMENTATION!
                    std::cmp::min(cur, new)
                } else {
                    cur
                }
            }
            // NB: The primitive and function-based merge functions heap allocate a single callback
            // for each layer of nesting. This introduces a bit of overhead, particularly for cases
            // that look like `(f old new)` or `(f new old)`. We could special-case common cases in
            // this function if that overhead shows up.
            ResolvedMergeFn::Primitive { prim, args, panic } => {
                let args = args
                    .iter()
                    .map(|arg| arg.run(state, cur, new, n_keys, self_col, ts, env))
                    .collect::<Vec<_>>();

                match state.call_external_func(*prim, &args) {
                    Some(result) => result,
                    None => {
                        let res = state.call_external_func(*panic, &[]);
                        assert_eq!(res, None);
                        cur[n_keys + self_col]
                    }
                }
            }
            ResolvedMergeFn::Function { func, args, panic } => {
                // see github.com/egraphs-good/egglog/pull/287
                if cur[n_keys + self_col] == new[n_keys + self_col] {
                    return cur[n_keys + self_col];
                }

                let args = args
                    .iter()
                    .map(|arg| arg.run(state, cur, new, n_keys, self_col, ts, env))
                    .collect::<Vec<_>>();

                // Merge functions dispatch to another function that may be
                // a constructor (mint fresh id on miss) or a custom function
                // (return `None` → panic). `lookup_or_insert` preserves
                // both behaviors; the pure-read `lookup` would skip
                // constructor minting.
                func.lookup_or_insert(state, &args).unwrap_or_else(|| {
                    let res = state.call_external_func(*panic, &[]);
                    assert_eq!(res, None);
                    cur[n_keys + self_col]
                })
            }
            ResolvedMergeFn::Lookup { table, args } => {
                let key = args
                    .iter()
                    .map(|arg| arg.run(state, cur, new, n_keys, self_col, ts, env))
                    .collect::<SmallVec<[Value; 4]>>();
                // A constructor mints its (single) output on miss; no extra value columns.
                table
                    .lookup_or_insert_multi(state, &key, &[])
                    .unwrap_or(cur[n_keys + self_col])
            }
        }
    }
}

/// Coarse classification of a table — `Constructor` mints a fresh
/// eclass id when a row is missed; `Function` does not. Mirrors the
/// `FunctionSubtype` split on the egglog side without dragging that
/// type into the bridge crate.
#[derive(Debug, Copy, Clone, Eq, PartialEq, Hash)]
pub enum TableKind {
    Function,
    Constructor,
}

impl TableKind {
    /// How this kind of table is spelled in a program, and in diagnostics.
    pub fn label(self) -> &'static str {
        match self {
            TableKind::Function => "function",
            TableKind::Constructor => "constructor",
        }
    }
}

/// User-visible table shape used by read-only, name-indexed APIs.
#[derive(Debug, Copy, Clone, Eq, PartialEq, Hash)]
struct TableReadProjection {
    kind: TableKind,
    input_arity: usize,
    output_arity: usize,
}

/// A requested read operation does not apply to the table's visible shape.
#[derive(Debug, Copy, Clone, Eq, PartialEq, Hash)]
#[doc(hidden)]
pub enum TableReadProjectionError {
    WrongKind { actual: TableKind },
    MultipleOutputs,
}

/// This is an intern-able struct that holds all the data needed
/// to do table operations with an [`ExecutionState`], assuming
/// that the [`FunctionId`] for the table is known ahead of time.
#[derive(Debug, PartialEq, Eq, Hash, Clone)]
pub struct TableAction {
    table: TableId,
    // A self-referential merge is resolved before its backing table is installed.
    // Its internal actions need only the reserved TableId; name-indexed handles
    // are created after installation and must have an allocation identity.
    identity: Option<TableIdentity>,
    name: Arc<str>,
    table_math: SchemaMath,
    default: Option<MergeVal>,
    timestamp: CounterId,
    /// Physical classification used by write operations.
    kind: TableKind,
    /// User-visible row projection. This equals the physical layout unless the
    /// table is an encoded view with internal columns.
    read_projection: TableReadProjection,
}

impl TableAction {
    /// Create a new `TableAction` to be used later.
    /// This requires access to the `egglog_bridge::EGraph`.
    pub fn new(egraph: &EGraph, func: FunctionId) -> TableAction {
        let func_info = &egraph.funcs[func];
        let kind = match &func_info.default_val {
            DefaultVal::FreshId => TableKind::Constructor,
            DefaultVal::Fail | DefaultVal::Const(_) => TableKind::Function,
        };
        TableAction {
            table: func_info.table,
            identity: egraph.db.table_identity(func_info.table),
            name: Arc::clone(&func_info.name),
            table_math: func_info.schema_math(),
            default: match &func_info.default_val {
                DefaultVal::FreshId => Some(MergeVal::Counter(egraph.id_counter)),
                DefaultVal::Fail => None,
                DefaultVal::Const(val) => Some(MergeVal::Constant(*val)),
            },
            timestamp: egraph.timestamp_counter,
            kind,
            read_projection: func_info.read_projection,
        }
    }

    /// Whether this still names the same table allocation in `state`.
    ///
    /// A table declared inside a `push` is dropped by the corresponding `pop`.
    /// Its [`TableId`] may then be reused by a different table, while handles
    /// handed out before the pop still hold the old id.
    pub fn is_live(&self, state: &ExecutionState) -> bool {
        self.identity.is_some()
            && state.table_identity(self.table) == self.identity
            && state.table_name(self.table) == Some(self.name.as_ref())
    }

    /// Whether this physical table is a `Function` (no auto-insert) or a
    /// `Constructor` (mints a fresh eclass id on miss).
    pub fn kind(&self) -> TableKind {
        self.kind
    }

    /// Number of physical input (key) columns.
    pub fn input_arity(&self) -> usize {
        self.table_math.num_keys()
    }

    /// Number of physical output (value) columns.
    pub fn output_arity(&self) -> usize {
        self.table_math.n_vals()
    }

    /// Validate a read operation against the user-visible kind and output
    /// shape, returning the input arity needed for its arity check. Physical
    /// kind/arity remain available separately for write operations.
    #[doc(hidden)]
    pub fn validate_read_projection(
        &self,
        expected_kind: Option<TableKind>,
        require_single_output: bool,
    ) -> std::result::Result<usize, TableReadProjectionError> {
        if expected_kind.is_some_and(|expected| expected != self.read_projection.kind) {
            return Err(TableReadProjectionError::WrongKind {
                actual: self.read_projection.kind,
            });
        }
        if require_single_output && self.read_projection.output_arity != 1 {
            return Err(TableReadProjectionError::MultipleOutputs);
        }
        Ok(self.read_projection.input_arity)
    }

    /// Look up the output selected by the user-visible row projection. The
    /// common layout remains a direct keyed lookup; layouts whose visible key
    /// differs from the physical key fall back to a projected scan.
    #[doc(hidden)]
    pub fn lookup_visible(&self, state: &ExecutionState, key: &[Value]) -> Option<Value> {
        debug_assert_eq!(key.len(), self.read_projection.input_arity);
        let physical_input_arity = self.table_math.num_keys();
        if physical_input_arity == self.read_projection.input_arity {
            return self.lookup_value_col(state, key, 0);
        }

        let mut found = None;
        self.for_each_visible_while(state, |inputs, output, _| {
            if inputs == key {
                found = Some(output);
                false
            } else {
                true
            }
        });
        found
    }

    /// Look up value column `col_idx` for `key`, or `None` if the key is absent.
    /// This is a pure read and never inserts a default row.
    pub fn lookup_value_col(
        &self,
        state: &ExecutionState,
        key: &[Value],
        col_idx: usize,
    ) -> Option<Value> {
        // The timestamp column sits right after the value columns, so an
        // out-of-range `col_idx` would read one of the table's own bookkeeping
        // columns back as a value.
        debug_assert!(
            col_idx < self.table_math.n_vals(),
            "value column {col_idx} is past this table's {} value columns",
            self.table_math.n_vals()
        );
        state.get_table(self.table).get_row_column(
            key,
            ColumnId::from_usize(self.table_math.num_keys() + col_idx),
        )
    }

    /// Look up all output columns for `key`. This is a pure read and never
    /// inserts a default row.
    pub fn lookup_values(&self, state: &ExecutionState, key: &[Value]) -> Option<Vec<Value>> {
        state
            .get_table(self.table)
            .get_row(key)
            .map(|row| row.vals[self.table_math.num_keys()..self.table_math.func_cols].to_vec())
    }

    /// Look up a row and return its return-value column, or `None` if the
    /// key is not present. **This is a pure read**: it never inserts a row,
    /// regardless of the table's configured [`DefaultVal`].
    ///
    /// For the lookup-or-insert behavior that mints fresh eclass IDs for
    /// constructors, use [`TableAction::lookup_or_insert`].
    pub fn lookup(&self, state: &ExecutionState, key: &[Value]) -> Option<Value> {
        self.lookup_values(state, key).map(|values| values[0])
    }

    /// Return the current number of rows in this table.
    pub fn row_count(&self, state: &ExecutionState) -> usize {
        state.get_table(self.table).len()
    }

    /// Iterate this table's rows, calling `f` on each function row.
    /// Mirrors [`EGraph::for_each`] but reaches the table through an
    /// [`ExecutionState`] — so it's callable from primitive bodies via
    /// the typed `Read`-style API.
    pub fn for_each(&self, state: &ExecutionState, mut f: impl FnMut(ScanEntry<'_>)) {
        self.for_each_while(state, |row| {
            f(row);
            true
        });
    }

    /// Like [`TableAction::for_each`], but stops as soon as `f`
    /// returns `false`.
    pub fn for_each_while(&self, state: &ExecutionState, mut f: impl FnMut(ScanEntry<'_>) -> bool) {
        let schema_math = self.table_math;
        let imp = state.get_table(self.table);
        let all = imp.all();
        let mut cur = Offset::new(0);
        let mut buf = TaggedRowBuffer::new(imp.spec().arity());
        macro_rules! drain_buf {
            ($buf:expr) => {
                for (_, row) in $buf.iter() {
                    let subsumed =
                        schema_math.subsume && row[schema_math.subsume_col()] == SUBSUMED;
                    if !f(ScanEntry {
                        vals: &row[0..schema_math.func_cols],
                        subsumed,
                    }) {
                        return;
                    }
                }
                $buf.clear();
            };
        }
        while let Some(next) = imp.scan_bounded(all.as_ref(), cur, 32, &mut buf) {
            drain_buf!(buf);
            cur = next;
        }
        drain_buf!(buf);
    }

    /// Iterate rows after applying the user-visible prefix/output projection,
    /// excluding internal columns such as an encoded view's proof.
    #[doc(hidden)]
    pub fn for_each_visible_while(
        &self,
        state: &ExecutionState,
        mut f: impl FnMut(&[Value], Value, bool) -> bool,
    ) {
        let input_arity = self.read_projection.input_arity;
        self.for_each_while(state, |row| {
            f(
                &row.vals[..input_arity],
                row.vals[input_arity],
                row.subsumed,
            )
        });
    }

    /// Call `f` on each row whose output column is `value`.
    pub fn for_each_output_value(
        &self,
        state: &ExecutionState,
        value: Value,
        mut f: impl FnMut(ScanEntry<'_>),
    ) {
        let schema_math = self.table_math;
        let output_col = ColumnId::from_usize(self.read_projection.input_arity);
        state.for_each_matching_col(self.table, output_col, value, |row| {
            let subsumed = schema_math.subsume && row[schema_math.subsume_col()] == SUBSUMED;
            f(ScanEntry {
                vals: &row[0..schema_math.func_cols],
                subsumed,
            });
        });
    }

    /// Look up a row, inserting the configured default value if absent.
    /// For constructor tables this mints a fresh eclass ID; for custom
    /// functions (no default) this behaves identically to
    /// [`TableAction::lookup`].
    ///
    /// This is a write operation — only safe in action contexts. See
    /// issue #772.
    pub fn lookup_or_insert(&self, state: &mut ExecutionState, key: &[Value]) -> Option<Value> {
        match self.default {
            Some(default) => {
                let timestamp =
                    MergeVal::Constant(Value::from_usize(state.read_counter(self.timestamp)));
                let mut merge_vals = SmallVec::<[MergeVal; 3]>::new();
                // Build just the non-key portion (single value + ts + subsume) of the row.
                // `lookup_or_insert` is only used for single-value functions/constructors.
                SchemaMath {
                    n_keys: 0,
                    func_cols: 1,
                    ..self.table_math
                }
                .write_table_row(
                    &mut merge_vals,
                    RowVals {
                        timestamp,
                        subsume: self
                            .table_math
                            .subsume
                            .then_some(MergeVal::Constant(NOT_SUBSUMED)),
                        ret_val: Some(default),
                    },
                );
                Some(
                    state.predict_val(self.table, key, merge_vals.iter().copied())
                        [self.table_math.ret_val_col()],
                )
            }
            None => self.lookup(state, key),
        }
    }

    /// Multi-value variant of [`TableAction::lookup_or_insert`] for a value-tuple constructor
    /// `(children) -> (output, extra...)`: the first value column (`output`) is minted (the
    /// configured `FreshId` default) and the rest are written from `provided_vals` (e.g. a proof).
    /// Returns the minted `output`.
    ///
    /// Idempotent: an already-present key returns its existing `output` and writes nothing. Write
    /// operation, only safe in action/merge contexts.
    pub fn lookup_or_insert_multi(
        &self,
        state: &mut ExecutionState,
        key: &[Value],
        provided_vals: &[Value],
    ) -> Option<Value> {
        match self.default {
            Some(default) => {
                debug_assert_eq!(
                    self.table_math.n_vals(),
                    1 + provided_vals.len(),
                    "lookup_or_insert_multi: provided_vals must fill every value \
                     column except the minted first one"
                );
                let timestamp =
                    MergeVal::Constant(Value::from_usize(state.read_counter(self.timestamp)));
                // Non-key columns, in order: [output (minted), provided.., ts, subsume?].
                let mut merge_vals = SmallVec::<[MergeVal; 4]>::new();
                merge_vals.push(default);
                merge_vals.extend(provided_vals.iter().map(|v| MergeVal::Constant(*v)));
                merge_vals.push(timestamp);
                if self.table_math.subsume {
                    merge_vals.push(MergeVal::Constant(NOT_SUBSUMED));
                }
                // The first value column (the minted output) is at `ret_val_col()`.
                Some(
                    state.predict_val(self.table, key, merge_vals.iter().copied())
                        [self.table_math.ret_val_col()],
                )
            }
            None => self.lookup(state, key),
        }
    }

    /// Get-or-insert with caller-supplied value columns, reading this batch's
    /// own pending inserts.
    ///
    /// Returns the first value column of the row for `key`: the committed row's
    /// if the key is present, the pending row's if an earlier call in this same
    /// action batch already inserted it, and otherwise `vals`' first entry after
    /// staging `(key, vals)`.
    pub fn lookup_or_insert_vals(
        &self,
        state: &mut ExecutionState,
        key: &[Value],
        vals: &[Value],
    ) -> Value {
        debug_assert_eq!(
            vals.len(),
            self.table_math.n_vals(),
            "lookup_or_insert_vals: vals must fill every value column"
        );
        let timestamp = MergeVal::Constant(Value::from_usize(state.read_counter(self.timestamp)));
        let mut merge_vals = SmallVec::<[MergeVal; 4]>::new();
        merge_vals.extend(vals.iter().map(|v| MergeVal::Constant(*v)));
        merge_vals.push(timestamp);
        if self.table_math.subsume {
            merge_vals.push(MergeVal::Constant(NOT_SUBSUMED));
        }
        state.predict_col(
            self.table,
            key,
            merge_vals.iter().copied(),
            ColumnId::from_usize(self.table_math.ret_val_col()),
        )
    }

    /// Insert a row into this table.
    pub fn insert(&self, state: &mut ExecutionState, row: impl Iterator<Item = Value>) {
        let ts = Value::from_usize(state.read_counter(self.timestamp));
        let mut scratch = row.collect::<SmallVec<[_; 8]>>();
        self.table_math.write_table_row(
            &mut scratch,
            RowVals {
                timestamp: ts,
                subsume: self.table_math.subsume.then_some(NOT_SUBSUMED),
                ret_val: None,
            },
        );
        state.stage_insert(self.table, &scratch);
    }

    /// Delete a row from this table.
    pub fn remove(&self, state: &mut ExecutionState, key: &[Value]) {
        state.stage_remove(self.table, key);
    }

    /// Subsume a row in a table with subsumption enabled. For a constructor,
    /// the configured default is inserted if the key is absent. Rows predicted
    /// earlier in the same action are reused.
    pub fn subsume(&self, state: &mut ExecutionState, key: impl Iterator<Item = Value>) {
        assert!(
            self.table_math.subsume,
            "table does not support subsumption"
        );
        let ts = Value::from_usize(state.read_counter(self.timestamp));
        let mut scratch = key.collect::<SmallVec<[_; 8]>>();
        let values = if self.table_math.n_vals() == 1 {
            vec![
                self.lookup_or_insert(state, &scratch)
                    .expect("subsume lookup failed"),
            ]
        } else {
            self.lookup_values(state, &scratch)
                .expect("subsume lookup failed")
        };
        scratch.extend(values);
        scratch.push(ts);
        scratch.push(SUBSUMED);
        state.stage_insert(self.table, &scratch);
    }
}

/// A variant of `TableAction` for the union-find.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct UnionAction {
    table: TableId,
    timestamp: CounterId,
}

impl UnionAction {
    /// Create a new `UnionAction` to be used later.
    /// This requires access to the `egglog_bridge::EGraph`.
    pub fn new(egraph: &EGraph) -> UnionAction {
        UnionAction {
            table: egraph.uf_table,
            timestamp: egraph.timestamp_counter,
        }
    }

    /// Union two values.
    pub fn union(&self, state: &mut ExecutionState, x: Value, y: Value) {
        let ts = Value::from_usize(state.read_counter(self.timestamp));
        state.stage_insert(self.table, &[x, y, ts]);
    }
}

fn run_rules_impl(
    db: &mut Database,
    rule_info: &mut DenseIdMapWithReuse<RuleId, RuleInfo>,
    rules: &[RuleId],
    next_ts: Timestamp,
    report_level: ReportLevel,
    context: ExternalContext<'_>,
) -> Result<(Duration, RuleSetReport)> {
    let assembly_timer = Instant::now();
    for rule in rules {
        let info = &mut rule_info[*rule];
        if info.cached_plan.is_none() {
            info.cached_plan = Some(info.query.build_cached_plan(db, &info.desc)?);
        }
    }
    let mut rsb = db.new_rule_set();
    for rule in rules {
        let info = &mut rule_info[*rule];
        let cached_plan = info.cached_plan.as_ref().unwrap();
        info.query
            .add_rules_from_cached(&mut rsb, info.last_run_at, cached_plan);
        info.last_run_at = next_ts;
    }
    let ruleset = rsb.build();
    let assembly_time = assembly_timer.elapsed();
    Ok((
        assembly_time,
        db.run_rule_set(&ruleset, report_level, context),
    ))
}

// These markers are just used to make it easy to distinguish time spent in
// incremental vs. nonincremental rebuilds in time-based profiles.

#[inline(never)]
fn marker_incremental_rebuild<R>(f: impl FnOnce() -> R) -> R {
    f()
}

#[inline(never)]
fn marker_nonincremental_rebuild<R>(f: impl FnOnce() -> R) -> R {
    f()
}

/// A useful type definition for external functions that need to pass data
/// to outside code, such as `Panic`.
pub type SideChannel<T> = Arc<Mutex<Option<T>>>;

/// An external function used to grab a value out of the database matching a
/// particular query.
//
// TODO: once we have parallelism wired in, we'll want to replace this with a
// more efficient solution (e.g. one based on crossbeam or arcswap).
/// This is a variant on [`Panic`] that avoids eager construction of the panic message.
///
/// The main thing this is used for is to avoid constructing the panic message ahead of time during
/// a call to [`RuleBuilder::call_external_func`]; these panic messages are often quite rare and
/// may never need to be constructed at all. Furthermore, a closure to produce the panic message in
/// most cases need only close over a few cheap-to-clone values.
///
/// The downside of this, and why we do not use it everywhere, is that there's no natural "key"
/// that we can use to cache duplicate panic messages. We would need a more complex API to support
/// both and fully replace our use of `Panic`.
struct LazyPanic<F>(Arc<Lazy<String, F>>, SideChannel<String>);

impl<F: FnOnce() -> String + Send> ExternalFunction for LazyPanic<F> {
    fn invoke(&self, state: &mut core_relations::ExecutionState, args: &[Value]) -> Option<Value> {
        assert!(args.is_empty());
        state.trigger_early_stop();
        let mut guard = self.1.lock().unwrap();
        if guard.is_none() {
            *guard = Some(Lazy::force(&self.0).clone());
        }
        None
    }
}

impl<F> Clone for LazyPanic<F> {
    fn clone(&self) -> Self {
        LazyPanic(self.0.clone(), self.1.clone())
    }
}

/// An external function used to store a message when a panic occurs.
//
// TODO: once we have parallelism wired in, we'll want to replace this with a
// more efficient solution (e.g. one based on crossbeam or arcswap).
#[derive(Clone)]
struct Panic(String, SideChannel<String>);

impl EGraph {
    /// Create a new `ExternalFunction` that panics with the given message.
    pub fn new_panic(&mut self, message: String) -> ExternalFunctionId {
        if let Some(cached) = self.panic_funcs.get(&message) {
            return *cached;
        }
        let panic = Panic(message.clone(), self.panic_message.clone());
        let id = self.db.add_external_function(Box::new(panic));
        self.panic_funcs.insert(message, id);
        id
    }

    pub fn new_panic_lazy(
        &mut self,
        message: impl FnOnce() -> String + Send + 'static,
    ) -> ExternalFunctionId {
        let lazy = Lazy::new(message);
        let panic = LazyPanic(Arc::new(lazy), self.panic_message.clone());
        self.db.add_external_function(Box::new(panic))
    }
}

impl ExternalFunction for Panic {
    fn invoke(&self, state: &mut core_relations::ExecutionState, _args: &[Value]) -> Option<Value> {
        // TODO (egglog feature): change this to support interpolating panic messages
        state.trigger_early_stop();
        let mut guard = self.1.lock().unwrap();
        if guard.is_none() {
            *guard = Some(self.0.clone());
        }
        None
    }
}

/// Heuristic for deciding whether to do an incremental or nonincremental
/// rebuild for a given table.
fn incremental_rebuild(uf_size: usize, table_size: usize, parallel: bool) -> bool {
    if parallel {
        uf_size <= (table_size / 16)
    } else {
        uf_size <= (table_size / 8)
    }
}

pub(crate) const SUBSUMED: Value = Value::new_const(1);
pub(crate) const NOT_SUBSUMED: Value = Value::new_const(0);
fn combine_subsumed(v1: Value, v2: Value) -> Value {
    std::cmp::max(v1, v2)
}

/// A struct helping with some calculations of where some information is stored at the
/// core-relations Table level for a given function.
///
/// Functions can have multiple "output columns" in the underlying core-relations layer depending
/// on whether different features are enabled. Roughly, tables are laid out as:
///
/// > `[key0, ..., keyn, value0, ..., valuem, timestamp, subsume?]`
///
/// Where there are `n+1` key columns, `m+1` value (return) columns, and columns marked with a
/// question mark are optional, depending on the egraph and table-level configuration.
///
/// Most functions have a single value column (`m == 0`); tuple-output functions (declared with a
/// parenthesized list of output sorts) have more than one. The functional dependency is always
/// from the key columns to the value columns.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
struct SchemaMath {
    /// Whether or not the table is enabled for subsumption.
    subsume: bool,
    /// The number of key (input) columns.
    n_keys: usize,
    /// The number of columns in the function (keys plus all value/return columns).
    func_cols: usize,
    /// Opt-in identity-column guard (see [`FunctionConfig::n_identity_vals`]).
    n_identity_vals: Option<usize>,
}

/// What a `mint-<Relation>!` primitive would do, kept so the rule builder can
/// lower a call site to a batched [`core_relations`] instruction.
#[derive(Clone)]
struct MintSpec {
    table_name: String,
    n_args: usize,
    vals: Vec<Value>,
    counter: CounterId,
}

/// What a `set-if-empty-<View>!` primitive would do, kept so the rule builder
/// can lower a call site to the existing `LookupOrInsertDefault` instruction.
#[derive(Clone)]
struct SetIfEmptySpec {
    view_name: String,
    n_keys: usize,
    out_arity: usize,
}

/// A lowered `set-if-empty`: the view table plus the layout its default row needs.
#[derive(Clone)]
pub(crate) struct SetIfEmptyPlan {
    pub(crate) table: TableId,
    pub(crate) n_keys: usize,
    pub(crate) ret_val_col: ColumnId,
    pub(crate) subsume: bool,
}

/// What a view-column read (`view-proof-<View>`, `@UF_<S>_canon`,
/// `@UF_<S>_canon_proof`) would do, kept so the rule builder can lower a call
/// site to the existing `LookupWithDefault` instruction.
#[derive(Clone)]
struct ViewColSpec {
    view_name: String,
    n_keys: usize,
    col_idx: usize,
}

/// A lowered view-column read: which table and which physical column.
#[derive(Clone)]
pub(crate) struct ViewColPlan {
    pub(crate) table: TableId,
    pub(crate) n_keys: usize,
    pub(crate) dst_col: ColumnId,
}

/// A lowered mint: what the rule builder needs to stage the row.
#[derive(Clone)]
pub(crate) struct MintInsertPlan {
    pub(crate) table: TableId,
    /// Constant value columns written after the minted id.
    pub(crate) tail: Vec<Value>,
    /// Counter minting the fresh id.
    pub(crate) counter: CounterId,
    pub(crate) math: SchemaMath,
    /// The column the minted id lands in.
    pub(crate) minted_col: ColumnId,
}

/// A struct containing possible non-key portions of a table row. To be used with
/// [`SchemaMath::write_table_row`].
///
/// This is the write side (building a row); [`ScanEntry`] is the
/// read side (a row yielded by a table scan).
struct RowVals<T> {
    /// The timestamp for the row.
    timestamp: T,
    /// The subsumption tag for the row. Only relevant if the table has subsumption enabled.
    subsume: Option<T>,
    /// The return value of the row. Return values are mandatory but callers may have already
    /// filled it in.
    ret_val: Option<T>,
}

/// A raw row yielded by a table scan; `vals` includes the trailing
/// output/eclass column.
///
/// Public so the `egglog` crate can consume it, but **do not re-export
/// it from `egglog`'s public API** — the user-facing row types are
/// `egglog::FunctionEntry` and `egglog::Enode`.
#[derive(Clone, Debug)]
pub struct ScanEntry<'a> {
    pub vals: &'a [Value],
    pub subsumed: bool,
}

impl SchemaMath {
    fn write_table_row<T: Clone>(
        &self,
        row: &mut impl HasResizeWith<T>,
        RowVals {
            timestamp,
            subsume,
            ret_val,
        }: RowVals<T>,
    ) {
        row.resize_with(self.table_columns(), || timestamp.clone());
        row[self.ts_col()] = timestamp;
        if let Some(ret_val) = ret_val {
            row[self.ret_val_col()] = ret_val;
        }
        if let Some(subsume) = subsume {
            row[self.subsume_col()] = subsume;
        } else {
            assert!(
                !self.subsume,
                "subsume flag must be provided if subsumption is enabled"
            );
        }
    }

    fn num_keys(&self) -> usize {
        self.n_keys
    }

    /// The number of value (return) columns.
    fn n_vals(&self) -> usize {
        self.func_cols - self.n_keys
    }

    fn table_columns(&self) -> usize {
        self.func_cols + 1 /* timestamp */ + if self.subsume { 1 } else { 0 }
    }

    /// The column index of the `i`th value (return) column.
    fn val_col(&self, i: usize) -> usize {
        self.n_keys + i
    }

    /// The first value column. For single-output functions this is *the* return value;
    /// for tuple-output functions it is value column 0.
    fn ret_val_col(&self) -> usize {
        self.n_keys
    }

    fn ts_col(&self) -> usize {
        self.func_cols
    }

    #[track_caller]
    fn subsume_col(&self) -> usize {
        assert!(self.subsume);
        self.func_cols + 1
    }
}

#[derive(Error, Debug)]
#[error("Panic: {0}")]
struct PanicError(String);

/// Basic ad-hoc polymorphism around `resize_with` in order to get [`SchemaMath::write_table_row`]
/// to work with both `Vec` and `SmallVec`.
trait HasResizeWith<T>:
    AsMut<[T]> + AsRef<[T]> + Index<usize, Output = T> + IndexMut<usize, Output = T>
{
    fn resize_with<F>(&mut self, new_size: usize, f: F)
    where
        F: FnMut() -> T;
}

impl<T> HasResizeWith<T> for Vec<T> {
    fn resize_with<F>(&mut self, new_size: usize, f: F)
    where
        F: FnMut() -> T,
    {
        self.resize_with(new_size, f);
    }
}

impl<T, A: smallvec::Array<Item = T>> HasResizeWith<T> for SmallVec<A> {
    fn resize_with<F>(&mut self, new_size: usize, f: F)
    where
        F: FnMut() -> T,
    {
        self.resize_with(new_size, f);
    }
}
