use std::cell::Cell;

use egglog::{
    ast::{ResolvedCommand, sanitize_internal_names},
    extract::{
        AdditiveCostModel, DEFAULT_COST_MODEL, DagCostModel, DefaultCost, MonoidCost,
        TreeCostModel, TreeCostModelFromDag, TreeExtractor,
    },
    *,
};

type CustomCost = u128;

struct CustomCostModel {
    node_cost: CustomCost,
}

struct BorrowedCountingTreeCostModel<'a>(&'a Cell<usize>);

impl TreeCostModel<DefaultCost> for BorrowedCountingTreeCostModel<'_> {
    type EnodeCost = ();
    type ContainerCost = ();

    fn base_value_cost(&self, _egraph: &EGraph, _sort: &ArcSort, _value: Value) -> DefaultCost {
        self.0.set(self.0.get() + 1);
        1
    }

    fn enode_cost(&self, _egraph: &EGraph, _func: &Function, _enode: &Enode<'_>) {
        self.0.set(self.0.get() + 1);
    }

    fn container_cost(&self, _egraph: &EGraph, _sort: &ArcSort, _value: Value) {
        self.0.set(self.0.get() + 1);
    }

    fn fold_enode_cost(&self, (): (), child_costs: &[DefaultCost]) -> DefaultCost {
        1 + child_costs.iter().sum::<DefaultCost>()
    }

    fn fold_container_cost(&self, (): (), element_costs: &[DefaultCost]) -> DefaultCost {
        element_costs.iter().sum()
    }
}

enum CustomEnodeCost {
    Wide,
    Other(CustomCost),
}

struct CustomContainerCost(CustomCost);

impl TreeCostModel<CustomCost> for CustomCostModel {
    type EnodeCost = CustomEnodeCost;
    type ContainerCost = CustomContainerCost;

    fn base_value_cost(&self, _egraph: &EGraph, _sort: &ArcSort, _value: Value) -> CustomCost {
        self.node_cost
    }

    fn enode_cost(&self, _egraph: &EGraph, func: &Function, _enode: &Enode<'_>) -> CustomEnodeCost {
        if func.name() == "Wide" {
            CustomEnodeCost::Wide
        } else {
            CustomEnodeCost::Other(self.node_cost)
        }
    }

    fn container_cost(
        &self,
        _egraph: &EGraph,
        _sort: &ArcSort,
        _value: Value,
    ) -> CustomContainerCost {
        CustomContainerCost(3)
    }

    fn fold_enode_cost(
        &self,
        enode_cost: CustomEnodeCost,
        child_costs: &[CustomCost],
    ) -> CustomCost {
        let child_cost = child_costs
            .iter()
            .fold(CustomCost::identity(), |cost, child| cost.combine(child));
        match enode_cost {
            CustomEnodeCost::Wide => child_cost.saturating_mul(10),
            CustomEnodeCost::Other(cost) => cost.combine(&child_cost),
        }
    }

    fn fold_container_cost(
        &self,
        container_cost: CustomContainerCost,
        element_costs: &[CustomCost],
    ) -> CustomCost {
        element_costs
            .iter()
            .fold(container_cost.0, |cost, element| cost.combine(element))
    }
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
struct OrderedOnlyCost(u128);

struct DirectTreeCostModel;

impl TreeCostModel<OrderedOnlyCost> for DirectTreeCostModel {
    type EnodeCost = ();
    type ContainerCost = ();

    fn base_value_cost(&self, _egraph: &EGraph, _sort: &ArcSort, _value: Value) -> OrderedOnlyCost {
        OrderedOnlyCost(1)
    }

    fn enode_cost(&self, _egraph: &EGraph, _func: &Function, _enode: &Enode<'_>) {}

    fn container_cost(&self, _egraph: &EGraph, _sort: &ArcSort, _value: Value) {}

    fn fold_enode_cost(&self, (): (), child_costs: &[OrderedOnlyCost]) -> OrderedOnlyCost {
        OrderedOnlyCost(1 + child_costs.iter().map(|cost| cost.0).sum::<u128>())
    }

    fn fold_container_cost(&self, (): (), element_costs: &[OrderedOnlyCost]) -> OrderedOnlyCost {
        OrderedOnlyCost(element_costs.iter().map(|cost| cost.0).sum())
    }
}

struct IndependentTreeAndDagCostModel;

impl DagCostModel<CustomCost> for IndependentTreeAndDagCostModel {
    fn base_value_cost(&self, _egraph: &EGraph, _sort: &ArcSort, _value: Value) -> CustomCost {
        1
    }

    fn enode_cost(&self, _egraph: &EGraph, _func: &Function, _enode: &Enode<'_>) -> CustomCost {
        1
    }

    fn container_cost(&self, _egraph: &EGraph, _sort: &ArcSort, _value: Value) -> CustomCost {
        3
    }
}

impl TreeCostModel<CustomCost> for IndependentTreeAndDagCostModel {
    type EnodeCost = CustomCost;
    type ContainerCost = CustomCost;

    fn base_value_cost(&self, _egraph: &EGraph, _sort: &ArcSort, _value: Value) -> CustomCost {
        1
    }

    fn enode_cost(&self, _egraph: &EGraph, _func: &Function, _enode: &Enode<'_>) -> CustomCost {
        1
    }

    fn container_cost(&self, _egraph: &EGraph, _sort: &ArcSort, _value: Value) -> CustomCost {
        0
    }

    fn fold_enode_cost(&self, enode_cost: CustomCost, child_costs: &[CustomCost]) -> CustomCost {
        enode_cost + child_costs.iter().sum::<CustomCost>()
    }

    fn fold_container_cost(
        &self,
        container_cost: CustomCost,
        element_costs: &[CustomCost],
    ) -> CustomCost {
        container_cost + element_costs.iter().sum::<CustomCost>()
    }
}

fn daggy_root(egraph: &mut EGraph) -> (ArcSort, Value) {
    let expr = egraph
        .parser
        .get_expr_from_string(None, "(Pair (Wide (Leaf 0)) (Wide (Leaf 0)))")
        .unwrap();
    egraph.eval_expr(&expr).unwrap()
}

fn add_daggy_example(egraph: &mut EGraph) {
    egraph
        .parse_and_run_program(
            None,
            r#"
             (datatype E
               (Pair E E)
               (Wide E)
               (Leaf i64)
             )
             (let shared (Wide (Leaf 0)))
             (let daggy (Pair shared shared))
             (let treeish (Pair (Leaf 1) (Leaf 2)))
             (union daggy treeish)
             "#,
        )
        .unwrap();
}

#[test]
fn globals_missing_prefix_errors_when_opted_in() {
    let mut egraph = EGraph::default();
    egraph.set_strict_mode(true);
    let err = egraph
        .parse_and_run_program(None, "(let value 41)")
        .unwrap_err();
    match err {
        Error::TypeError(TypeError::GlobalMissingPrefix { ref name, .. }) => {
            assert_eq!(name, "value");
        }
        other => panic!("expected missing dollar error, got {other:?}"),
    }
}

#[test]
fn globals_missing_prefix_errors_for_prefixed_pattern_variable_when_opted_in() {
    let mut egraph = EGraph::default();
    egraph.set_strict_mode(true);
    let err = egraph
        .parse_and_run_program(None, "(rule ((= $x 1)) ())")
        .unwrap_err();

    match err {
        Error::TypeError(TypeError::NonGlobalPrefixed { ref name, .. }) => {
            assert_eq!(name, "$x");
        }
        other => panic!("expected non-global prefixed variable error, got {other:?}"),
    }
}

#[test]
fn globals_missing_prefix_errors_for_prefixed_rule_let_when_opted_in() {
    let mut egraph = EGraph::default();
    egraph.set_strict_mode(true);
    let err = egraph
        .parse_and_run_program(None, "(rule () ((let $y 1)))")
        .unwrap_err();

    match err {
        Error::TypeError(TypeError::NonGlobalPrefixed { ref name, .. }) => {
            assert_eq!(name, "$y");
        }
        other => panic!("expected non-global prefixed variable error, got {other:?}"),
    }
}

#[test]
fn globals_cannot_be_shadowed_by_pattern_variables() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::default();
    let program = r#"
        (let $value 41)
        (rule ((= value $value)) ())
    "#;

    let err = egraph.parse_and_run_program(None, program).unwrap_err();
    match err {
        Error::Shadowing(message, _global_span, _shadow_span) => {
            assert!(message.contains("pattern variable `value`"));
            assert!(message.contains("global `$value`"));
        }
        other => panic!("expected shadowing error, got {other:?}"),
    }
}

#[test]
fn test_simple_extract1() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::default();

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
             (datatype Op (Add i64 i64))
             (let expr (Add 1 1))
             (extract expr)"#,
        )
        .unwrap();
    let CommandOutput::ExtractBest(_, cost, _) = outputs[0] else {
        panic!();
    };
    assert_eq!(cost, 3);
}

#[test]
fn primitive_error_in_extract_returns_error() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::default();
    // Evaluating this primitive should surface a user-facing error instead of
    // panicking when the primitive fails.
    let err = egraph
        .parse_and_run_program(None, "(extract (<< 1 10000))")
        .unwrap_err();
    assert!(err.to_string().contains("call of primitive << failed"));
}

#[test]
fn primitive_error_in_run_schedule_returns_error() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::default();
    let program = r#"
        (ruleset problematic)
        (rule ()
              ((let tmp (<< 1 10000)))
              :ruleset problematic)
        (run-schedule (run problematic))
    "#;

    let err = egraph.parse_and_run_program(None, program).unwrap_err();
    assert!(err.to_string().contains("call of primitive << failed"));
}

#[test]
fn failed_run_continues_from_canonical_partial_state() {
    let mut egraph = EGraph::default();
    egraph
        .parse_and_run_program(
            None,
            r#"
            (ruleset problematic)
            (datatype E (A) (B))
            (function P (E) i64 :merge old)
            (set (P (A)) 0)
            (set (P (B)) 0)
            (rule ((= a (A)) (= b (B)))
                  ((union a b) (panic "boom"))
                  :ruleset problematic)
            "#,
        )
        .unwrap();

    // `fail` deliberately rolls back in this fork. Observe the error directly
    // to exercise the backend's recovery of a canonical partial state.
    let error = egraph
        .parse_and_run_program(None, "(run problematic 1)")
        .unwrap_err();
    assert!(error.to_string().contains("boom"));
    egraph
        .parse_and_run_program(None, "(check (= (A) (B)))")
        .unwrap();
    assert_eq!(egraph.get_size("P"), 1);
}

#[test]
fn check_facts_stops_safely_in_parallel_mode() {
    use std::fmt::Write;

    let mut program = String::from("(relation Candidate (i64))\n");
    for i in 0..20_000 {
        writeln!(&mut program, "(Candidate {i})").unwrap();
    }

    let mut egraph = EGraph::new(32);
    egraph.parse_and_run_program(None, &program).unwrap();
    egraph
        .parse_and_run_program(None, "(check (Candidate x))")
        .unwrap();
    egraph
        .parse_and_run_program(None, "(check (Candidate 19999))")
        .unwrap();
}

#[test]
fn prove_exists_reports_query_mismatch() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::new_with_proofs();
    let program = r#"
        (relation R (i64))
    (prove (R x))
    "#;

    let err = egraph.parse_and_run_program(None, program).unwrap_err();
    let msg = err.to_string();
    assert!(
        msg.contains("Could not find a proof due to query not matching"),
        "expected helpful error message, got {msg}"
    );
}

#[test]
fn test_simple_extract2() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::default();

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
             (datatype Term
               (Origin :cost 0)
               (BigStep Term :cost 10)
               (SmallStep Term :cost 1)
             )
             (let t (Origin))
             (let tb (BigStep t))
             (let tbs (SmallStep tb))
             (let ts (SmallStep t))
             (let tss (SmallStep ts))
             (let tsss (SmallStep tss))
             (union tbs tsss)
             (let tssss (SmallStep tsss))
             (union tssss tb)
             (extract tb)
             "#,
        )
        .unwrap();
    assert!(matches!(outputs[0], CommandOutput::ExtractBest(_, 4, _)));
}

#[test]
fn test_simple_extract3() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::default();

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
             (datatype Fruit
               (Apple i64 :cost 1)
               (Orange f64 :cost 2)
             )
             (datatype Vegetable
               (Broccoli bool :cost 3)
               (Carrot Fruit :cost 4)
             )
             (let a (Apple 5))
             (let o (Orange 3.14))
             (let b (Broccoli true))
             (let c (Carrot a))
             (extract a)
             "#,
        )
        .unwrap();

    let CommandOutput::ExtractBest(_, cost, _) = outputs[0] else {
        panic!();
    };
    assert_eq!(cost, 2);
}

#[test]
fn test_simple_extract4() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::default();

    egraph
        .parse_and_run_program(
            None,
            r#"
        (datatype Foo
            (Foobar)
        )
        (subsume (Foobar))
        (datatype Bar
            (Barbar Foo)
        )
        (let x (Barbar (Foobar)))
        (extract x)
        "#,
        )
        .unwrap_err();
}

#[test]
fn test_simple_extract5() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::default();

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
             (datatype Foo
                (Foobar i64)
             )
             (let foobar (Foobar 42))
             (datatype Bar
                (Barfoo i64)
             )
             (let barfoo (Barfoo 24))
             (sort QuaVec (Vec i64))
             (sort QuaMap (Map QuaVec Foo))
             (function Quaz () QuaMap :no-merge)
             (set (Quaz) (map-empty))
             (extract (Quaz))
             "#,
        )
        .unwrap();

    let CommandOutput::ExtractBest(_, cost, _) = outputs[0] else {
        panic!();
    };
    assert_eq!(cost, 0);
}

#[test]
fn test_simple_extract6() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::default();

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
             (datatype False)
             (sort QuaVec (Vec i64))
             (sort QuaMap (Map QuaVec False))
             (function Quaz () QuaMap :no-merge)
             (set (Quaz) (map-empty))
             (extract (Quaz))
             "#,
        )
        .unwrap();

    let CommandOutput::ExtractBest(_, cost, _) = outputs[0] else {
        panic!();
    };
    assert_eq!(cost, 0);
}

#[test]
fn test_simple_extract7() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::default();

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype Foo
                (bar)
                (baz)
            )
            (sort Mapsrt1 (Map i64 Foo))
            (let map1 (map-insert (map-empty) 0 (bar)))

            (sort Mapsrt2 (Map bool Foo))
            (let map2 (map-insert (map-empty) false (baz)))
            ;(let map2b (map-insert (map-empty) false (bar)))
            ;(union map2 map2b)

            ;(extract map1)
            ;(extract map2)

            ;(function toerr (Mapsrt2) Foo :no-merge)

            ;(set (toerr map2) (bar))

            (union (bar) (baz))
            ; Also unions map1 and map2!?

            (extract map1)
            (extract map2)

            ;(extract (toerr map2))

             "#,
        )
        .unwrap();

    let CommandOutput::ExtractBest(_, cost, _) = outputs[0] else {
        panic!();
    };
    assert_eq!(cost, 2);
}

#[test]
fn test_simple_extract8() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::default();

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype Foo
                (bar :cost 10)
            )
            (function func () Foo :no-merge)
            (set (func) (bar))

            (extract (bar))
            "#,
        )
        .unwrap();

    let CommandOutput::ExtractBest(_, cost, _) = outputs[0] else {
        panic!();
    };
    assert_eq!(cost, 10);
}

#[test]
fn test_simple_extract9() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::default();

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype Foo)
            (datatype NodeA)
            (datatype NodeB)
            (datatype NodeC)
            (constructor ctoa (NodeC) NodeA)
            (constructor atob (NodeA) NodeB)
            (constructor btoc (NodeB) NodeC)

            (constructor bar () Foo :cost 9223372036854775807)
            (constructor barbar (Foo Foo) Foo :cost 2)

            (constructor groundedA (Foo) NodeA)
            (let a (groundedA (barbar (bar) (bar))))
            (let b (atob a))
            (let c (btoc b))
            (let a2 (ctoa c))
            (let b2 (atob a2))
            (let c2 (btoc b2))
            (union a a2)
            (union b b2)
            (union c c2)

            (extract a)
            "#,
        )
        .unwrap();

    let CommandOutput::ExtractBest(_, cost, _) = outputs[0] else {
        panic!();
    };
    assert_eq!(cost, DefaultCost::MAX);

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
            (extract b)
            "#,
        )
        .unwrap();

    let CommandOutput::ExtractBest(_, cost, _) = outputs[0] else {
        panic!();
    };
    assert_eq!(cost, DefaultCost::MAX);

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
            (extract c)
            "#,
        )
        .unwrap();

    let CommandOutput::ExtractBest(_, cost, _) = outputs[0] else {
        panic!();
    };
    assert_eq!(cost, DefaultCost::MAX);
}

#[test]
fn test_extract_variants1() {
    let _ = env_logger::builder().is_test(true).try_init();

    let mut egraph = EGraph::default();

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
             (datatype Term
               (Origin :cost 0)
               (BigStep Term :cost 10)
               (SmallStep Term :cost 1)
             )
             (let t (Origin))
             (let tb (BigStep t))
             (let tbs (SmallStep tb))
             (let ts (SmallStep t))
             (let tss (SmallStep ts))
             (let tsss (SmallStep tss))
             (union tbs tsss)
             (let tssss (SmallStep tsss))
             (union tssss tb)
             (extract tb 3)
             "#,
        )
        .unwrap();
    assert_eq!(
        outputs[0].to_string(),
        "(\n   (SmallStep (SmallStep (SmallStep (SmallStep (Origin)))))\n   (BigStep (Origin))\n)\n"
    );
}

#[test]
fn tree_cost_model_accepts_custom_enode_annotation() {
    let mut egraph = EGraph::default();
    add_daggy_example(&mut egraph);

    let (sort, value) = daggy_root(&mut egraph);

    let extracted: extract::ExtractedTerms<u128> = egraph
        .extract_best_with_cost_model(
            vec![(sort.clone(), value)],
            CustomCostModel { node_cost: 1 },
        )
        .unwrap();
    let root = extracted.terms.into_iter().next().unwrap().unwrap();

    assert_eq!(root.cost, 5);
    let extracted_term = extracted.termdag.to_string(root.term);
    assert_eq!(extracted_term, "(Pair (Leaf 1) (Leaf 2))");
    let extracted_expr = egraph
        .parser
        .get_expr_from_string(None, &extracted_term)
        .unwrap();
    let (extracted_sort, extracted_value) = egraph.eval_expr(&extracted_expr).unwrap();
    assert_eq!(extracted_sort.name(), sort.name());
    assert_eq!(extracted_value, value);
}

#[test]
fn tree_cost_model_does_not_require_monoid_cost() {
    let mut egraph = EGraph::default();
    add_daggy_example(&mut egraph);

    let (sort, value) = daggy_root(&mut egraph);
    let extracted = egraph
        .extract_best_with_cost_model(vec![(sort, value)], DirectTreeCostModel)
        .unwrap();
    let root = extracted.terms.into_iter().next().unwrap().unwrap();

    assert_eq!(root.cost, OrderedOnlyCost(5));
    assert_eq!(
        extracted.termdag.to_string(root.term),
        "(Pair (Leaf 1) (Leaf 2))"
    );

    // One type may implement the independent tree and DAG model interfaces.
    let (sort, value) = daggy_root(&mut egraph);
    let extracted = egraph
        .extract_best_with_cost_model(vec![(sort, value)], IndependentTreeAndDagCostModel)
        .unwrap();
    assert_eq!(extracted.terms[0].as_ref().unwrap().cost, 5);

    let (sort, value) = daggy_root(&mut egraph);
    let extracted = egraph
        .extract_best_with_cost_model(
            vec![(sort, value)],
            TreeCostModelFromDag(IndependentTreeAndDagCostModel),
        )
        .unwrap();
    assert_eq!(extracted.terms[0].as_ref().unwrap().cost, 5);
}

#[test]
fn monoid_unsigned_cost_saturates() {
    assert_eq!(<usize as MonoidCost>::identity(), 0);
    assert_eq!(usize::MAX.combine(&1), usize::MAX);
    assert_eq!(u64::MAX.combine(&1), u64::MAX);
    assert_eq!(u128::MAX.combine(&1), u128::MAX);
}

#[test]
fn additive_cost_model_uses_configured_default_node_cost() {
    let mut egraph = EGraph::default();
    add_daggy_example(&mut egraph);

    let (sort, value) = daggy_root(&mut egraph);

    let extracted = egraph
        .extract_best_with_cost_model(
            vec![(sort.clone(), value)],
            TreeCostModelFromDag(AdditiveCostModel { node_cost: 2 }),
        )
        .unwrap();
    let root = extracted.terms.into_iter().next().unwrap().unwrap();

    assert_eq!(root.cost, 10);
    assert_eq!(
        extracted.termdag.to_string(root.term),
        "(Pair (Leaf 1) (Leaf 2))"
    );

    let (termdag, term, cost) = egraph.extract_value(&sort, value).unwrap();
    assert_eq!(cost, 5);
    assert_eq!(termdag.to_string(term), "(Pair (Leaf 1) (Leaf 2))");
}

#[test]
fn tree_extractor_reuses_costs_for_multiple_values() {
    let mut egraph = EGraph::default();
    add_daggy_example(&mut egraph);

    let (sort, root_value) = daggy_root(&mut egraph);
    let leaf = egraph
        .parser
        .get_expr_from_string(None, "(Leaf 9)")
        .unwrap();
    let (_, leaf_value) = egraph.eval_expr(&leaf).unwrap();
    let calls = Cell::new(0);
    let extractor = TreeExtractor::compute_costs_from_rootsorts(
        Some(vec![sort.clone()]),
        &egraph,
        BorrowedCountingTreeCostModel(&calls),
    );
    assert!(calls.get() > 0);
    let prepared_calls = calls.get();
    let mut termdag = TermDag::default();

    let root = extractor
        .extract_best_with_sort(&mut termdag, root_value, sort.clone())
        .unwrap();
    let leaf = extractor
        .extract_best_with_sort(&mut termdag, leaf_value, sort.clone())
        .unwrap();

    assert_eq!(termdag.to_string(root.term), "(Pair (Leaf 1) (Leaf 2))");
    assert_eq!(termdag.to_string(leaf.term), "(Leaf 9)");
    assert_eq!(calls.get(), prepared_calls);

    let all_sorts = TreeExtractor::compute_costs_from_rootsorts(None, &egraph, DEFAULT_COST_MODEL);
    let leaf = all_sorts
        .extract_best_with_sort(&mut termdag, leaf_value, sort)
        .unwrap();
    assert_eq!(termdag.to_string(leaf.term), "(Leaf 9)");
}

#[test]
fn tree_extractor_supports_reachable_sorts_and_zero_variants() {
    let mut egraph = EGraph::default();
    egraph
        .parse_and_run_program(
            None,
            r#"
            (sort Child)
            (constructor Leaf (i64) Child)
            (sort Parent)
            (constructor Wrap (Child) Parent)
            (sort IntVec (Vec i64))
            (let $root (Wrap (Leaf 1)))
            "#,
        )
        .unwrap();

    let child_expr = egraph
        .parser
        .get_expr_from_string(None, "(Leaf 1)")
        .unwrap();
    let (child_sort, child_value) = egraph.eval_expr(&child_expr).unwrap();
    let parent_sort = egraph.get_arcsort_by(|sort| sort.name() == "Parent");
    let primitive = egraph.parser.get_expr_from_string(None, "1").unwrap();
    let (primitive_sort, primitive_value) = egraph.eval_expr(&primitive).unwrap();
    let container = egraph
        .parser
        .get_expr_from_string(None, "(vec-of 1)")
        .unwrap();
    let (container_sort, container_value) = egraph.eval_expr(&container).unwrap();

    let extractor = TreeExtractor::compute_costs_from_rootsorts(
        Some(vec![parent_sort]),
        &egraph,
        DEFAULT_COST_MODEL,
    );
    let mut termdag = TermDag::default();

    let variants =
        extractor.extract_variants_with_sort(&mut termdag, child_value, 1, child_sort.clone());
    assert_eq!(termdag.to_string(variants[0].term), "(Leaf 1)");
    assert!(
        extractor
            .extract_variants_with_sort(&mut termdag, child_value, 0, child_sort)
            .is_empty()
    );
    assert!(
        extractor
            .extract_variants_with_sort(&mut termdag, primitive_value, 0, primitive_sort.clone())
            .is_empty()
    );
    assert!(
        extractor
            .extract_variants_with_sort(&mut termdag, container_value, 0, container_sort.clone())
            .is_empty()
    );
    let container_variants = extractor.extract_variants_with_sort(
        &mut termdag,
        container_value,
        2,
        container_sort.clone(),
    );
    assert_eq!(container_variants.len(), 1);
    assert_eq!(termdag.to_string(container_variants[0].term), "(vec-of 1)");

    let annotated = egraph
        .extract_best_with_cost_model(
            vec![(container_sort.clone(), container_value)],
            CustomCostModel { node_cost: 1 },
        )
        .unwrap();
    assert_eq!(annotated.terms[0].as_ref().unwrap().cost, 4);
    let adapted = egraph
        .extract_best_with_cost_model(
            vec![(container_sort, container_value)],
            TreeCostModelFromDag(IndependentTreeAndDagCostModel),
        )
        .unwrap();
    assert_eq!(adapted.terms[0].as_ref().unwrap().cost, 4);

    let calls = Cell::new(0);
    let extracted = egraph
        .extract_variants_with_cost_model(
            vec![(primitive_sort, primitive_value)],
            0,
            BorrowedCountingTreeCostModel(&calls),
        )
        .unwrap();
    assert_eq!(extracted.variants.len(), 1);
    assert!(extracted.variants[0].is_empty());
    assert_eq!(calls.get(), 0);
}

#[test]
fn extract_best_returns_none_for_unextractable_roots() {
    let mut egraph = EGraph::default();
    egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype Math)
            (constructor visible () Math)
            (constructor hidden () Math :unextractable)
            "#,
        )
        .unwrap();

    let visible = egraph
        .parser
        .get_expr_from_string(None, "(visible)")
        .unwrap();
    let hidden = egraph
        .parser
        .get_expr_from_string(None, "(hidden)")
        .unwrap();
    let (sort, visible) = egraph.eval_expr(&visible).unwrap();
    let (_, hidden) = egraph.eval_expr(&hidden).unwrap();

    let extracted = egraph
        .extract_best(vec![(sort.clone(), visible), (sort, hidden)])
        .unwrap();

    assert_eq!(extracted.terms.len(), 2);
    let visible_root = extracted.terms[0].as_ref().unwrap();
    assert_eq!(extracted.termdag.to_string(visible_root.term), "(visible)");
    assert!(extracted.terms[1].is_none());
}

#[test]
fn test_subsumed_unextractable_action_extract() {
    // Test when an expression is subsumed, it isn't extracted, even if its the cheapest
    let mut egraph = EGraph::default();

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype Math)
            (constructor expensive () Math :cost 100)
            (constructor cheap () Math :cost 1)
            (union (expensive) (cheap))
            (extract (expensive))
            "#,
        )
        .unwrap();

    let CommandOutput::ExtractBest(_term_dag, _, _term_id) = &outputs[0] else {
        panic!("Should get extract best command output");
    };
    // Originally should give back numeric term
    assert!(match &outputs[0] {
        CommandOutput::ExtractBest(termdag, _, term_id) => {
            matches!(termdag.get(*term_id), Term::App(s, ..) if s == "cheap")
        }
        _ => false,
    });
    // Then if we make one as subsumed, it should give back the variable term
    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
            (subsume (cheap))
            (extract (expensive))
            "#,
        )
        .unwrap();
    assert!(match &outputs[0] {
        CommandOutput::ExtractBest(termdag, _, term_id) => {
            matches!(termdag.get(*term_id), Term::App(s, ..) if s == "expensive")
        }
        _ => false,
    });
}

#[test]
fn test_subsume_unextractable_insert_and_merge() {
    // Example adapted from https://github.com/egraphs-good/egglog/pull/301#pullrequestreview-1756826062
    let mut egraph = EGraph::default();

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype Expr
                (f Expr)
                (Num i64))
            (constructor expensive () Expr :cost 100)

              (f (Num 1))
              (subsume (f (Num 1)))
              (f (Num 2))

              (union (Num 2) (Num 1))
              (union (f (Num 2)) (expensive))
              (extract (f (Num 2)))
            "#,
        )
        .unwrap();
    assert!(match &outputs[0] {
        CommandOutput::ExtractBest(termdag, _, term_id) => {
            matches!(termdag.get(*term_id), Term::App(s, ..) if s == "expensive")
        }
        _ => false,
    });
}

#[test]
fn test_subsume_unextractable_action_extract_multiple() {
    // Test when an expression is set as subsumed, it isn't extracted, like with
    // extract multiple
    let mut egraph = EGraph::default();

    let outputs1 = egraph
        .parse_and_run_program(
            None,
            "
            (datatype Math (Num i64))
            (Num 1)
            (union (Num 1) (Num 2))
            (extract (Num 1) 2)
            ",
        )
        .unwrap();
    // Originally should give back two terms when extracted
    assert!(matches!(
        outputs1[0],
        CommandOutput::ExtractVariants(_, ref terms) if terms.len() == 2
    ));
    // Then if we make one unextractable, it should only give back one term
    let outputs2 = egraph
        .parse_and_run_program(
            None,
            "
            (subsume (Num 2))
            (extract (Num 1) 2)
            ",
        )
        .unwrap();
    assert!(matches!(
        outputs2[0],
        CommandOutput::ExtractVariants(_, ref terms) if terms.len() == 1
    ));
}

#[test]
fn test_rewrite_subsumed_unextractable() {
    // When a rewrite is marked as a subsumed, the lhs should not be extracted

    let mut egraph = EGraph::default();

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype Math)
            (constructor expensive () Math :cost 100)
            (constructor cheap () Math :cost 1)
            (rewrite (cheap) (expensive) :subsume)
            (cheap)
            (run 1)
            (extract (cheap))
            "#,
        )
        .unwrap();
    // Should give back expenive term, because cheap is unextractable
    assert_eq!(outputs[1].to_string(), "(expensive)\n");
}

#[test]
fn test_rewrite_subsumed() {
    // When a rewrite is marked as a subsumed, the lhs should not be extracted

    let mut egraph = EGraph::default();

    // If we rerite most-exp to another term, that rewrite shouldnt trigger since its been subsumed.
    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype Math)
            (constructor expensive () Math :cost 100)
            (constructor most-exp () Math :cost 1000)
            (rewrite (most-exp) (expensive) :subsume)
            (most-exp)
            (run 1)
            (constructor cheap () Math :cost 1)
            (rewrite (most-exp) (cheap))
            (run 1)
            (extract (most-exp))
            "#,
        )
        .unwrap();
    assert_eq!(outputs[2].to_string(), "(expensive)\n");
}

#[test]
fn test_subsume() {
    // Test that if we mark a term as subsumed than no rewrites will be applied to it.
    // We can test this by adding a commutative additon property, and verifying it isn't applied on one of the terms
    // but is on the other
    let mut egraph = EGraph::default();
    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
        (datatype Math
          (Add Math Math)
          (Num i64))

        (rewrite (Add a b) (Add b a))
        (let x (Add (Num 1) (Num 2)))
        (let y (Add (Num 3) (Num 4)))
        (subsume (Add (Num 1) (Num 2)))
        (run 1)
        (extract y 10)
        "#,
        )
        .unwrap();
    assert!(matches!(
        outputs[1],
        CommandOutput::ExtractVariants(_, ref terms) if terms.len() == 2
    ));

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
        ;; add something equal to x that can be extracted:
        (constructor otherConst () Math)
        (let other (otherConst))
        (union x other)
        (extract x 10)
        "#,
        )
        .unwrap();
    assert!(matches!(
        outputs[0],
        CommandOutput::ExtractVariants(_, ref terms) if terms.len() == 1
    ));
}

#[test]
fn test_subsume_custom() {
    // Test that we can't subsume  a custom function
    // Only relations and constructors are allowed to be subsumed

    let mut egraph = EGraph::default();
    let res = egraph.parse_and_run_program(
        None,
        r#"
        (function one () i64 :no-merge)
        (set (one) 1)
        (subsume (one))
        "#,
    );
    assert!(res.is_err());
}

#[test]
fn test_subsume_ok() {
    let mut egraph = EGraph::default();
    let res = egraph.parse_and_run_program(
        None,
        r#"
        (sort E)
        (constructor one () E)
        (constructor two () E)
        (one)
        (subsume (one))
        ;; subsuming a non-existent tuple
        (subsume (two))

        (relation R (i64))
        (R 1)
        (subsume (R 1))
        (subsume (R 2))
        "#,
    );
    assert!(res.is_ok());
}

#[test]
fn test_rule_subsume_predicted_rows() {
    let mut egraph = EGraph::default();
    egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype Math (Num i64))
            (relation fire (i64))
            (relation after (i64))
            (relation saw-num (i64))
            (ruleset mutate)
            (ruleset observe)

            ;; Subsume a missing row directly.
            (rule ((fire 0))
                  ((subsume (Num 0))
                   (after 0))
                  :ruleset mutate)

            ;; Add, then subsume, within one rule action.
            (rule ((fire 1))
                  ((let n (Num 1))
                   (subsume (Num 1))
                   (after 1))
                  :ruleset mutate)

            ;; Subsumption remains dominant when followed by an add.
            (rule ((fire 2))
                  ((subsume (Num 2))
                   (let n (Num 2))
                   (after 2))
                  :ruleset mutate)

            (rule ((= e (Num n)))
                  ((saw-num n))
                  :ruleset observe)

            (fire 0)
            (fire 1)
            (fire 2)
            (run mutate 1)
            (check (after 0) (after 1) (after 2))
            (run observe 1)
            (fail (check (saw-num 0)))
            (fail (check (saw-num 1)))
            (fail (check (saw-num 2)))
            "#,
        )
        .unwrap();

    let mut nums = Vec::new();
    egraph
        .constructor_enodes("Num", |enode| {
            nums.push((
                egraph.value_to_base::<i64>(enode.children[0]),
                enode.subsumed,
            ));
        })
        .unwrap();
    nums.sort_unstable();
    assert_eq!(nums, vec![(0, true), (1, true), (2, true)]);
}

#[test]
fn test_cant_subsume_merge() {
    // Test that we can't subsume something with a merge function

    let mut egraph = EGraph::default();
    let res = egraph.parse_and_run_program(
        None,
        r#"
        (constructor one () i64 :merge old)
        (set (one) 1)
        (subsume (one))
        "#,
    );
    assert!(res.is_err());
}

#[test]
fn constructor_internal_view_is_rejected() {
    let mut egraph = EGraph::default();
    // Proof-encoding views use a function annotation, so constructor syntax
    // should reject `:internal-view`.
    let res = egraph.parse_and_run_program(
        None,
        r#"
        (sort Expr)
        (sort View)
        (constructor ExprView (Expr Expr) View :internal-view constructor)
        "#,
    );

    let err = res.unwrap_err();
    assert!(
        err.to_string()
            .contains("could not parse constructor options")
    );
}

#[test]
fn test_value_to_classid() {
    let mut egraph = EGraph::default();

    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype Math)
            (constructor expensive () Math )
            (expensive)
            (extract (expensive))
            "#,
        )
        .unwrap();
    let CommandOutput::ExtractBest(termdag, _cost, term) = outputs[0].clone() else {
        panic!();
    };
    let expr = termdag.term_to_expr(&term, span!());
    let (sort, value) = egraph.eval_expr(&expr).unwrap();

    let serialize_output = egraph.serialize(SerializeConfig::default());
    assert!(serialize_output.is_complete());
    let class_id = egraph.value_to_class_id(&sort, value);
    assert!(serialize_output.egraph.class_data.get(&class_id).is_some());
    assert_eq!(value, egraph.class_id_to_value(&class_id));
}

#[test]
fn test_serialize_sort_name_with_dash() {
    // A sort whose name contains '-' (legal, like the built-in `vec-set`) must
    // serialize without panicking, and its class ID must still round-trip.
    let mut egraph = EGraph::default();
    let outputs = egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype Math-Expr (Lit i64))
            (Lit 5)
            (extract (Lit 5))
            "#,
        )
        .unwrap();
    let CommandOutput::ExtractBest(termdag, _cost, term) = outputs[0].clone() else {
        panic!();
    };
    let expr = termdag.term_to_expr(&term, span!());
    let (sort, value) = egraph.eval_expr(&expr).unwrap();
    assert_eq!(sort.name(), "Math-Expr");

    let serialize_output = egraph.serialize(SerializeConfig::default());
    assert!(serialize_output.is_complete());
    let class_id = egraph.value_to_class_id(&sort, value);
    assert!(serialize_output.egraph.class_data.get(&class_id).is_some());
    assert_eq!(value, egraph.class_id_to_value(&class_id));
}

#[test]
fn test_serialize_617() {
    let program = "
        (sort Node)
        (constructor mk (i64) Node)
        (constructor mkb (i64) Node)
        (rewrite (mkb x) (mk x))

        (mkb 1) (mkb 3) (mkb 5) (mkb 6)

        (union (mk 1) (mk 3))
        (union (mk 3) (mk 5))

        (run-schedule (saturate (run)))";

    let mut egraph = EGraph::default();
    egraph.parse_and_run_program(None, program).unwrap();

    let serialize_output = egraph.serialize(SerializeConfig::default());
    assert!(serialize_output.is_complete());
    assert_eq!(serialize_output.egraph.class_data.len(), 6);
    assert_eq!(serialize_output.egraph.nodes.len(), 12);
}

#[test]
fn test_serialize_subsume_status() {
    let mut egraph = EGraph::default();

    egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype Math)
            (constructor a () Math )
            (constructor b () Math )
            (a)
            (b)
            (subsume (a))
            "#,
        )
        .unwrap();

    let serialize_output = egraph.serialize(SerializeConfig::default());
    assert!(serialize_output.is_complete());
    let a_id = egraph.to_node_id(
        None,
        egglog::SerializedNode::Function {
            name: "a".into(),
            offset: 0,
        },
    );
    let b_id = egraph.to_node_id(
        None,
        egglog::SerializedNode::Function {
            name: "b".into(),
            offset: 0,
        },
    );
    assert!(serialize_output.egraph.nodes[&a_id].subsumed);
    assert!(!serialize_output.egraph.nodes[&b_id].subsumed);
}

#[test]
fn test_shadowing_query() {
    let s = "(function f () i64 :no-merge) (set (f) 2) (check (= (f) f) (= f 2))";
    let e = EGraph::default()
        .parse_and_run_program(None, s)
        .unwrap_err();
    assert!(matches!(e, Error::Shadowing(_, _, _)));
}

#[test]
fn test_shadowing_push() {
    let s = "(push) (let x 1) (pop) (let x 1)";
    EGraph::default().parse_and_run_program(None, s).unwrap();
}

#[test]
fn test_print_function_size() {
    let s = "(function f () i64 :no-merge) (set (f) 2) (print-size f)";
    let outputs = EGraph::default().parse_and_run_program(None, s).unwrap();
    assert_eq!(outputs[0].to_string(), "1\n");
}

#[test]
fn test_print_function() {
    let s = "(function f () i64 :no-merge) (set (f) 2) (print-function f)";
    let outputs = EGraph::default().parse_and_run_program(None, s).unwrap();
    assert_eq!(outputs[0].to_string(), "(\n   (f) -> 2\n)\n");
}

#[test]
fn function_to_dag_uses_logical_view_layout() {
    let s = "(datatype N (n :cost 0))
             (function f (i64 N) Unit :no-merge :internal-view constructor)
             (set (f 1 (n)) ())";
    let mut egraph = EGraph::default();
    egraph.parse_and_run_program(None, s).unwrap();
    let (inputs, outputs, termdag) = egraph.function_to_dag("f", 1, true).unwrap();
    assert_eq!(termdag.to_string(inputs[0]), "(f 1)");
    assert_eq!(termdag.to_string(outputs.unwrap()[0]), "(n)");
}

#[test]
fn test_print_function_csv() {
    let s = "(function f () i64 :no-merge) (set (f) 2) (print-function f :mode csv)";
    let outputs = EGraph::default().parse_and_run_program(None, s).unwrap();
    assert_eq!(outputs[0].to_string(), "f,2\n");
}

#[test]
fn test_print_stats() {
    let s = "(run 1) (print-stats)";
    let outputs = EGraph::default().parse_and_run_program(None, s).unwrap();
    assert_eq!(
        outputs[1].to_string(),
        "Overall statistics:\nRuleset : assembly 0.000s, search 0.000s, apply 0.000s, unattributed 0.000s, merge 0.000s\nNative rebuild: 0.000s\n"
    );
}

#[test]
fn test_run_report() {
    let s = "(run 1)";
    let outputs = EGraph::default().parse_and_run_program(None, s).unwrap();
    assert_eq!(outputs[0].to_string(), "");
    assert!(matches!(outputs[0], CommandOutput::RunSchedule(..)));
}

#[test]
fn test_serialize_message_max_functions() {
    let mut egraph = EGraph::default();
    // Create three zero-arg constructors
    egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype A)
            (constructor a () A)
            (constructor b () A)
            (constructor c () A)
            (a) (b) (c)
            "#,
        )
        .unwrap();
    let serialize_output = egraph.serialize(SerializeConfig {
        max_functions: Some(2),
        max_calls_per_function: None,
        include_temporary_functions: false,
        root_eclasses: vec![],
    });
    assert!(!serialize_output.is_complete());
    assert_eq!(serialize_output.omitted_description(), "Omitted: c\n");
}

#[test]
fn test_serialize_message_max_calls_per_function() {
    let mut egraph = EGraph::default();
    // Single constructor with many distinct calls (different arguments)
    egraph
        .parse_and_run_program(
            None,
            r#"
            (datatype N)
            (constructor mk (i64) N)
            (mk 0) (mk 1) (mk 2) (mk 3)
            "#,
        )
        .unwrap();
    let serialize_output = egraph.serialize(SerializeConfig {
        max_functions: None,
        max_calls_per_function: Some(2),
        include_temporary_functions: false,
        root_eclasses: vec![],
    });
    assert!(!serialize_output.is_complete());
    assert_eq!(serialize_output.omitted_description(), "Truncated: mk\n");
}

#[test]
fn eqsat_basic_term_encoding_roundtrip() {
    fn render_program(commands: &[ResolvedCommand]) -> String {
        let text = sanitize_internal_names(commands)
            .iter()
            .map(|cmd| cmd.to_string())
            .collect::<Vec<_>>()
            .join("\n");
        format!("{text}\n")
    }

    let path = std::path::Path::new("tests/web-demo/eqsat-basic.egg");
    let source = std::fs::read_to_string(path)
        .unwrap_or_else(|err| panic!("failed to read {}: {err}", path.display()));

    // 1. Desugar the program with term encoding enabled.
    let mut egraph = EGraph::new_with_term_encoding();
    let desugared_once = egraph
        .resolve_program(Some(path.display().to_string()), &source)
        .expect("term-encoding desugaring should succeed");
    let text_once = render_program(&desugared_once);

    // 2. Parse and desugar the rendered program with a fresh e-graph.
    let mut egraph = EGraph::default();
    let desugared_twice = egraph
        .resolve_program(None, &text_once)
        .expect("second desugaring should succeed");
    let text_twice = render_program(&desugared_twice);

    // 3. Parse and desugar again to ensure stability using another fresh e-graph.
    let mut egraph = EGraph::default();
    let desugared_thrice = egraph
        .resolve_program(None, &text_twice)
        .expect("third desugaring should succeed");
    let text_thrice = render_program(&desugared_thrice);

    assert_eq!(text_twice, text_thrice, "desugaring should stabilize");

    // 4. Run the stabilized program using term encoding.
    let mut runner = EGraph::default();
    runner
        .parse_and_run_program(None, &text_thrice)
        .expect("final program should execute successfully");
}

#[test]
fn rewrite_name_basic() {
    let mut egraph = EGraph::default();
    egraph
        .parse_and_run_program(
            None,
            "
            (datatype Math (Num i64) (Mul Math Math))
            (rewrite (Mul a (Num 1)) a :name \"mul-identity\")
            (let $x (Mul (Num 42) (Num 1)))
            (run 3)
            (check (= $x (Num 42)))
            ",
        )
        .unwrap();
}

#[test]
fn rewrite_name_birewrite() {
    let mut egraph = EGraph::default();
    egraph
        .parse_and_run_program(
            None,
            "
            (datatype Math (Num i64) (Add Math Math))
            (birewrite (Add a b) (Add b a) :name \"add-comm\")
            (let $x (Add (Num 1) (Num 2)))
            (run 3)
            (check (= $x (Add (Num 2) (Num 1))))
            ",
        )
        .unwrap();
}

#[test]
fn rewrite_name_desugars_correctly() {
    let mut egraph = EGraph::default();
    let desugared = egraph
        .resolve_program(
            None,
            "
            (datatype Math (Num i64) (Mul Math Math) (Add Math Math))
            (rewrite (Mul a (Num 1)) a :name \"mul-identity\")
            (birewrite (Add a b) (Add b a) :name \"add-comm\")
            ",
        )
        .unwrap();

    let joined: String = desugared
        .iter()
        .map(|cmd| format!("{cmd}"))
        .collect::<Vec<_>>()
        .join("\n");

    assert!(
        joined.contains("mul-identity"),
        "expected 'mul-identity' in:\n{joined}"
    );
    assert!(
        joined.contains("add-comm=>"),
        "expected 'add-comm=>' in:\n{joined}"
    );
    assert!(
        joined.contains("add-comm<="),
        "expected 'add-comm<=' in:\n{joined}"
    );
}

#[test]
fn rewrite_without_name_still_works() {
    let mut egraph = EGraph::default();
    egraph
        .parse_and_run_program(
            None,
            "
            (datatype Math (Num i64) (Add Math Math))
            (rewrite (Add a b) (Add b a))
            (let $x (Add (Num 1) (Num 2)))
            (run 3)
            (check (= $x (Add (Num 2) (Num 1))))
            ",
        )
        .unwrap();
}

#[test]
fn rewrite_name_with_ruleset() {
    let mut egraph = EGraph::default();
    egraph
        .parse_and_run_program(
            None,
            "
            (datatype Math (Num i64) (Mul Math Math))
            (ruleset my-rules)
            (rewrite (Mul a (Num 0)) (Num 0) :name \"mul-zero\" :ruleset my-rules)
            (let $x (Mul (Num 99) (Num 0)))
            (run my-rules 3)
            (check (= $x (Num 0)))
            ",
        )
        .unwrap();
}

// =====================================================================
// `clear_function` tests.
//
// The clear path bumps the table's major generation, which is the
// source of most subtle bugs: cached subsets, hash indexes, seminaive
// watermarks, and `RowId` values from the old generation must all be
// invalidated lazily before the next read/write touches them. Each
// test below threads several such failure modes together so the same
// e-graph exercises a realistic sequence rather than one assertion at
// a time.
// =====================================================================

/// Single-function lifecycle: declare → no-op clear of empty table →
/// populate → assert the three different read paths agree on the
/// contents (`get_size`, `eclass_of`, `constructor_enodes`) →
/// clear → assert all three read paths report empty → re-insert with
/// completely new keys → assert the old keys are gone and the new
/// ones are present. Run the populate/clear/re-insert pass repeatedly
/// to make sure the generation counter and the index-reset path keep
/// working past the first cycle.
#[test]
fn clear_function_lifecycle() {
    let mut egraph = EGraph::default();
    egraph
        .parse_and_run_program(None, "(datatype Math (Num i64))")
        .unwrap();

    // Clearing an empty function is a no-op (and does it twice to
    // exercise the `data.len() == 0` early-return inside
    // `SortedWritesTable::clear`).
    assert_eq!(egraph.get_size("Num"), 0);
    egraph.clear_function("Num").unwrap();
    egraph.clear_function("Num").unwrap();
    assert_eq!(egraph.get_size("Num"), 0);

    for round in 0..3i64 {
        let a = round * 10;
        let b = round * 10 + 1;
        let c = round * 10 + 2;

        // Populate, then read through all three paths to warm caches
        // (and any per-table indexes) before we clear.
        egraph
            .parse_and_run_program(None, &format!("(Num {a}) (Num {b}) (Num {c})"))
            .unwrap();
        assert_eq!(egraph.get_size("Num"), 3);

        let key_a = egraph.base_to_value::<i64>(a);
        assert!(
            egraph
                .update(|fs| fs.eclass_of("Num", key_a))
                .unwrap()
                .is_some()
        );

        let mut seen = 0;
        egraph
            .update(|fs| fs.constructor_enodes("Num", |_| seen += 1))
            .unwrap();
        assert_eq!(seen, 3);

        // Now clear and re-read through every access path: each must
        // observe the new (empty) generation, not phantom rows from
        // before the generation bump.
        egraph.clear_function("Num").unwrap();
        assert_eq!(egraph.get_size("Num"), 0);
        assert!(
            egraph
                .update(|fs| fs.eclass_of("Num", key_a))
                .unwrap()
                .is_none()
        );
        let mut seen_after = 0;
        egraph
            .update(|fs| fs.constructor_enodes("Num", |_| seen_after += 1))
            .unwrap();
        assert_eq!(seen_after, 0);
        let check_old = egraph.parse_and_run_program(None, &format!("(check (Num {a}))"));
        assert!(
            check_old.is_err(),
            "round {round}: (Num {a}) should be absent after clear, got {check_old:?}"
        );
    }
}

/// Cross-cutting scenario: a rule that derives from one function,
/// a sibling function we expect not to touch, a `:merge` function
/// whose accumulator state must be reset, and an index over the
/// cleared function that was warmed by an earlier rule run.
///
/// The scenario verifies, in order:
///   1. `clear_function` only clears the named function, not the
///      sibling `Sym` and not the derived `Saw` populated by a rule.
///   2. The `:merge` accumulator on `score` resets — a write after
///      the clear does not silently re-merge with the old value.
///   3. The cleared `Num` does not yield phantom rows via the rule's
///      cached index over the old generation.
///   4. After re-insert, the rule re-fires on the new `Num` rows,
///      which catches seminaive-watermark-not-invalidated bugs.
#[test]
fn clear_function_with_rules_siblings_and_merge() {
    let mut egraph = EGraph::default();
    egraph
        .parse_and_run_program(
            None,
            "
            (datatype Math (Num i64) (Sym i64))
            (relation Saw (i64))
            (rule ((Num x)) ((Saw x)))
            (function score (i64) i64 :merge (max old new))

            (Num 1) (Num 2) (Num 3)
            (Sym 10) (Sym 20)
            (set (score 7) 5)
            (set (score 7) 10)
            (set (score 7) 8)
            (run 1)
            (check (Saw 1)) (check (Saw 2)) (check (Saw 3))
            (check (= (score 7) 10))
            ",
        )
        .unwrap();
    assert_eq!(egraph.get_size("Num"), 3);
    assert_eq!(egraph.get_size("Sym"), 2);
    assert_eq!(egraph.get_size("Saw"), 3);
    assert_eq!(egraph.get_size("score"), 1);

    // (1) Clear Num and score. Sym is a sibling datatype constructor;
    // Saw is derived data populated by the rule. Neither should be
    // affected.
    egraph.clear_function("Num").unwrap();
    egraph.clear_function("score").unwrap();
    assert_eq!(egraph.get_size("Num"), 0);
    assert_eq!(egraph.get_size("score"), 0);
    assert_eq!(egraph.get_size("Sym"), 2);
    assert_eq!(egraph.get_size("Saw"), 3);
    egraph
        .parse_and_run_program(None, "(check (Sym 10))")
        .unwrap();

    // (3) The cleared Num must not yield phantom rows via a cached
    // index — the major-generation bump on clear should force the
    // index to rebuild before the check runs.
    let phantom = egraph.parse_and_run_program(None, "(check (Num 1))");
    assert!(
        phantom.is_err(),
        "old (Num 1) should not be findable after clear, got: {phantom:?}"
    );

    // (2) Repopulate `score` with a smaller value than the cleared
    // accumulator. If the merge state survived the clear, the next
    // line's `check` would see 10 instead of 3.
    egraph
        .parse_and_run_program(
            None,
            "
            (set (score 7) 3)
            (check (= (score 7) 3))
            ",
        )
        .unwrap();

    // (4) Re-insert into Num and re-run the rule. The rule must fire
    // on the new rows, which exercises the seminaive watermark and
    // the rule's table index after a generation bump.
    egraph
        .parse_and_run_program(
            None,
            "
            (Num 100) (Num 200)
            (run 1)
            (check (Saw 100)) (check (Saw 200))
            ",
        )
        .unwrap();
    // 3 original Saw rows + 2 from the new run = 5.
    assert_eq!(egraph.get_size("Saw"), 5);
}

/// `clear_function` on a name that was never declared returns an
/// `UnboundFunction` error rather than panicking. Kept standalone
/// because there's nothing to thread through — the e-graph never
/// transitions out of its empty starting state.
#[test]
fn clear_function_unknown_function_errors() {
    let mut egraph = EGraph::default();
    let err = egraph.clear_function("DoesNotExist").unwrap_err();
    match err {
        Error::TypeError(TypeError::UnboundFunction(name, _)) => {
            assert_eq!(name, "DoesNotExist");
        }
        other => panic!("expected UnboundFunction, got {other:?}"),
    }
}

/// A declared index has a function type but no table of its own, so `input`
/// errors instead of panicking on the missing table. All-`i64` columns, so the
/// error comes from the index check and not from `input`'s sort support check.
#[test]
fn input_into_index_errors() {
    let mut egraph = EGraph::default();
    egraph
        .parse_and_run_program(
            None,
            "(function f (i64 i64) i64 :merge old)\n(index FOcc f (any 0 1 2))",
        )
        .unwrap();
    let err = egraph
        .parse_and_run_program(None, "(input FOcc \"rows.tsv\")")
        .unwrap_err();
    match err {
        Error::TypeError(TypeError::IndexIsReadOnly(name, _)) => assert_eq!(name, "FOcc"),
        other => panic!("expected IndexIsReadOnly, got {other:?}"),
    }
}

/// An index reads a function's rows; another index has none to read. Rejected
/// at the declaration rather than when a rule first queries it.
#[test]
fn index_over_index_errors() {
    let mut egraph = EGraph::default();
    egraph
        .parse_and_run_program(
            None,
            "(function f (i64 i64) i64 :merge old)\n(index FOcc f (any 0 1 2))",
        )
        .unwrap();
    let err = egraph
        .parse_and_run_program(None, "(index FOcc2 FOcc (any 0))")
        .unwrap_err();
    match err {
        Error::TypeError(TypeError::IndexOfIndex(name, indexed, _)) => {
            assert_eq!((name.as_str(), indexed.as_str()), ("FOcc2", "FOcc"));
        }
        other => panic!("expected IndexOfIndex, got {other:?}"),
    }
}
