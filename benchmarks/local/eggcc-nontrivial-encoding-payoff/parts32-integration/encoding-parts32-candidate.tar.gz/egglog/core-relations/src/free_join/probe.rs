//! Adapt catalog, shared-root, residual, and packed indexes to join probes.

use std::{
    cell::{OnceCell, RefCell},
    cmp,
    sync::Arc,
};

use egglog_concurrency::{Handle, SharedArena};
use smallvec::SmallVec;

use crate::{
    common::Value,
    hash_index::{ColumnIndex, Index, IndexPosition, TupleIndex},
    offsets::{OffsetRange, RowId, SubsetRef},
    table_spec::{Constraint, WrappedTableRef},
};

use super::{
    AtomId, ColumnIds,
    frame_update::FrameUpdates,
    packed_cache::{RootProjection, TrieRoot},
    packed_trie::{ChildShape, PackedCursor, TrieNode},
    plan::{ScanSpec, SingleScanSpec},
    prepared_index::{AccessId, ContinuationPosition, PreparedIndexRef, RootContinuationCache},
    residual_index::{InlineRows, SmallColumnIndex, SmallExactProbe},
};

/// Intersect a `SubsetRef` with a dense `OffsetRange` and return the result as a
/// borrowed `SubsetRef`, or `None` if the intersection is empty.
///
/// This function never allocates — it borrows into
/// the source data via `subslice`. Use this in `for_each` paths where the result
/// may be discarded (e.g., empty after refinement), to avoid pool allocations.
#[inline]
pub(super) fn intersect_with_dense_ref<'a>(
    v: SubsetRef<'a>,
    range: OffsetRange,
) -> Option<SubsetRef<'a>> {
    match v {
        SubsetRef::Dense(r) => {
            let resl = cmp::max(r.start, range.start);
            let resr = cmp::min(r.end, range.end);
            if resl >= resr {
                None
            } else {
                Some(SubsetRef::Dense(OffsetRange::new(resl, resr)))
            }
        }
        SubsetRef::Sparse(s) => {
            let l = s.binary_search_by_id(range.start);
            let r = s.binary_search_from(l, range.end);
            if l >= r {
                None
            } else {
                Some(SubsetRef::Sparse(s.subslice(l, r)))
            }
        }
    }
}

/// Seek `key` in a sorted scalar index without moving backward.
///
/// Exponential search followed by a bounded binary search avoids walking a
/// large target when the sorted query is sparse.
pub(super) fn seek_sorted_key(
    key: Value,
    target_len: usize,
    target_cursor: &mut usize,
    target_at: impl Fn(usize) -> Value,
) -> bool {
    if *target_cursor >= target_len {
        return false;
    }

    let current = target_at(*target_cursor);
    match current.cmp(&key) {
        cmp::Ordering::Equal => true,
        cmp::Ordering::Greater => false,
        cmp::Ordering::Less => {
            let base = *target_cursor;
            let mut step = 1usize;
            while let Some(position) = base.checked_add(step).filter(|&pos| pos < target_len) {
                if target_at(position) >= key {
                    break;
                }
                let Some(next) = step.checked_mul(2) else {
                    step = target_len;
                    break;
                };
                step = next;
            }

            let previous = step / 2;
            let mut lo = base
                .saturating_add(previous)
                .saturating_add(1)
                .min(target_len);
            let mut hi = base.saturating_add(step).saturating_add(1).min(target_len);
            while lo < hi {
                let mid = lo + (hi - lo) / 2;
                if target_at(mid) < key {
                    lo = mid + 1;
                } else {
                    hi = mid;
                }
            }
            *target_cursor = lo;
            if lo >= target_len {
                return false;
            }
            target_at(lo) == key
        }
    }
}

/// A plan-local continuation for rows borrowed from a catalog or root index.
#[derive(Clone, Copy)]
pub(super) struct CatalogContinuation<'rows> {
    pub(super) cache: &'rows RootContinuationCache,
    pub(super) position: ContinuationPosition,
}

/// The rows currently associated with an atom during one plan execution.
/// Roots retain ownership of their header-filtered subset. An indexed cursor
/// borrows a first-level group from either a prepared persistent index or a
/// shared round-local root index and carries a plan-local continuation slot.
/// Every lower cursor is just a packed node plus a key ordinal. Dense
/// singletons come from cover scans and are packed lazily if the atom is probed
/// again.
#[derive(Clone)]
pub(super) enum AtomRows<'rows, 'exec> {
    Root(Arc<TrieRoot>),
    Catalog {
        subset: SubsetRef<'rows>,
        continuation: Option<CatalogContinuation<'rows>>,
    },
    Packed(PackedCursor<'rows, 'exec>),
    /// Owned small residual passed directly between buffered or parallel
    /// frames. Unlike `Catalog` and `Packed`, this variant borrows no index or
    /// arena storage.
    Inline(InlineRows),
    Dense(OffsetRange),
}

impl std::fmt::Debug for AtomRows<'_, '_> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("AtomRows")
            .field("kind", &self.kind_name())
            .field("size", &self.size())
            .finish()
    }
}

impl<'rows, 'exec> AtomRows<'rows, 'exec>
where
    'exec: 'rows,
{
    /// A short representation label used by the custom [`std::fmt::Debug`]
    /// output. The underlying row sets may be large, so diagnostics report only
    /// this label and their cardinality rather than formatting their contents.
    fn kind_name(&self) -> &'static str {
        match self {
            Self::Root(_) => "root",
            Self::Catalog { .. } => "catalog",
            Self::Packed(_) => "packed",
            Self::Inline(_) => "inline",
            Self::Dense(_) => "dense",
        }
    }

    pub(super) fn subset(&self) -> SubsetRef<'_> {
        match self {
            Self::Root(root) => root.subset.as_ref(),
            Self::Catalog { subset, .. } => *subset,
            Self::Packed(cursor) => cursor.subset(),
            Self::Inline(rows) => rows.subset(),
            Self::Dense(range) => SubsetRef::Dense(*range),
        }
    }

    pub(super) fn size(&self) -> usize {
        match self {
            Self::Packed(cursor) => cursor.size(),
            _ => self.subset().size(),
        }
    }

    pub(super) fn is_empty(&self) -> bool {
        self.size() == 0
    }

    #[cfg(test)]
    pub(super) fn root_arc(&self) -> &Arc<TrieRoot> {
        let Self::Root(root) = self else {
            panic!("expected root rows")
        };
        root
    }
}

impl<'rows, 'exec> From<Arc<TrieRoot>> for AtomRows<'rows, 'exec> {
    fn from(root: Arc<TrieRoot>) -> Self {
        Self::Root(root)
    }
}

/// Physical strategies available for looking up or enumerating the current
/// rows of one atom. `JoinState::get_index` chooses one variant for each
/// logical scan based on the source subset, requested columns, and whether a
/// reusable table index is valid.
pub(super) enum ProbeIndex<'ctx, 'rows, 'exec> {
    /// A persistent, fully refreshed multi-column table index. This is used for
    /// a large dense root with cacheable columns and no additional constraints.
    /// Stale candidates are allowed only when rows are retained for a later
    /// cover and `child_shape` is `Leaf`: that cover filters them before emitting
    /// matches. Other uses require live rows. `intersect_outer` clips results
    /// when the root is a dense subrange rather than the whole table.
    CachedTuple {
        intersect_outer: Option<OffsetRange>,
        table: &'rows Index<TupleIndex>,
        continuations: &'rows RootContinuationCache,
        child_shape: ChildShape,
    },
    /// The single-column counterpart of [`Self::CachedTuple`], also used for
    /// occurrence indexes, with the same candidate-liveness requirements.
    CachedColumn {
        intersect_outer: Option<OffsetRange>,
        table: &'rows Index<ColumnIndex>,
        continuations: &'rows RootContinuationCache,
        child_shape: ChildShape,
    },
    /// A first-column index shared by plans that start from the same filtered
    /// root subset. This is used when a shared root exists but the persistent
    /// catalog fast path is invalid, for example because the root is sparse or
    /// the scan has additional constraints.
    ProjectedRoot(RootProjectionProbe<'ctx, 'rows, 'exec>),
    /// An inline scalar index for a source containing at most
    /// [`super::residual_index::SMALL_RESIDUAL`] rows. It supports both exact lookup and enumeration
    /// without constructing a general packed trie.
    SmallColumn(SmallColumnIndex),
    /// An exact-only multi-column probe over an inline residual. Join stages
    /// select it when the source is already [`AtomRows::Inline`]; it scans those
    /// few rows directly and is never used as an enumeration leader.
    SmallExact(SmallExactProbe<'ctx>),
    /// The general fallback: an arena-allocated packed trie over an arbitrary
    /// source subset, with lower column indexes constructed lazily.
    Packed(PackedProbe<'ctx, 'rows, 'exec>),
}

/// Borrowed, ordered scalar keys used by merge and galloping intersections.
#[derive(Clone, Copy)]
pub(super) enum SortedScalarProbe<'a, 'exec> {
    Projected(&'a RootProjection),
    Small(&'a SmallColumnIndex),
    Packed(&'a TrieNode<'exec>),
}

impl SortedScalarProbe<'_, '_> {
    pub(super) fn len(self) -> usize {
        match self {
            Self::Projected(index) => index.len(),
            Self::Small(index) => index.n_keys,
            Self::Packed(index) => index.values().len(),
        }
    }

    pub(super) fn value_at(self, key_index: usize) -> Value {
        match self {
            Self::Projected(index) => index.value_at(key_index),
            Self::Small(index) => index.keys[key_index],
            Self::Packed(index) => index.values()[key_index],
        }
    }
}

/// A successful probe either carries rows needed by a later stage or only
/// records existence when this atom is dead in the remaining join tail. The
/// latter case avoids copying an inline subset into every buffered frame.
pub(super) enum ProbeMatch<'rows, 'exec> {
    Present,
    Rows(AtomRows<'rows, 'exec>),
}

/// Worker-local arena handle initialized only by a path that actually builds
/// a packed node. Cover-only queries and scalar projected-root probes never
/// touch the arena allocator.
pub(super) struct LazyArenaHandle<'exec> {
    arena: &'exec SharedArena,
    handle: OnceCell<Handle<'exec>>,
}

impl<'exec> LazyArenaHandle<'exec> {
    pub(super) fn new(arena: &'exec SharedArena) -> Self {
        Self {
            arena,
            handle: OnceCell::new(),
        }
    }

    pub(super) fn get(&self) -> &Handle<'exec> {
        self.handle.get_or_init(|| self.arena.new_handle())
    }
}

impl<'rows, 'exec> ProbeMatch<'rows, 'exec> {
    #[inline]
    pub(super) fn refine(self, atom: AtomId, updates: &mut FrameUpdates<'rows, 'exec>) {
        if let Self::Rows(rows) = self {
            updates.refine_atom(atom, rows);
        }
    }
}

pub(super) struct PackedProbe<'ctx, 'rows, 'exec> {
    pub(super) first: &'rows TrieNode<'exec>,
    pub(super) columns: ColumnIds,
    pub(super) table: WrappedTableRef<'ctx>,
    pub(super) handle: &'ctx LazyArenaHandle<'exec>,
    pub(super) scratch: &'ctx RefCell<Vec<(Value, RowId)>>,
    pub(super) terminal_child_shape: ChildShape,
}

/// Probes a first-column grouping shared by plans with the same root subset.
///
/// A root projection is an execution-local index that groups a root's rows by
/// one requested column and stores each distinct value beside its matching row
/// subset. `JoinState::get_index` selects this representation when the atom
/// has a cross-plan shared root but cannot use a persistent table index, such
/// as when header or scan constraints have filtered the root. The grouping is
/// built once and reused directly by every qualifying plan.
///
/// For a one-column scan, this object returns the shared row subset. For a
/// multi-column scan, only the first grouping is shared; subsequent packed
/// trie nodes and their continuation slots remain local to this query.
pub(super) struct RootProjectionProbe<'ctx, 'rows, 'exec> {
    pub(super) first: &'rows RootProjection,
    pub(super) columns: ColumnIds,
    pub(super) table: WrappedTableRef<'ctx>,
    pub(super) continuations: &'rows RootContinuationCache,
    pub(super) access: AccessId,
    pub(super) handle: &'ctx LazyArenaHandle<'exec>,
    pub(super) scratch: &'ctx RefCell<Vec<(Value, RowId)>>,
    pub(super) terminal_child_shape: ChildShape,
}

impl<'ctx, 'rows, 'exec> RootProjectionProbe<'ctx, 'rows, 'exec>
where
    'exec: 'rows,
{
    fn scalar_rows(&self, key_index: usize) -> AtomRows<'rows, 'exec> {
        debug_assert_eq!(self.columns.len(), 1);
        AtomRows::Catalog {
            subset: self.first.subset_at(key_index),
            continuation: (self.terminal_child_shape != ChildShape::Leaf).then_some(
                CatalogContinuation {
                    cache: self.continuations,
                    position: ContinuationPosition::unsharded(key_index),
                },
            ),
        }
    }

    fn first_child(&self, key_index: usize) -> &'exec TrieNode<'exec> {
        debug_assert!(self.columns.len() > 1);
        let child_shape = if self.columns.len() > 2 {
            ChildShape::Direct
        } else {
            self.terminal_child_shape
        };
        let slot = self
            .continuations
            .slot(ContinuationPosition::unsharded(key_index), self.access);
        let address = *slot.get_or_init(|| {
            TrieNode::build_from_subset(
                self.handle.get(),
                self.table,
                self.first.subset_at(key_index),
                self.columns[1],
                child_shape,
                &mut self.scratch.borrow_mut(),
            ) as *const TrieNode<'exec> as usize
        });
        // SAFETY: this continuation cache belongs to the prepared query and can
        // only publish nodes allocated by the same query's SharedArena.
        let child = unsafe { &*(address as *const TrieNode<'exec>) };
        assert_eq!(child.child_shape(), child_shape);
        child
    }

    fn get(&self, key: &[Value]) -> Option<AtomRows<'rows, 'exec>> {
        debug_assert_eq!(key.len(), self.columns.len());
        let first_index = self.first.find(key[0])?;
        if self.columns.len() == 1 {
            return Some(self.scalar_rows(first_index));
        }

        let mut node = self.first_child(first_index);
        let mut terminal = None;
        for (depth, &value) in key.iter().enumerate().skip(1) {
            let cursor = PackedCursor::new(node, node.find(value)?);
            terminal = Some(cursor);
            if depth + 1 < self.columns.len() {
                let child_shape = if depth + 2 < self.columns.len() {
                    ChildShape::Direct
                } else {
                    self.terminal_child_shape
                };
                node = cursor.child_index(
                    self.handle.get(),
                    self.table,
                    self.columns[depth + 1],
                    0,
                    child_shape,
                    &mut self.scratch.borrow_mut(),
                );
            }
        }
        terminal.map(AtomRows::Packed)
    }

    fn for_each_packed(
        &self,
        node: &'rows TrieNode<'exec>,
        depth: usize,
        key: &mut SmallVec<[Value; 4]>,
        f: &mut impl FnMut(&[Value], AtomRows<'rows, 'exec>),
    ) {
        for (key_index, &value) in node.values().iter().enumerate() {
            key.push(value);
            let cursor = PackedCursor::new(node, key_index);
            if depth + 1 == self.columns.len() {
                f(key, AtomRows::Packed(cursor));
            } else {
                let child_shape = if depth + 2 < self.columns.len() {
                    ChildShape::Direct
                } else {
                    self.terminal_child_shape
                };
                let child = cursor.child_index(
                    self.handle.get(),
                    self.table,
                    self.columns[depth + 1],
                    0,
                    child_shape,
                    &mut self.scratch.borrow_mut(),
                );
                self.for_each_packed(child, depth + 1, key, f);
            }
            key.pop();
        }
    }

    fn for_each(&self, f: &mut impl FnMut(&[Value], AtomRows<'rows, 'exec>)) {
        let mut key = SmallVec::new();
        for key_index in 0..self.first.len() {
            key.push(self.first.value_at(key_index));
            if self.columns.len() == 1 {
                f(&key, self.scalar_rows(key_index));
            } else {
                let child = self.first_child(key_index);
                self.for_each_packed(child, 1, &mut key, f);
            }
            key.pop();
        }
    }
}

impl<'ctx, 'rows, 'exec> PackedProbe<'ctx, 'rows, 'exec>
where
    'exec: 'rows,
{
    fn get(&self, key: &[Value]) -> Option<AtomRows<'rows, 'exec>> {
        debug_assert_eq!(key.len(), self.columns.len());
        let mut node = self.first;
        let mut terminal = None;
        for (depth, (&_column, &value)) in self.columns.iter().zip(key).enumerate() {
            let cursor = PackedCursor::new(node, node.find(value)?);
            terminal = Some(cursor);
            if depth + 1 < self.columns.len() {
                let child_shape = if depth + 2 < self.columns.len() {
                    ChildShape::Direct
                } else {
                    self.terminal_child_shape
                };
                node = cursor.child_index(
                    self.handle.get(),
                    self.table,
                    self.columns[depth + 1],
                    0,
                    child_shape,
                    &mut self.scratch.borrow_mut(),
                );
            }
        }
        terminal.map(AtomRows::Packed)
    }

    fn for_each_recur(
        &self,
        node: &'rows TrieNode<'exec>,
        depth: usize,
        key: &mut SmallVec<[Value; 4]>,
        f: &mut impl FnMut(&[Value], AtomRows<'rows, 'exec>),
    ) {
        for (key_index, &value) in node.values().iter().enumerate() {
            key.push(value);
            let cursor = PackedCursor::new(node, key_index);
            if depth + 1 == self.columns.len() {
                f(key, AtomRows::Packed(cursor));
            } else {
                let child_shape = if depth + 2 < self.columns.len() {
                    ChildShape::Direct
                } else {
                    self.terminal_child_shape
                };
                let child = cursor.child_index(
                    self.handle.get(),
                    self.table,
                    self.columns[depth + 1],
                    0,
                    child_shape,
                    &mut self.scratch.borrow_mut(),
                );
                self.for_each_recur(child, depth + 1, key, f);
            }
            key.pop();
        }
    }

    fn for_each(&self, f: &mut impl FnMut(&[Value], AtomRows<'rows, 'exec>)) {
        let mut key = SmallVec::new();
        self.for_each_recur(self.first, 0, &mut key, f);
    }
}

pub(super) struct Prober<'ctx, 'rows, 'exec> {
    pub(super) source: AtomRows<'rows, 'exec>,
    pub(super) ix: ProbeIndex<'ctx, 'rows, 'exec>,
    /// Whether a match returns [`ProbeMatch::Rows`] so a later stage can probe,
    /// scan, or materialize this atom's refined rows. If the atom is never read
    /// again, return only [`ProbeMatch::Present`] and skip refining its frame.
    /// This can be true even with [`ChildShape::Leaf`]: a later cover scan needs
    /// the rows without needing another column index.
    pub(super) keep_rows: bool,
}

/// Normalized input to `JoinState::get_index` for one indexed scan.
///
/// Both scalar [`SingleScanSpec`]s and tuple [`ScanSpec`]s are converted to
/// this form so physical-strategy selection has one code path. It identifies
/// the atom and projected columns, carries constraints that must be applied to
/// the source rows, records whether later stages need the matching rows or only
/// existence, and supplies the prepared sidecar slot used for cached indexes
/// and continuations. `terminal_child_shape` describes how execution may
/// continue after the final requested column.
pub(super) struct ProbeRequest<'scan, 'rows> {
    pub(super) atom: AtomId,
    pub(super) columns: ColumnIds,
    /// Read a scalar key occurring in any projected column.
    pub(super) occurrence: bool,
    pub(super) constraints: &'scan [Constraint],
    pub(super) keep_rows: bool,
    pub(super) terminal_child_shape: ChildShape,
    pub(super) prepared: PreparedIndexRef<'rows>,
}

impl<'scan, 'rows> ProbeRequest<'scan, 'rows> {
    pub(super) fn column(
        scan: &'scan SingleScanSpec,
        keep_rows: bool,
        terminal_child_shape: ChildShape,
        prepared: PreparedIndexRef<'rows>,
    ) -> Self {
        Self {
            atom: scan.atom,
            columns: scan
                .occurrence_cols
                .clone()
                .unwrap_or_else(|| smallvec::smallvec![scan.column]),
            occurrence: scan.occurrence_cols.is_some(),
            constraints: &scan.cs,
            keep_rows,
            terminal_child_shape,
            prepared,
        }
    }

    pub(super) fn tuple(
        scan: &'scan ScanSpec,
        keep_rows: bool,
        terminal_child_shape: ChildShape,
        prepared: PreparedIndexRef<'rows>,
    ) -> Self {
        Self {
            atom: scan.to_index.atom,
            columns: scan.to_index.vars.clone(),
            occurrence: scan.occurrence_cols.is_some(),
            constraints: &scan.constraints,
            keep_rows,
            terminal_child_shape,
            prepared,
        }
    }
}

impl<'ctx, 'rows, 'exec> Prober<'ctx, 'rows, 'exec>
where
    'exec: 'rows,
{
    fn keep_or_discard(rows: AtomRows<'rows, 'exec>, keep_rows: bool) -> ProbeMatch<'rows, 'exec> {
        if keep_rows {
            ProbeMatch::Rows(rows)
        } else {
            ProbeMatch::Present
        }
    }

    fn catalog_match(
        position: IndexPosition,
        subset: SubsetRef<'rows>,
        continuations: &'rows RootContinuationCache,
        keep_rows: bool,
        child_shape: ChildShape,
    ) -> ProbeMatch<'rows, 'exec> {
        if keep_rows {
            ProbeMatch::Rows(AtomRows::Catalog {
                subset,
                continuation: (child_shape != ChildShape::Leaf).then_some(CatalogContinuation {
                    cache: continuations,
                    position: position.into(),
                }),
            })
        } else {
            ProbeMatch::Present
        }
    }

    /// Return the result of a persistent catalog lookup when this access cannot
    /// need another indexed column of the same atom.
    ///
    /// A nonterminal catalog result retains its [`IndexPosition`] so a later
    /// access can use the corresponding continuation slot to publish a packed
    /// child index. Here the planned child shape is a leaf, or the caller only
    /// needs to know whether a match exists, so that position would never be
    /// used. If `keep_rows` is true, the leaf's subset is still preserved for a
    /// later cover or materialization barrier; it is stored with no
    /// continuation. Otherwise the result is reduced to `Present` immediately.
    fn terminal_catalog_match(
        subset: SubsetRef<'rows>,
        keep_rows: bool,
    ) -> ProbeMatch<'rows, 'exec> {
        if keep_rows {
            ProbeMatch::Rows(AtomRows::Catalog {
                subset,
                continuation: None,
            })
        } else {
            ProbeMatch::Present
        }
    }

    pub(super) fn get_subset(&self, key: &[Value]) -> Option<ProbeMatch<'rows, 'exec>> {
        match &self.ix {
            ProbeIndex::CachedTuple {
                intersect_outer,
                table,
                continuations,
                child_shape,
            } => {
                let table: &'rows Index<TupleIndex> = table;
                if *child_shape == ChildShape::Leaf || !self.keep_rows {
                    debug_assert!(self.keep_rows || *child_shape == ChildShape::Leaf);
                    let subset = table.get_subset(key)?;
                    let subset = if let Some(range) = intersect_outer {
                        intersect_with_dense_ref(subset, *range)?
                    } else {
                        subset
                    };
                    return Some(Self::terminal_catalog_match(subset, self.keep_rows));
                }
                let (position, subset) = table.get_subset_positioned(key)?;
                let subset = if let Some(range) = intersect_outer {
                    intersect_with_dense_ref(subset, *range)?
                } else {
                    subset
                };
                Some(Self::catalog_match(
                    position,
                    subset,
                    continuations,
                    self.keep_rows,
                    *child_shape,
                ))
            }
            ProbeIndex::CachedColumn {
                intersect_outer,
                table,
                continuations,
                child_shape,
            } => {
                debug_assert_eq!(key.len(), 1);
                let table: &'rows Index<ColumnIndex> = table;
                if *child_shape == ChildShape::Leaf || !self.keep_rows {
                    debug_assert!(self.keep_rows || *child_shape == ChildShape::Leaf);
                    let subset = table.get_subset(&key[0])?;
                    let subset = if let Some(range) = intersect_outer {
                        intersect_with_dense_ref(subset, *range)?
                    } else {
                        subset
                    };
                    return Some(Self::terminal_catalog_match(subset, self.keep_rows));
                }
                let (position, subset) = table.get_subset_positioned(&key[0])?;
                let subset = if let Some(range) = intersect_outer {
                    intersect_with_dense_ref(subset, *range)?
                } else {
                    subset
                };
                Some(Self::catalog_match(
                    position,
                    subset,
                    continuations,
                    self.keep_rows,
                    *child_shape,
                ))
            }
            ProbeIndex::ProjectedRoot(projected) => projected
                .get(key)
                .map(|rows| Self::keep_or_discard(rows, self.keep_rows)),
            ProbeIndex::SmallColumn(index) => {
                let [value] = key else {
                    return None;
                };
                let key_index = index.find(*value)?;
                Some(if self.keep_rows {
                    ProbeMatch::Rows(AtomRows::Inline(index.rows_at(key_index)))
                } else {
                    ProbeMatch::Present
                })
            }
            ProbeIndex::SmallExact(exact) => exact.get(key, self.keep_rows),
            ProbeIndex::Packed(packed) => packed
                .get(key)
                .map(|rows| Self::keep_or_discard(rows, self.keep_rows)),
        }
    }

    /// Borrow the ordered keys when this probe supports scalar intersection.
    pub(super) fn sorted_scalar_probe(&self) -> Option<SortedScalarProbe<'_, 'exec>> {
        match &self.ix {
            ProbeIndex::ProjectedRoot(projected) if projected.columns.len() == 1 => {
                Some(SortedScalarProbe::Projected(projected.first))
            }
            ProbeIndex::SmallColumn(index) => Some(SortedScalarProbe::Small(index)),
            ProbeIndex::Packed(packed) if packed.columns.len() == 1 => {
                Some(SortedScalarProbe::Packed(packed.first))
            }
            ProbeIndex::CachedTuple { .. }
            | ProbeIndex::CachedColumn { .. }
            | ProbeIndex::ProjectedRoot(..)
            | ProbeIndex::SmallExact(..)
            | ProbeIndex::Packed(..) => None,
        }
    }

    /// Reconstruct the match at an ordinal returned by a sorted scalar probe.
    /// Preserves the row-retention policy used by ordinary key lookup.
    pub(super) fn sorted_match_at(&self, key_index: usize) -> ProbeMatch<'rows, 'exec> {
        match &self.ix {
            ProbeIndex::ProjectedRoot(projected) if projected.columns.len() == 1 => {
                Self::keep_or_discard(projected.scalar_rows(key_index), self.keep_rows)
            }
            ProbeIndex::SmallColumn(index) => {
                if self.keep_rows {
                    ProbeMatch::Rows(AtomRows::Inline(index.rows_at(key_index)))
                } else {
                    ProbeMatch::Present
                }
            }
            ProbeIndex::Packed(packed) if packed.columns.len() == 1 => {
                let rows = AtomRows::Packed(PackedCursor::new(packed.first, key_index));
                Self::keep_or_discard(rows, self.keep_rows)
            }
            ProbeIndex::CachedTuple { .. }
            | ProbeIndex::CachedColumn { .. }
            | ProbeIndex::ProjectedRoot(..)
            | ProbeIndex::SmallExact(..)
            | ProbeIndex::Packed(..) => {
                unreachable!("only a sorted scalar probe has a match ordinal")
            }
        }
    }

    pub(super) fn for_each(&self, mut f: impl FnMut(&[Value], ProbeMatch<'rows, 'exec>)) {
        match &self.ix {
            ProbeIndex::CachedTuple {
                intersect_outer,
                table,
                continuations,
                child_shape,
            } => {
                let table: &'rows Index<TupleIndex> = table;
                table.for_each_positioned(|position, key, subset| {
                    let subset = if let Some(range) = intersect_outer {
                        let Some(subset) = intersect_with_dense_ref(subset, *range) else {
                            return;
                        };
                        subset
                    } else {
                        subset
                    };
                    f(
                        key,
                        Self::catalog_match(
                            position,
                            subset,
                            continuations,
                            self.keep_rows,
                            *child_shape,
                        ),
                    );
                });
            }
            ProbeIndex::CachedColumn {
                intersect_outer,
                table,
                continuations,
                child_shape,
            } => {
                let table: &'rows Index<ColumnIndex> = table;
                table.for_each_positioned(|position, value, subset| {
                    let subset = if let Some(range) = intersect_outer {
                        let Some(subset) = intersect_with_dense_ref(subset, *range) else {
                            return;
                        };
                        subset
                    } else {
                        subset
                    };
                    f(
                        &[*value],
                        Self::catalog_match(
                            position,
                            subset,
                            continuations,
                            self.keep_rows,
                            *child_shape,
                        ),
                    );
                });
            }
            ProbeIndex::ProjectedRoot(projected) => projected.for_each(&mut |key, rows| {
                f(key, Self::keep_or_discard(rows, self.keep_rows));
            }),
            ProbeIndex::SmallColumn(index) => {
                for key_index in 0..index.n_keys {
                    let rows = if self.keep_rows {
                        ProbeMatch::Rows(AtomRows::Inline(index.rows_at(key_index)))
                    } else {
                        ProbeMatch::Present
                    };
                    f(&index.keys[key_index..key_index + 1], rows);
                }
            }
            ProbeIndex::SmallExact(..) => {
                unreachable!("small multi-column residuals are exact-probe only")
            }
            ProbeIndex::Packed(packed) => packed.for_each(&mut |key, rows| {
                f(key, Self::keep_or_discard(rows, self.keep_rows));
            }),
        }
    }

    pub(super) fn for_each_shard(
        &self,
        shard: usize,
        mut f: impl FnMut(&[Value], ProbeMatch<'rows, 'exec>),
    ) {
        match &self.ix {
            ProbeIndex::CachedTuple {
                intersect_outer,
                table,
                continuations,
                child_shape,
            } => {
                let table: &'rows Index<TupleIndex> = table;
                table.for_each_shard_positioned(shard, |position, key, subset| {
                    let subset = if let Some(range) = intersect_outer {
                        let Some(subset) = intersect_with_dense_ref(subset, *range) else {
                            return;
                        };
                        subset
                    } else {
                        subset
                    };
                    f(
                        key,
                        Self::catalog_match(
                            position,
                            subset,
                            continuations,
                            self.keep_rows,
                            *child_shape,
                        ),
                    );
                });
            }
            ProbeIndex::CachedColumn {
                intersect_outer,
                table,
                continuations,
                child_shape,
            } => {
                let table: &'rows Index<ColumnIndex> = table;
                table.for_each_shard_positioned(shard, |position, value, subset| {
                    let subset = if let Some(range) = intersect_outer {
                        let Some(subset) = intersect_with_dense_ref(subset, *range) else {
                            return;
                        };
                        subset
                    } else {
                        subset
                    };
                    f(
                        &[*value],
                        Self::catalog_match(
                            position,
                            subset,
                            continuations,
                            self.keep_rows,
                            *child_shape,
                        ),
                    );
                });
            }
            ProbeIndex::ProjectedRoot(..)
            | ProbeIndex::SmallColumn(..)
            | ProbeIndex::SmallExact(..)
            | ProbeIndex::Packed(..) => {
                unreachable!("only persistent root indexes expose physical shards")
            }
        }
    }

    /// Visit a disjoint ordinal range of an unsharded scalar index.
    ///
    /// `Intersect` stages always probe one column, so partitioning the first
    /// (and only) key level preserves complete key groups. The backing
    /// projected/packed index remains borrowed by every coarse task.
    pub(super) fn for_each_range(
        &self,
        start: usize,
        scan_size: usize,
        mut f: impl FnMut(&[Value], ProbeMatch<'rows, 'exec>),
    ) {
        let end = start
            .checked_add(scan_size)
            .expect("top index range overflow");
        match &self.ix {
            ProbeIndex::ProjectedRoot(projected) => {
                debug_assert_eq!(projected.columns.len(), 1);
                assert!(end <= projected.first.len());
                for key_index in start..end {
                    let key = [projected.first.value_at(key_index)];
                    f(
                        &key,
                        Self::keep_or_discard(projected.scalar_rows(key_index), self.keep_rows),
                    );
                }
            }
            ProbeIndex::SmallColumn(index) => {
                assert!(end <= index.n_keys);
                for key_index in start..end {
                    let rows = if self.keep_rows {
                        ProbeMatch::Rows(AtomRows::Inline(index.rows_at(key_index)))
                    } else {
                        ProbeMatch::Present
                    };
                    f(&index.keys[key_index..key_index + 1], rows);
                }
            }
            ProbeIndex::Packed(packed) => {
                debug_assert_eq!(packed.columns.len(), 1);
                let values = packed.first.values();
                assert!(end <= values.len());
                for key_index in start..end {
                    let rows = AtomRows::Packed(PackedCursor::new(packed.first, key_index));
                    f(
                        &values[key_index..key_index + 1],
                        Self::keep_or_discard(rows, self.keep_rows),
                    );
                }
            }
            ProbeIndex::CachedTuple { .. } | ProbeIndex::CachedColumn { .. } => {
                unreachable!("persistent indexes use physical shard partitions")
            }
            ProbeIndex::SmallExact(..) => {
                unreachable!("a scalar intersection cannot use an exact tuple probe")
            }
        }
    }

    pub(super) fn shard_count(&self) -> Option<usize> {
        match &self.ix {
            ProbeIndex::CachedTuple { table, .. } => Some(table.shard_count()),
            ProbeIndex::CachedColumn { table, .. } => Some(table.shard_count()),
            ProbeIndex::ProjectedRoot(..)
            | ProbeIndex::SmallColumn(..)
            | ProbeIndex::SmallExact(..)
            | ProbeIndex::Packed(..) => None,
        }
    }

    pub(super) fn shard_len(&self, shard: usize) -> Option<usize> {
        match &self.ix {
            ProbeIndex::CachedTuple { table, .. } => Some(table.shard_len(shard)),
            ProbeIndex::CachedColumn { table, .. } => Some(table.shard_len(shard)),
            ProbeIndex::ProjectedRoot(..)
            | ProbeIndex::SmallColumn(..)
            | ProbeIndex::SmallExact(..)
            | ProbeIndex::Packed(..) => None,
        }
    }

    pub(super) fn len(&self) -> usize {
        match &self.ix {
            ProbeIndex::CachedTuple { table, .. } => table.len(),
            ProbeIndex::CachedColumn { table, .. } => table.len(),
            ProbeIndex::ProjectedRoot(projected) => projected.first.len(),
            ProbeIndex::SmallColumn(index) => index.len(),
            ProbeIndex::SmallExact(exact) => exact.len(),
            // Intersect stages are scalar. Tuple-packed probers are used only
            // for exact probes, so the first-level count is sufficient here.
            ProbeIndex::Packed(packed) => packed.first.values().len(),
        }
    }
}

#[cfg(test)]
#[path = "probe_tests.rs"]
mod tests;
