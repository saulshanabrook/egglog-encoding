use std::{
    panic,
    sync::{
        Arc, Barrier, Mutex,
        atomic::{AtomicBool, AtomicUsize, Ordering},
    },
    thread,
    time::{Duration, Instant},
};

use crate::{
    Notification, Scope, ThreadPool, current_num_threads, scope as threadpool_scope,
    without_current_pool,
};

use super::{
    MAX_INLINE_SCOPE_HELP_DEPTH, ThreadPoolState, ThreadPoolStatePtr, WorkerContext,
    is_background_worker_thread,
};

#[test]
fn scope_runs_spawned_work_and_waits() {
    let pool = ThreadPool::new(4);
    let counter = AtomicUsize::new(0);

    pool.scope(|scope| {
        for _ in 0..128 {
            scope.spawn(|_| {
                counter.fetch_add(1, Ordering::Relaxed);
            });
        }
    });

    assert_eq!(counter.load(Ordering::Relaxed), 128);
}

#[test]
fn spawn_remains_a_global_queue_compatibility_alias() {
    let pool = ThreadPool::new(1);
    pool.reset_scheduler_metrics();

    pool.scope(|scope| scope.spawn(|_| {}));

    let metrics = pool.scheduler_metrics();
    assert_eq!(metrics.global_pushes, 1);
    assert_eq!(metrics.global_pops, 1);
    assert_eq!(metrics.local_pushes, 0);
    assert_eq!(metrics.local_pops, 0);
}

#[test]
fn spawn_local_from_root_falls_back_to_global_queue() {
    let pool = ThreadPool::new(1);
    pool.reset_scheduler_metrics();

    pool.scope(|scope| scope.spawn_local(|_| {}));

    let metrics = pool.scheduler_metrics();
    assert_eq!(metrics.global_pushes, 1);
    assert_eq!(metrics.global_pops, 1);
    assert_eq!(metrics.local_pushes, 0);
}

#[test]
fn owner_runs_local_work_depth_first_before_global_work() {
    let pool = ThreadPool::new(1);
    let first_started = Notification::new();
    let release_first = Notification::new();
    let order = Mutex::new(Vec::new());

    pool.scope(|scope| {
        scope.spawn_global(|scope| {
            order.lock().unwrap().push("parent");
            first_started.notify();
            release_first.wait();
            scope.spawn_local(|_| order.lock().unwrap().push("local-oldest"));
            scope.spawn_local(|_| order.lock().unwrap().push("local-newest"));
        });

        first_started.wait();
        scope.spawn_global(|_| order.lock().unwrap().push("global"));
        release_first.notify();
    });

    assert_eq!(
        order.into_inner().unwrap(),
        ["parent", "local-newest", "local-oldest", "global"]
    );
    let metrics = pool.scheduler_metrics();
    assert_eq!(metrics.local_pushes, 2);
    assert_eq!(metrics.local_pops, 2);
    assert_eq!(metrics.donated_jobs, 0);
}

#[test]
fn nested_scope_help_takes_local_work_before_global_work() {
    let pool = ThreadPool::new(1);
    let parent_started = Notification::new();
    let release_parent = Notification::new();
    let order = Mutex::new(Vec::new());

    pool.scope(|scope| {
        scope.spawn_global(|_| {
            order.lock().unwrap().push("parent-start");
            parent_started.notify();
            release_parent.wait();

            threadpool_scope(|nested| {
                nested.spawn_local(|_| order.lock().unwrap().push("nested-local"));
            });
            order.lock().unwrap().push("parent-after-nested");
        });

        parent_started.wait();
        scope.spawn_global(|_| order.lock().unwrap().push("global"));
        release_parent.notify();
    });

    assert_eq!(
        order.into_inner().unwrap(),
        [
            "parent-start",
            "nested-local",
            "parent-after-nested",
            "global"
        ]
    );
}

#[test]
fn donation_moves_half_of_the_oldest_local_jobs() {
    let (sender, receiver) = super::unbounded();
    let state = ThreadPoolState::new(sender, receiver, 1);
    let worker = WorkerContext::new(ThreadPoolStatePtr::new(&state), 0);
    let order = Arc::new(Mutex::new(Vec::new()));

    // Build the queue directly so one donation decision observes all six jobs.
    // This isolates deque-end and half-transfer policy from worker timing.
    unsafe {
        let queue = &mut *worker.local.get();
        for value in 0..6 {
            let order = order.clone();
            queue.push_back(Box::new(move || order.lock().unwrap().push(value)));
        }
    }
    state
        .instrumentation
        .stalled_workers
        .store(1, Ordering::Release);

    worker.donate_half_if_stalled(&state);
    state
        .instrumentation
        .stalled_workers
        .store(0, Ordering::Release);

    for _ in 0..3 {
        state.try_recv_global().unwrap()();
    }
    while let Some(job) = worker.pop_local(&state) {
        job();
    }

    assert_eq!(*order.lock().unwrap(), [0, 1, 2, 5, 4, 3]);
    let metrics = state.instrumentation.snapshot();
    assert_eq!(metrics.donated_jobs, 3);
    assert_eq!(metrics.global_pushes, 3);
    assert_eq!(metrics.global_pops, 3);
    assert_eq!(metrics.local_pops, 3);
}

#[test]
fn stalled_worker_signal_causes_public_local_work_to_be_donated() {
    let pool = ThreadPool::new(2);
    let deadline = Instant::now() + Duration::from_secs(1);
    while pool.scheduler_metrics().stalled_workers != 2 {
        assert!(Instant::now() < deadline, "workers did not become stalled");
        thread::yield_now();
    }
    pool.reset_scheduler_metrics();

    pool.scope(|scope| {
        scope.spawn_global(|scope| {
            for _ in 0..16 {
                scope.spawn_local(|_| {});
            }
        });
    });

    let metrics = pool.scheduler_metrics();
    assert_eq!(metrics.local_pushes, 16);
    assert!(metrics.donated_jobs > 0);
    assert_eq!(
        metrics.local_pushes,
        metrics.local_pops + metrics.donated_jobs
    );
    assert_eq!(metrics.global_pushes, 1 + metrics.donated_jobs);
    assert_eq!(metrics.global_pushes, metrics.global_pops);
    assert!(metrics.max_local_queue_depth >= 2);
}

#[test]
fn stalled_time_snapshots_include_stalls_in_progress() {
    let pool = ThreadPool::new(2);
    let deadline = Instant::now() + Duration::from_secs(1);
    while pool.scheduler_metrics().stalled_workers != 2 {
        assert!(Instant::now() < deadline, "workers did not become stalled");
        thread::yield_now();
    }

    let before = pool.scheduler_metrics();
    thread::sleep(Duration::from_millis(2));
    let delta = pool.scheduler_metrics().delta_since(before);
    assert!(delta.stalled_time >= Duration::from_millis(2));
    assert_eq!(delta.stalled_workers, 2);

    pool.reset_scheduler_metrics();
    let after_reset = pool.scheduler_metrics();
    thread::sleep(Duration::from_millis(2));
    let reset_delta = pool.scheduler_metrics().delta_since(after_reset);
    assert!(reset_delta.stalled_time >= Duration::from_millis(2));
}

#[test]
fn panic_from_local_work_is_propagated_after_the_scope_drains() {
    let pool = ThreadPool::new(1);
    let sibling_completed = AtomicBool::new(false);

    let result = panic::catch_unwind(panic::AssertUnwindSafe(|| {
        pool.scope(|scope| {
            scope.spawn_global(|scope| {
                scope.spawn_local(|_| sibling_completed.store(true, Ordering::Release));
                // Local jobs are LIFO, so the panic runs first. Its job wrapper
                // must record the panic and let the worker drain the sibling.
                scope.spawn_local(|_| panic!("local worker panic"));
            });
        });
    }));

    assert!(result.is_err());
    assert!(sibling_completed.load(Ordering::Acquire));
}

#[test]
fn scope_allows_borrowing_stack_data() {
    let pool = ThreadPool::new(2);
    let values = [1usize, 3, 5, 7, 11];
    let sum = AtomicUsize::new(0);

    pool.scope(|scope| {
        for value in &values {
            scope.spawn(|_| {
                sum.fetch_add(*value, Ordering::Relaxed);
            });
        }
    });

    assert_eq!(sum.load(Ordering::Relaxed), values.iter().sum());
}

#[test]
fn scope_allows_one_task_to_mutate_stack_data() {
    let pool = ThreadPool::new(1);
    let mut value = 0;

    pool.scope(|scope| {
        scope.spawn(|_| {
            value = 42;
        });
    });

    assert_eq!(value, 42);
}

#[test]
fn scope_handles_work_completed_before_expected_is_published() {
    let pool = ThreadPool::new(4);
    let counter = AtomicUsize::new(0);
    const TASKS: usize = 64;

    pool.scope(|scope| {
        for _ in 0..TASKS {
            scope.spawn(|_| {
                counter.fetch_add(1, Ordering::Release);
            });
        }

        while counter.load(Ordering::Acquire) != TASKS {
            thread::yield_now();
        }
    });

    assert_eq!(counter.load(Ordering::Acquire), TASKS);
}

#[test]
fn scope_waits_for_last_work_after_expected_is_published() {
    let pool = ThreadPool::new(2);
    let release = Arc::new(Notification::new());
    let entered = Arc::new(Notification::new());
    let scope_returned = Arc::new(AtomicBool::new(false));

    thread::scope(|thread_scope| {
        let release_inner = release.clone();
        let entered_inner = entered.clone();
        let scope_returned_inner = scope_returned.clone();
        let pool = &pool;
        thread_scope.spawn(move || {
            pool.scope(|scope| {
                scope.spawn(move |_| {
                    entered_inner.notify();
                    release_inner.wait();
                });
            });
            scope_returned_inner.store(true, Ordering::Release);
        });

        entered.wait();
        thread::sleep(Duration::from_millis(10));
        assert!(!scope_returned.load(Ordering::Acquire));
        release.notify();
    });

    assert!(scope_returned.load(Ordering::Acquire));
}

#[test]
fn many_scopes_cover_completion_races() {
    let pool = ThreadPool::new(4);

    for round in 0..512 {
        let counter = AtomicUsize::new(0);
        let tasks = round % 65;

        pool.scope(|scope| {
            for task in 0..tasks {
                let counter = &counter;
                scope.spawn(move |_| {
                    if task % 3 == 0 {
                        thread::yield_now();
                    }
                    counter.fetch_add(1, Ordering::AcqRel);
                });
            }

            if round % 2 == 0 {
                while counter.load(Ordering::Acquire) != tasks {
                    thread::yield_now();
                }
            }
        });

        assert_eq!(counter.load(Ordering::Acquire), tasks);
    }
}

#[test]
fn blocked_tasks_complete_together() {
    let pool = ThreadPool::new(8);
    let barrier = Arc::new(Barrier::new(8));
    let counter = AtomicUsize::new(0);

    pool.scope(|scope| {
        for _ in 0..8 {
            let barrier = barrier.clone();
            let counter = &counter;
            scope.spawn(move |_| {
                barrier.wait();
                counter.fetch_add(1, Ordering::AcqRel);
            });
        }
    });

    assert_eq!(counter.load(Ordering::Acquire), 8);
}

#[test]
fn nested_spawn_runs_to_completion() {
    let pool = ThreadPool::new(4);
    let counter = AtomicUsize::new(0);

    pool.scope(|scope| {
        for _ in 0..8 {
            scope.spawn(|scope| {
                counter.fetch_add(1, Ordering::AcqRel);
                for _ in 0..8 {
                    scope.spawn(|_| {
                        counter.fetch_add(1, Ordering::AcqRel);
                    });
                }
            });
        }
    });

    assert_eq!(counter.load(Ordering::Acquire), 72);
}

#[test]
fn nested_spawn_can_borrow_scope_data() {
    let pool = ThreadPool::new(4);
    let values = [2usize, 4, 8, 16];
    let sum = AtomicUsize::new(0);

    pool.scope(|scope| {
        for value in &values {
            let sum = &sum;
            scope.spawn(move |scope| {
                scope.spawn(move |_| {
                    sum.fetch_add(*value, Ordering::AcqRel);
                });
            });
        }
    });

    assert_eq!(sum.load(Ordering::Acquire), values.iter().sum());
}

#[test]
fn nested_work_spawned_after_root_callback_returns_is_waited_for() {
    let pool = ThreadPool::new(2);
    let root_returned = Arc::new(Notification::new());
    let release_nested_spawn = Arc::new(Notification::new());
    let nested_ran = Arc::new(AtomicBool::new(false));
    let scope_returned = Arc::new(AtomicBool::new(false));

    thread::scope(|thread_scope| {
        let root_returned_inner = root_returned.clone();
        let release_nested_spawn_inner = release_nested_spawn.clone();
        let nested_ran_inner = nested_ran.clone();
        let scope_returned_inner = scope_returned.clone();
        let pool = &pool;

        thread_scope.spawn(move || {
            pool.scope(|scope| {
                scope.spawn(move |scope| {
                    root_returned_inner.wait();
                    release_nested_spawn_inner.wait();
                    scope.spawn(move |_| {
                        nested_ran_inner.store(true, Ordering::Release);
                    });
                });
            });
            scope_returned_inner.store(true, Ordering::Release);
        });

        root_returned.notify();
        thread::sleep(Duration::from_millis(10));
        assert!(!scope_returned.load(Ordering::Acquire));
        release_nested_spawn.notify();
    });

    assert!(nested_ran.load(Ordering::Acquire));
    assert!(scope_returned.load(Ordering::Acquire));
}

#[test]
fn scope_root_callback_can_borrow_shorter_scheduling_data() {
    fn increment<'slice, 'counter>(pool: &ThreadPool, counters: &'slice [&'counter AtomicUsize]) {
        pool.scope(move |scope: &Scope<'counter>| {
            for &counter in counters {
                scope.spawn(move |_| {
                    counter.fetch_add(1, Ordering::Relaxed);
                });
            }
        });
    }

    let pool = ThreadPool::new(4);
    let counter = AtomicUsize::new(0);
    increment(&pool, &[&counter; 64]);

    assert_eq!(counter.load(Ordering::Relaxed), 64);
}

#[test]
fn static_scope_still_allows_local_scheduling_iterator() {
    static COUNTER: AtomicUsize = AtomicUsize::new(0);

    let pool = ThreadPool::new(4);
    let mut range = 0..32;
    let expected = range.clone().sum();
    let iter = &mut range;

    COUNTER.store(0, Ordering::Relaxed);
    pool.scope(|scope: &Scope<'static>| {
        for value in iter {
            scope.spawn(move |_| {
                COUNTER.fetch_add(value, Ordering::Relaxed);
            });
        }
    });

    assert_eq!(COUNTER.load(Ordering::Relaxed), expected);
}

#[test]
fn worker_panic_is_propagated_after_other_tasks_finish() {
    let pool = ThreadPool::new(2);
    let completed = Arc::new(AtomicUsize::new(0));

    let result = {
        let completed = completed.clone();
        panic::catch_unwind(panic::AssertUnwindSafe(|| {
            pool.scope(|scope| {
                scope.spawn(|_| panic!("worker panic"));
                scope.spawn(move |_| {
                    completed.fetch_add(1, Ordering::Release);
                });
            });
        }))
    };

    assert!(result.is_err());
    assert_eq!(completed.load(Ordering::Acquire), 1);
}

#[test]
fn outer_panic_still_waits_for_spawned_work() {
    let pool = ThreadPool::new(1);
    let completed = AtomicBool::new(false);

    let result = panic::catch_unwind(panic::AssertUnwindSafe(|| {
        pool.scope(|scope| {
            scope.spawn(|_| {
                completed.store(true, Ordering::Release);
            });
            panic!("outer panic");
        });
    }));

    assert!(result.is_err());
    assert!(completed.load(Ordering::Acquire));
}

#[test]
fn parallel_for_each_processes_borrowed_items() {
    let pool = ThreadPool::new(4);
    let values = vec![1usize, 2, 3, 4, 5, 6];
    let seen = Mutex::new(Vec::new());

    pool.parallel_for_each(values.iter(), |value| {
        seen.lock().unwrap().push(*value);
    });

    let mut seen = seen.into_inner().unwrap();
    seen.sort_unstable();
    assert_eq!(seen, values);
}

#[test]
fn parallel_for_each_waits_for_all_work() {
    let pool = ThreadPool::new(4);
    let counter = AtomicUsize::new(0);

    pool.parallel_for_each(0..256, |_| {
        counter.fetch_add(1, Ordering::AcqRel);
    });

    assert_eq!(counter.load(Ordering::Acquire), 256);
}

#[test]
fn dropping_pool_closes_workers() {
    let pool = ThreadPool::new(4);
    assert_eq!(pool.thread_count(), 4);
    drop(pool);
}

#[test]
fn current_num_threads_is_one_without_installed_pool() {
    assert_eq!(current_num_threads(), 1);
}

#[test]
fn install_sets_and_restores_current_pool() {
    let outer = ThreadPool::new(2);
    let inner = ThreadPool::new(3);

    assert_eq!(current_num_threads(), 1);
    outer.install(|| {
        assert_eq!(current_num_threads(), 2);
        inner.install(|| {
            assert_eq!(current_num_threads(), 3);
        });
        assert_eq!(current_num_threads(), 2);
    });
    assert_eq!(current_num_threads(), 1);
}

#[test]
fn spawn_local_does_not_use_a_different_pools_worker_queue() {
    let outer = ThreadPool::new(1);
    let inner = ThreadPool::new(1);
    let completed = AtomicBool::new(false);
    inner.reset_scheduler_metrics();

    outer.scope(|scope| {
        scope.spawn_global(|_| {
            inner.scope(|scope| {
                scope.spawn_local(|_| completed.store(true, Ordering::Release));
            });
        });
    });

    assert!(completed.load(Ordering::Acquire));
    let metrics = inner.scheduler_metrics();
    assert_eq!(metrics.local_pushes, 0);
    assert_eq!(metrics.global_pushes, 1);
    assert_eq!(metrics.global_pops, 1);
}

#[test]
fn without_current_pool_clears_and_restores_current_pool() {
    let pool = ThreadPool::new(2);

    pool.install(|| {
        assert_eq!(current_num_threads(), 2);
        without_current_pool(|| {
            assert_eq!(current_num_threads(), 1);
        });
        assert_eq!(current_num_threads(), 2);
    });

    assert_eq!(current_num_threads(), 1);
}

#[test]
fn pool_scope_installs_pool_for_root_and_spawned_callbacks() {
    let pool = ThreadPool::new(4);

    pool.scope(|scope| {
        assert_eq!(current_num_threads(), 4);
        scope.spawn(|_| {
            assert_eq!(current_num_threads(), 4);
        });
    });

    assert_eq!(pool.state.backup_workers_spawned(), 0);
    assert_eq!(pool.state.backup_workers_live(), 0);
}

#[test]
fn free_scope_uses_installed_pool() {
    let pool = ThreadPool::new(4);
    let counter = AtomicUsize::new(0);

    pool.install(|| {
        threadpool_scope(|scope| {
            assert_eq!(current_num_threads(), 4);
            scope.spawn(|_| {
                assert_eq!(current_num_threads(), 4);
                counter.fetch_add(1, Ordering::Relaxed);
            });
        });
    });

    assert_eq!(counter.load(Ordering::Relaxed), 1);
}

#[test]
fn free_scope_works_from_spawned_callback() {
    let pool = ThreadPool::new(4);
    let counter = AtomicUsize::new(0);

    pool.scope(|scope| {
        scope.spawn(|_| {
            threadpool_scope(|scope| {
                scope.spawn(|_| {
                    assert_eq!(current_num_threads(), 4);
                    counter.fetch_add(1, Ordering::Relaxed);
                });
            });
        });
    });

    assert_eq!(counter.load(Ordering::Relaxed), 1);
}

#[test]
#[should_panic(expected = "no egglog thread pool is currently installed")]
fn free_scope_panics_without_installed_pool() {
    threadpool_scope(|_| {});
}

#[test]
fn primary_workers_are_marked_as_background_workers() {
    let pool = ThreadPool::new(1);

    assert!(!is_background_worker_thread());
    pool.scope(|scope| {
        assert!(!is_background_worker_thread());
        scope.spawn(|_| {
            assert!(is_background_worker_thread());
        });
    });
}

#[test]
fn root_scope_waits_for_spawned_work() {
    let pool = ThreadPool::new(1);
    let entered = Arc::new(Notification::new());
    let release = Arc::new(Notification::new());

    thread::scope(|thread_scope| {
        let entered_inner = entered.clone();
        let release_inner = release.clone();
        let pool = &pool;
        thread_scope.spawn(move || {
            pool.scope(|scope| {
                scope.spawn(move |_| {
                    entered_inner.notify();
                    release_inner.wait();
                });
            });
        });

        entered.wait();
        thread::sleep(Duration::from_millis(10));
        release.notify();
    });

    assert_eq!(pool.state.backup_workers_spawned(), 0);
    assert_eq!(pool.state.backup_workers_live(), 0);
}

#[test]
fn background_worker_helps_single_worker_nested_scope() {
    let pool = ThreadPool::new(1);
    let nested_completed = AtomicBool::new(false);

    pool.scope(|scope| {
        scope.spawn(|_| {
            threadpool_scope(|nested| {
                nested.spawn(|_| {
                    assert!(is_background_worker_thread());
                    assert_eq!(current_num_threads(), 1);
                    nested_completed.store(true, Ordering::Release);
                });
            });
        });
    });

    assert!(nested_completed.load(Ordering::Acquire));
    assert_eq!(pool.state.backup_workers_spawned(), 0);
    assert_eq!(pool.state.backup_workers_live(), 0);
}

#[test]
fn background_worker_wait_returns_after_nested_scope_finishes() {
    let pool = ThreadPool::new(1);
    let nested_started = Arc::new(Notification::new());
    let release_nested = Arc::new(Notification::new());
    let scope_returned = Arc::new(AtomicBool::new(false));

    thread::scope(|thread_scope| {
        let nested_started_inner = nested_started.clone();
        let release_nested_inner = release_nested.clone();
        let scope_returned_inner = scope_returned.clone();
        let pool = &pool;
        thread_scope.spawn(move || {
            pool.scope(|scope| {
                scope.spawn(move |_| {
                    threadpool_scope(|nested| {
                        nested.spawn(move |_| {
                            nested_started_inner.notify();
                            release_nested_inner.wait();
                        });
                    });
                });
            });
            scope_returned_inner.store(true, Ordering::Release);
        });

        nested_started.wait();
        thread::sleep(Duration::from_millis(10));
        assert!(!scope_returned.load(Ordering::Acquire));
        release_nested.notify();
    });

    assert!(scope_returned.load(Ordering::Acquire));
    assert_eq!(pool.state.backup_workers_spawned(), 0);
    assert_eq!(pool.state.backup_workers_live(), 0);
}

#[test]
fn nested_background_worker_waits_can_reenter_help_loop() {
    let pool = ThreadPool::new(1);
    let completed = AtomicUsize::new(0);

    pool.scope(|scope| {
        scope.spawn(|_| {
            threadpool_scope(|scope| {
                scope.spawn(|_| {
                    threadpool_scope(|scope| {
                        scope.spawn(|_| {
                            assert!(is_background_worker_thread());
                            completed.fetch_add(1, Ordering::Release);
                        });
                    });
                });
            });
        });
    });

    assert_eq!(completed.load(Ordering::Acquire), 1);
    assert_eq!(pool.state.backup_workers_spawned(), 0);
    assert_eq!(pool.state.backup_workers_live(), 0);
}

#[test]
fn deeply_nested_background_waits_fall_back_to_backup_worker() {
    fn recurse(depth: usize, completed: &AtomicUsize) {
        if depth == 0 {
            completed.fetch_add(1, Ordering::Release);
            return;
        }

        threadpool_scope(|scope| {
            scope.spawn(move |_| recurse(depth - 1, completed));
        });
    }

    let pool = ThreadPool::new(1);
    let completed = AtomicUsize::new(0);

    pool.scope(|scope| {
        scope.spawn(|_| {
            recurse(MAX_INLINE_SCOPE_HELP_DEPTH + 8, &completed);
        });
    });

    assert_eq!(completed.load(Ordering::Acquire), 1);
    assert!(pool.state.backup_workers_spawned() >= 1);
    assert_eq!(pool.state.backup_workers_live(), 0);
}

#[test]
fn deeply_nested_local_work_is_donated_to_backup_worker() {
    fn recurse(depth: usize, completed: &AtomicUsize) {
        if depth == 0 {
            completed.fetch_add(1, Ordering::Release);
            return;
        }

        threadpool_scope(|scope| {
            scope.spawn_local(move |_| recurse(depth - 1, completed));
        });
    }

    let pool = ThreadPool::new(1);
    let completed = AtomicUsize::new(0);

    pool.scope(|scope| {
        scope.spawn_global(|_| {
            recurse(MAX_INLINE_SCOPE_HELP_DEPTH + 8, &completed);
        });
    });

    assert_eq!(completed.load(Ordering::Acquire), 1);
    assert!(pool.state.backup_workers_spawned() >= 1);
    assert_eq!(pool.state.backup_workers_live(), 0);
    assert!(pool.scheduler_metrics().donated_jobs >= 1);
}
