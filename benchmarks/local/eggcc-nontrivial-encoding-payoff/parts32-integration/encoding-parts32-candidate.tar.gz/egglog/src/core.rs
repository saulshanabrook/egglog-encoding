//! This file implements the core IR of the language, which is called CoreRule.
//! CoreRule uses a conjunctive query-like IR for the body (queries) and a
//! SSA-like IR for the head (actions) based on the previous CoreAction form.
//! Every construct has two forms: a standard (unresolved) form and a resolved form,
//! which differs in whether the head is a symbol or a resolved call.
//! Currently, CoreRule has several usages:
//!   Typechecking is done over CoreRule format
//!   Canonicalization is done over CoreRule format
//!   ActionCompilers further compiles core actions to programs in a small VM
//!   GJ compiler further compiler core queries to gj's CompiledQueries
//!
//! Most compiler-time optimizations are expected to be done over CoreRule format.
use std::{
    fmt::Display,
    hash::{Hash, Hasher},
    marker::PhantomData,
    ops::AddAssign,
};

use crate::{constraint::grounded_check, *};
use egglog_ast::generic_ast::{Change, GenericAction, GenericActions, GenericExpr, Literal};
use egglog_ast::span::Span;
use egglog_ast::util::ListDisplay;
use typechecking::{FuncType, PrimitiveValidator, PrimitiveWithId, TypeError};

/// A variable, literal, or global in lowered rule syntax.
#[derive(Debug, Clone)]
pub enum GenericAtomTerm<Leaf> {
    Var(Span, Leaf),
    Literal(Span, Literal),
    Global(Span, Leaf),
}

// Source annotations do not affect equality or hashing.
impl<Leaf: PartialEq> PartialEq for GenericAtomTerm<Leaf> {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (Self::Var(_, lhs), Self::Var(_, rhs)) => lhs == rhs,
            (Self::Literal(_, lhs), Self::Literal(_, rhs)) => lhs == rhs,
            (Self::Global(_, lhs), Self::Global(_, rhs)) => lhs == rhs,
            _ => false,
        }
    }
}

impl<Leaf: Eq> Eq for GenericAtomTerm<Leaf> {}

impl<Leaf: Hash> Hash for GenericAtomTerm<Leaf> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        match self {
            Self::Var(_, value) | Self::Global(_, value) => value.hash(state),
            Self::Literal(_, value) => value.hash(state),
        }
    }
}

impl<Leaf> GenericAtomTerm<Leaf> {
    pub fn span(&self) -> &Span {
        match self {
            Self::Var(span, _) | Self::Literal(span, _) | Self::Global(span, _) => span,
        }
    }
}

impl<Leaf: Clone> GenericAtomTerm<Leaf> {
    pub fn to_expr<Head>(&self) -> GenericExpr<Head, Leaf> {
        match self {
            Self::Var(span, value) | Self::Global(span, value) => {
                GenericExpr::Var(span.clone(), value.clone())
            }
            Self::Literal(span, literal) => GenericExpr::Lit(span.clone(), literal.clone()),
        }
    }
}

impl Display for GenericAtomTerm<String> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Var(_, value) | Self::Global(_, value) => write!(f, "{value}"),
            Self::Literal(_, literal) => write!(f, "{literal}"),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct GenericAtom<Head, Leaf> {
    pub span: Span,
    pub head: Head,
    pub args: Vec<GenericAtomTerm<Leaf>>,
}

impl<Head: Display> Display for GenericAtom<Head, String> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "({} {}) ", self.head, ListDisplay(&self.args, " "))
    }
}

impl<Head, Leaf> GenericAtom<Head, Leaf>
where
    Leaf: Clone,
{
    pub fn vars(&self) -> impl Iterator<Item = Leaf> + '_ {
        self.args.iter().filter_map(|term| match term {
            GenericAtomTerm::Var(_, value) => Some(value.clone()),
            GenericAtomTerm::Literal(..) | GenericAtomTerm::Global(..) => None,
        })
    }

    pub fn substitute_with(
        &mut self,
        substitute: &mut impl FnMut(&Leaf) -> Option<GenericAtomTerm<Leaf>>,
    ) {
        for argument in &mut self.args {
            if let GenericAtomTerm::Var(_, variable) = argument
                && let Some(replacement) = substitute(variable)
            {
                *argument = replacement;
            }
        }
    }
}

impl<Head: Clone, Leaf: Clone> GenericAtom<Head, Leaf> {
    pub fn to_expr(&self) -> GenericExpr<Head, Leaf> {
        let input_count = self
            .args
            .len()
            .checked_sub(1)
            .expect("an atom must include an output argument");
        GenericExpr::Call(
            self.span.clone(),
            self.head.clone(),
            self.args[..input_count]
                .iter()
                .map(GenericAtomTerm::to_expr)
                .collect(),
        )
    }
}

#[derive(Debug, Clone)]
pub struct Query<Head, Leaf> {
    pub atoms: Vec<GenericAtom<Head, Leaf>>,
}

impl<Head, Leaf> Default for Query<Head, Leaf> {
    fn default() -> Self {
        Self { atoms: Vec::new() }
    }
}

impl<Head, Leaf: Clone> Query<Head, Leaf> {
    pub fn vars(&self) -> impl Iterator<Item = Leaf> + '_ {
        self.atoms.iter().flat_map(GenericAtom::vars)
    }
}

impl<Head, Leaf> AddAssign for Query<Head, Leaf> {
    fn add_assign(&mut self, rhs: Self) {
        self.atoms.extend(rhs.atoms);
    }
}

impl Display for Query<String, String> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        for atom in &self.atoms {
            writeln!(f, "{atom}")?;
        }
        Ok(())
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub enum GenericCoreAction<Head, Leaf> {
    Let(Span, Leaf, Head, Vec<GenericAtomTerm<Leaf>>),
    LetAtomTerm(Span, Leaf, GenericAtomTerm<Leaf>),
    Set(
        Span,
        Head,
        Vec<GenericAtomTerm<Leaf>>,
        Vec<GenericAtomTerm<Leaf>>,
    ),
    Change(Span, Change, Head, Vec<GenericAtomTerm<Leaf>>),
    Union(Span, GenericAtomTerm<Leaf>, GenericAtomTerm<Leaf>),
    Panic(Span, String),
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct GenericCoreActions<Head, Leaf>(pub Vec<GenericCoreAction<Head, Leaf>>);

impl<Head, Leaf> Default for GenericCoreActions<Head, Leaf> {
    fn default() -> Self {
        Self(Vec::new())
    }
}

impl<Head, Leaf> GenericCoreActions<Head, Leaf> {
    pub fn new(actions: Vec<GenericCoreAction<Head, Leaf>>) -> Self {
        Self(actions)
    }

    pub fn free_vars(&self) -> Vec<Leaf>
    where
        Leaf: Clone + Eq,
    {
        fn insert_unique<T: Eq>(values: &mut Vec<T>, value: T) {
            if !values.contains(&value) {
                values.push(value);
            }
        }

        fn add_term<Leaf: Clone + Eq>(free: &mut Vec<Leaf>, term: &GenericAtomTerm<Leaf>) {
            if let GenericAtomTerm::Var(_, variable) = term {
                insert_unique(free, variable.clone());
            }
        }

        let mut free = Vec::new();

        for action in self.0.iter().rev() {
            match action {
                GenericCoreAction::Let(_, variable, _, arguments) => {
                    for argument in arguments {
                        add_term(&mut free, argument);
                    }
                    free.retain(|candidate| candidate != variable);
                }
                GenericCoreAction::LetAtomTerm(_, variable, term) => {
                    add_term(&mut free, term);
                    free.retain(|candidate| candidate != variable);
                }
                GenericCoreAction::Set(_, _, arguments, values) => {
                    for argument in arguments {
                        add_term(&mut free, argument);
                    }
                    for value in values {
                        add_term(&mut free, value);
                    }
                }
                GenericCoreAction::Change(_, _, _, arguments) => {
                    for argument in arguments {
                        add_term(&mut free, argument);
                    }
                }
                GenericCoreAction::Union(_, lhs, rhs) => {
                    add_term(&mut free, lhs);
                    add_term(&mut free, rhs);
                }
                GenericCoreAction::Panic(..) => {}
            }
        }
        free
    }
}

/// Lowered rule syntax with potentially distinct body and action call types.
#[derive(Debug, Clone)]
pub struct GenericCoreRule<BodyCall, ActionCall, Leaf> {
    pub span: Span,
    pub body: Query<BodyCall, Leaf>,
    pub head: GenericCoreActions<ActionCall, Leaf>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum HeadOrEq<Head> {
    Head(Head),
    Eq,
}

pub(crate) type StringOrEq = HeadOrEq<String>;
pub type AtomTerm = GenericAtomTerm<String>;
pub type Atom<Head> = GenericAtom<Head, String>;
pub type CoreAction = GenericCoreAction<String, String>;

impl From<String> for StringOrEq {
    fn from(value: String) -> Self {
        StringOrEq::Head(value)
    }
}

impl<Head> HeadOrEq<Head> {
    pub fn is_eq(&self) -> bool {
        matches!(self, HeadOrEq::Eq)
    }
}

#[derive(Debug, Clone)]
pub struct SpecializedPrimitive {
    prim_with_id: PrimitiveWithId,
    input: Vec<ArcSort>,
    output: ArcSort,
}

impl SpecializedPrimitive {
    /// Get the name of this primitive
    pub fn name(&self) -> &str {
        self.prim_with_id.primitive.name()
    }

    /// Get the output sort of this primitive
    pub fn output(&self) -> &ArcSort {
        &self.output
    }

    /// Get the input sorts of this primitive
    pub fn input(&self) -> &[ArcSort] {
        &self.input
    }

    /// Get the external function ID of this primitive
    pub(crate) fn external_id(&self, ctx: crate::Context) -> ExternalFunctionId {
        self.prim_with_id.context_ids[ctx].unwrap_or_else(|| {
            panic!(
                "primitive {:?} is not valid in context {ctx:?}",
                self.prim_with_id.primitive.name()
            )
        })
    }

    /// Get the validator function of this primitive, if any
    pub fn validator(&self) -> Option<&PrimitiveValidator> {
        self.prim_with_id.validator.as_ref()
    }
}

impl PartialEq for SpecializedPrimitive {
    fn eq(&self, other: &Self) -> bool {
        // This is the key used when resolved atoms are deduplicated by
        // `(head, inputs)`. The context-id map identifies the primitive
        // registration, while the concrete input/output sorts identify the
        // specialization of generic primitives. The primitive name and
        // validator are registration metadata, so they are intentionally not
        // separate key fields.
        self.prim_with_id.context_ids == other.prim_with_id.context_ids
            && self.output.name() == other.output.name()
            && self.input.len() == other.input.len()
            && self
                .input
                .iter()
                .zip(&other.input)
                .all(|(a, b)| a.name() == b.name())
    }
}

impl Eq for SpecializedPrimitive {}

impl Hash for SpecializedPrimitive {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.prim_with_id.context_ids.hash(state);
        self.output.name().hash(state);
        self.input.len().hash(state);
        for input in &self.input {
            input.name().hash(state);
        }
    }
}

#[derive(Debug, Clone)]
pub enum ResolvedCall {
    Func(Arc<FuncType>),
    Primitive(SpecializedPrimitive),
    /// The `values` tuple constructor, used to destructure a tuple-output function's outputs in a
    /// query (`(= (values a b) (f x))`) or to construct them in a `set` action
    /// (`(set (f x) (values a b))`). Carries the output sorts. It never reaches rule lowering on its
    /// own: it is always paired with a tuple-output function call when lowering to core.
    Values(Vec<ArcSort>),
}

impl PartialEq for ResolvedCall {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (ResolvedCall::Func(a), ResolvedCall::Func(b)) => a == b,
            (ResolvedCall::Primitive(a), ResolvedCall::Primitive(b)) => a == b,
            (ResolvedCall::Values(a), ResolvedCall::Values(b)) => {
                a.len() == b.len() && a.iter().zip(b).all(|(x, y)| x.name() == y.name())
            }
            _ => false,
        }
    }
}

impl Eq for ResolvedCall {}

impl Hash for ResolvedCall {
    fn hash<H: Hasher>(&self, state: &mut H) {
        std::mem::discriminant(self).hash(state);
        match self {
            ResolvedCall::Func(f) => f.hash(state),
            ResolvedCall::Primitive(p) => p.hash(state),
            ResolvedCall::Values(sorts) => sorts.iter().for_each(|s| s.name().hash(state)),
        }
    }
}

impl ResolvedCall {
    pub fn name(&self) -> &str {
        match self {
            ResolvedCall::Func(func) => &func.name,
            ResolvedCall::Primitive(prim) => prim.name(),
            ResolvedCall::Values(_) => "values",
        }
    }

    pub fn output(&self) -> &ArcSort {
        match self {
            ResolvedCall::Func(func) => func.output(),
            ResolvedCall::Primitive(prim) => prim.output(),
            // `values` has no single output; its first column is returned only so that callers
            // that incidentally ask for "a" sort do not panic. Tuple-output uses are routed
            // specially before this is consulted.
            ResolvedCall::Values(sorts) => &sorts[0],
        }
    }

    // Different from `from_resolution`, this function only considers function types and not primitives.
    // As a result, it only requires input argument types, so types.len() == func.input.len(),
    // while for `from_resolution`, types.len() == func.input.len() + 1 to account for the output type
    pub fn from_resolution_func_types(
        head: &str,
        types: &[ArcSort],
        typeinfo: &TypeInfo,
    ) -> Option<ResolvedCall> {
        if let Some(ty) = typeinfo.get_func_type(head) {
            // As long as input types match, a result is returned.
            let expected = ty.input.iter().map(|s| s.name());
            let actual = types.iter().map(|s| s.name());
            if expected.eq(actual) {
                return Some(ResolvedCall::Func(ty.clone()));
            }
        }
        None
    }

    pub fn from_resolution(
        head: &str,
        types: &[ArcSort],
        typeinfo: &TypeInfo,
        ctx: crate::Context,
        span: &Span,
    ) -> Result<ResolvedCall, TypeError> {
        if let Some(ty) = typeinfo.get_func_type(head) {
            let expected = ty.input.iter().chain(ty.outputs.iter()).map(|s| s.name());
            let actual = types.iter().map(|s| s.name());
            if expected.eq(actual) {
                return Ok(ResolvedCall::Func(ty.clone()));
            }
        }

        let mut primitives = typeinfo
            .get_prims(head)
            .into_iter()
            .flatten()
            .filter(|p| p.context_ids[ctx].is_some() && p.accept(types, typeinfo));
        if let Some(picked) = primitives.next() {
            // Type inference has already assigned concrete types, so a valid
            // overload (`+`, `map-empty`, container primitives) leaves exactly
            // one matching registration. A second match means two registrations
            // are indistinguishable for this signature and context.
            if primitives.next().is_some() {
                return Err(TypeError::AmbiguousPrimitive {
                    name: head.to_owned(),
                    ctx,
                    span: span.clone(),
                });
            }
            let (out, inp) = types.split_last().unwrap();
            return Ok(ResolvedCall::Primitive(SpecializedPrimitive {
                prim_with_id: picked.clone(),
                input: inp.to_vec(),
                output: out.clone(),
            }));
        }

        Err(TypeError::UnresolvedPrimitive {
            name: head.to_owned(),
            ctx,
            span: span.clone(),
        })
    }

    /// Whether this call is to a `function` table, as opposed to a constructor
    /// or a primitive.
    pub(crate) fn is_custom_func(&self) -> bool {
        matches!(self, ResolvedCall::Func(func) if func.subtype == FunctionSubtype::Custom)
    }
}

impl Display for ResolvedCall {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            ResolvedCall::Func(func) => write!(f, "{}", func.name),
            ResolvedCall::Primitive(prim) => write!(f, "{}", prim.name()),
            ResolvedCall::Values(_) => write!(f, "values"),
        }
    }
}

/// A trait encapsulating the ability to query a [`TypeInfo`] to determine
/// whether or not a symbol is bound as a function in the current egglog program.
///
/// Currently, we only use this trait to determine whether a symbol is a
/// [`FunctionSubtype::Constructor`].
pub trait IsFunc {
    fn is_constructor(&self, type_info: &TypeInfo) -> bool;
}

impl IsFunc for ResolvedCall {
    fn is_constructor(&self, type_info: &TypeInfo) -> bool {
        match self {
            ResolvedCall::Func(func) => type_info.is_constructor(&func.name),
            ResolvedCall::Primitive(_) => false,
            ResolvedCall::Values(_) => false,
        }
    }
}

impl IsFunc for String {
    fn is_constructor(&self, type_info: &TypeInfo) -> bool {
        type_info.is_constructor(self)
    }
}

/// Operations on a call head needed to lower the `values` tuple sugar. Implemented for both the
/// unresolved (`String`) and resolved ([`ResolvedCall`]) head representations so that the same
/// lowering code runs in both the type-checking and canonicalization passes.
pub trait HeadOps {
    /// Whether this head is the `values` tuple constructor.
    fn is_values(&self) -> bool;
    /// Whether this head is a tuple-output function (more than one output column).
    fn is_tuple_output(&self, type_info: &TypeInfo) -> bool;
}

impl HeadOps for String {
    fn is_values(&self) -> bool {
        self == "values"
    }
    fn is_tuple_output(&self, type_info: &TypeInfo) -> bool {
        type_info
            .get_func_type(self)
            .is_some_and(|t| t.is_tuple_output())
    }
}

impl HeadOps for ResolvedCall {
    fn is_values(&self) -> bool {
        matches!(self, ResolvedCall::Values(_))
    }
    fn is_tuple_output(&self, _type_info: &TypeInfo) -> bool {
        matches!(self, ResolvedCall::Func(f) if f.is_tuple_output())
    }
}
pub type ResolvedAtomTerm = GenericAtomTerm<ResolvedVar>;

fn atom_term_sort(term: &ResolvedAtomTerm) -> ArcSort {
    match term {
        GenericAtomTerm::Var(_, variable) | GenericAtomTerm::Global(_, variable) => {
            variable.sort.clone()
        }
        GenericAtomTerm::Literal(_, literal) => literal_sort(literal),
    }
}

impl Query<StringOrEq, String> {
    pub(crate) fn get_constraints(
        &self,
        type_info: &TypeInfo,
        ctx: crate::Context,
    ) -> Result<Vec<Box<dyn Constraint<AtomTerm, ArcSort>>>, TypeError> {
        let mut constraints = vec![];
        for atom in self.atoms.iter() {
            constraints.extend(atom.get_constraints(type_info, ctx)?.into_iter());
        }
        Ok(constraints)
    }

    pub(crate) fn atom_terms(&self) -> HashSet<AtomTerm> {
        self.atoms
            .iter()
            .flat_map(|atom| atom.args.iter().cloned())
            .collect()
    }
}

pub(crate) type ResolvedCoreActions = GenericCoreActions<ResolvedCall, ResolvedVar>;
/// Shared state that threads through lowering from surface actions to core actions.
///
pub(crate) struct CoreActionContext<'a, Head, Leaf, FG> {
    /// Type environment describing functions, constructors, and primitives.
    pub typeinfo: &'a TypeInfo,
    /// Set of variables that are currently in scope during lowering.
    pub binding: &'a mut IndexSet<Leaf>,
    /// Generator used to create fresh symbols for intermediate values.
    pub fresh_gen: &'a mut FG,
    /// Whether we may rewrite `union` on constructors into `set`.
    pub union_to_set_optimization: bool,
    _marker: PhantomData<fn() -> Head>,
}

impl<'a, Head, Leaf, FG> CoreActionContext<'a, Head, Leaf, FG> {
    pub fn new(
        typeinfo: &'a TypeInfo,
        binding: &'a mut IndexSet<Leaf>,
        fresh_gen: &'a mut FG,
        union_to_set_optimization: bool,
    ) -> Self {
        Self {
            typeinfo,
            binding,
            fresh_gen,
            union_to_set_optimization,
            _marker: PhantomData,
        }
    }
}

pub(crate) trait GenericActionsExt<Head, Leaf> {
    #[allow(clippy::type_complexity)]
    fn to_core_actions<FG>(
        &self,
        ctx: &mut CoreActionContext<'_, Head, Leaf, FG>,
    ) -> Result<(GenericCoreActions<Head, Leaf>, MappedActions<Head, Leaf>), TypeError>
    where
        Head: Clone + Display + IsFunc + HeadOps,
        Leaf: Clone + PartialEq + Eq + Display + Hash,
        FG: FreshGen<Head, Leaf>;
}

impl<Head, Leaf> GenericActionsExt<Head, Leaf> for GenericActions<Head, Leaf>
where
    Head: Clone + Display + IsFunc + HeadOps,
    Leaf: Clone + PartialEq + Eq + Display + Hash,
{
    #[allow(clippy::type_complexity)]
    fn to_core_actions<FG>(
        &self,
        ctx: &mut CoreActionContext<'_, Head, Leaf, FG>,
    ) -> Result<(GenericCoreActions<Head, Leaf>, MappedActions<Head, Leaf>), TypeError>
    where
        Head: Clone + Display + IsFunc + HeadOps,
        Leaf: Clone + PartialEq + Eq + Display + Hash,
        FG: FreshGen<Head, Leaf>,
    {
        let mut norm_actions = vec![];
        let mut mapped_actions: MappedActions<Head, Leaf> = GenericActions(vec![]);
        let typeinfo = ctx.typeinfo;
        let union_to_set_optimization = ctx.union_to_set_optimization;

        // During the lowering, there are two important guaratees:
        //   Every used variable should be bound.
        //   Every introduced variable should be unbound before.
        for action in self.0.iter() {
            match action {
                GenericAction::Let(span, var, expr) => {
                    if ctx.binding.contains(var) {
                        return Err(TypeError::AlreadyDefined(var.to_string(), span.clone()));
                    }
                    let mapped_expr = expr.to_core_actions(ctx, &mut norm_actions)?;
                    norm_actions.push(GenericCoreAction::LetAtomTerm(
                        span.clone(),
                        var.clone(),
                        mapped_expr.get_corresponding_var_or_lit(typeinfo),
                    ));
                    mapped_actions.0.push(GenericAction::Let(
                        span.clone(),
                        var.clone(),
                        mapped_expr,
                    ));
                    ctx.binding.insert(var.clone());
                }
                GenericAction::Set(span, head, args, expr) => {
                    let mut mapped_args = vec![];
                    for arg in args {
                        let mapped_arg = arg.to_core_actions(ctx, &mut norm_actions)?;
                        mapped_args.push(mapped_arg);
                    }
                    // The value may be a `(values v...)` tuple (for a tuple-output function), which
                    // contributes one output column per element; otherwise it is a single value.
                    let (mapped_value, value_terms) = match expr {
                        GenericExpr::Call(vspan, vhead, vargs) if vhead.is_values() => {
                            let mut mapped = vec![];
                            let mut terms = vec![];
                            for v in vargs {
                                let m = v.to_core_actions(ctx, &mut norm_actions)?;
                                terms.push(m.get_corresponding_var_or_lit(typeinfo));
                                mapped.push(m);
                            }
                            let dummy = ctx.fresh_gen.fresh(vhead);
                            let mapped_call = GenericExpr::Call(
                                vspan.clone(),
                                CorrespondingVar::new(vhead.clone(), dummy),
                                mapped,
                            );
                            (mapped_call, terms)
                        }
                        _ => {
                            let m = expr.to_core_actions(ctx, &mut norm_actions)?;
                            let term = m.get_corresponding_var_or_lit(typeinfo);
                            (m, vec![term])
                        }
                    };
                    norm_actions.push(GenericCoreAction::Set(
                        span.clone(),
                        head.clone(),
                        mapped_args
                            .iter()
                            .map(|e| e.get_corresponding_var_or_lit(typeinfo))
                            .collect(),
                        value_terms,
                    ));
                    let v = ctx.fresh_gen.fresh(head);
                    mapped_actions.0.push(GenericAction::Set(
                        span.clone(),
                        CorrespondingVar::new(head.clone(), v),
                        mapped_args,
                        mapped_value,
                    ));
                }
                GenericAction::Change(span, change, head, args) => {
                    let mut mapped_args = vec![];
                    for arg in args {
                        let mapped_arg = arg.to_core_actions(ctx, &mut norm_actions)?;
                        mapped_args.push(mapped_arg);
                    }
                    norm_actions.push(GenericCoreAction::Change(
                        span.clone(),
                        *change,
                        head.clone(),
                        mapped_args
                            .iter()
                            .map(|e| e.get_corresponding_var_or_lit(typeinfo))
                            .collect(),
                    ));
                    let v = ctx.fresh_gen.fresh(head);
                    mapped_actions.0.push(GenericAction::Change(
                        span.clone(),
                        *change,
                        CorrespondingVar::new(head.clone(), v),
                        mapped_args,
                    ));
                }
                GenericAction::Union(span, e1, e2) => {
                    // Optimization: if one side is a constructor call and the other side is a variable,
                    // we can lower this to a Set action instead of a Union action.
                    // This produces invalid egglog, since top-level egglog expects only Union on constructors.
                    // We disable this with union_to_set_optimization flag for term/proof mode.
                    // TODO move this optimization to later stage so we can keep it enabled in term/proof mode.
                    match (e1, e2) {
                        (var @ GenericExpr::Var(..), GenericExpr::Call(_, f, args))
                        | (GenericExpr::Call(_, f, args), var @ GenericExpr::Var(..))
                            if f.is_constructor(typeinfo) && union_to_set_optimization =>
                        {
                            let head = f;
                            let expr = var;
                            let mut mapped_args = vec![];
                            for arg in args {
                                let mapped_arg = arg.to_core_actions(ctx, &mut norm_actions)?;
                                mapped_args.push(mapped_arg);
                            }
                            let mapped_expr = expr.to_core_actions(ctx, &mut norm_actions)?;
                            norm_actions.push(GenericCoreAction::Set(
                                span.clone(),
                                head.clone(),
                                mapped_args
                                    .iter()
                                    .map(|e| e.get_corresponding_var_or_lit(typeinfo))
                                    .collect(),
                                // Constructors are single-output, so a single value column.
                                vec![mapped_expr.get_corresponding_var_or_lit(typeinfo)],
                            ));
                            let v = ctx.fresh_gen.fresh(head);
                            mapped_actions.0.push(GenericAction::Set(
                                span.clone(),
                                CorrespondingVar::new(head.clone(), v),
                                mapped_args,
                                mapped_expr,
                            ));
                        }
                        _ => {
                            let mapped_e1 = e1.to_core_actions(ctx, &mut norm_actions)?;
                            let mapped_e2 = e2.to_core_actions(ctx, &mut norm_actions)?;
                            norm_actions.push(GenericCoreAction::Union(
                                span.clone(),
                                mapped_e1.get_corresponding_var_or_lit(typeinfo),
                                mapped_e2.get_corresponding_var_or_lit(typeinfo),
                            ));
                            mapped_actions.0.push(GenericAction::Union(
                                span.clone(),
                                mapped_e1,
                                mapped_e2,
                            ));
                        }
                    };
                }
                GenericAction::Panic(span, string) => {
                    norm_actions.push(GenericCoreAction::Panic(span.clone(), string.clone()));
                    mapped_actions
                        .0
                        .push(GenericAction::Panic(span.clone(), string.clone()));
                }
                GenericAction::Expr(span, expr) => {
                    let mapped_expr = expr.to_core_actions(ctx, &mut norm_actions)?;
                    mapped_actions
                        .0
                        .push(GenericAction::Expr(span.clone(), mapped_expr));
                }
            }
        }
        Ok((GenericCoreActions::new(norm_actions), mapped_actions))
    }
}

pub(crate) trait GenericExprExt<Head, Leaf>
where
    Head: Clone + Display,
    Leaf: Clone + PartialEq + Eq + Display + Hash,
{
    fn to_query(
        &self,
        typeinfo: &TypeInfo,
        fresh_gen: &mut impl FreshGen<Head, Leaf>,
    ) -> (
        Vec<GenericAtom<HeadOrEq<Head>, Leaf>>,
        MappedExpr<Head, Leaf>,
    );

    fn to_core_actions<FG: FreshGen<Head, Leaf>>(
        &self,
        ctx: &mut CoreActionContext<'_, Head, Leaf, FG>,
        out_actions: &mut Vec<GenericCoreAction<Head, Leaf>>,
    ) -> Result<MappedExpr<Head, Leaf>, TypeError>;
}

impl<Head, Leaf> GenericExprExt<Head, Leaf> for GenericExpr<Head, Leaf>
where
    Head: Clone + Display,
    Leaf: Clone + PartialEq + Eq + Display + Hash,
{
    fn to_query(
        &self,
        typeinfo: &TypeInfo,
        fresh_gen: &mut impl FreshGen<Head, Leaf>,
    ) -> (
        Vec<GenericAtom<HeadOrEq<Head>, Leaf>>,
        MappedExpr<Head, Leaf>,
    )
    where
        Head: Clone + Display,
        Leaf: Clone + PartialEq + Eq + Display + Hash,
    {
        match self {
            GenericExpr::Lit(span, lit) => (vec![], GenericExpr::Lit(span.clone(), lit.clone())),
            GenericExpr::Var(span, v) => (vec![], GenericExpr::Var(span.clone(), v.clone())),
            GenericExpr::Call(span, f, children) => {
                let fresh = fresh_gen.fresh(f);
                let mut new_children = vec![];
                let mut atoms = vec![];
                let mut child_exprs = vec![];
                for child in children {
                    let (child_atoms, child_expr) = child.to_query(typeinfo, fresh_gen);
                    let child_atomterm = child_expr.get_corresponding_var_or_lit(typeinfo);
                    new_children.push(child_atomterm);
                    atoms.extend(child_atoms);
                    child_exprs.push(child_expr);
                }
                let args = {
                    new_children.push(GenericAtomTerm::Var(span.clone(), fresh.clone()));
                    new_children
                };
                atoms.push(GenericAtom {
                    span: span.clone(),
                    head: HeadOrEq::Head(f.clone()),
                    args,
                });
                (
                    atoms,
                    GenericExpr::Call(
                        span.clone(),
                        CorrespondingVar::new(f.clone(), fresh),
                        child_exprs,
                    ),
                )
            }
        }
    }

    fn to_core_actions<FG: FreshGen<Head, Leaf>>(
        &self,
        ctx: &mut CoreActionContext<'_, Head, Leaf, FG>,
        out_actions: &mut Vec<GenericCoreAction<Head, Leaf>>,
    ) -> Result<MappedExpr<Head, Leaf>, TypeError> {
        let typeinfo = ctx.typeinfo;
        match self {
            GenericExpr::Lit(span, lit) => Ok(GenericExpr::Lit(span.clone(), lit.clone())),
            GenericExpr::Var(span, v) => {
                let sym = v.to_string();
                if ctx.binding.contains(v) || typeinfo.is_global(&sym) {
                    Ok(GenericExpr::Var(span.clone(), v.clone()))
                } else {
                    Err(TypeError::Unbound(sym, span.clone()))
                }
            }
            GenericExpr::Call(span, f, args) => {
                let mut norm_args = vec![];
                let mut mapped_args = vec![];
                for arg in args {
                    let mapped_arg = arg.to_core_actions(ctx, out_actions)?;
                    norm_args.push(mapped_arg.get_corresponding_var_or_lit(typeinfo));
                    mapped_args.push(mapped_arg);
                }
                let var = ctx.fresh_gen.fresh(f);
                ctx.binding.insert(var.clone());
                out_actions.push(GenericCoreAction::Let(
                    span.clone(),
                    var.clone(),
                    f.clone(),
                    norm_args,
                ));
                Ok(GenericExpr::Call(
                    span.clone(),
                    CorrespondingVar::new(f.clone(), var),
                    mapped_args,
                ))
            }
        }
    }
}

pub(crate) type ResolvedCoreRule = GenericCoreRule<ResolvedCall, ResolvedCall, ResolvedVar>;

impl<BodyCall, ActionCall, Leaf> GenericCoreRule<BodyCall, ActionCall, Leaf>
where
    Leaf: Clone + Eq + Hash,
{
    fn subst(&mut self, subst: &HashMap<Leaf, GenericAtomTerm<Leaf>>) {
        for atom in &mut self.body.atoms {
            atom.substitute_with(&mut |variable| subst.get(variable).cloned());
        }
        let substitutions = subst.iter().map(|(variable, term)| {
            GenericCoreAction::LetAtomTerm(term.span().clone(), variable.clone(), term.clone())
        });
        let actions = std::mem::take(&mut self.head.0);
        self.head.0 = substitutions.chain(actions).collect();
    }
}

impl<Head, Leaf> GenericCoreRule<HeadOrEq<Head>, Head, Leaf>
where
    Leaf: Eq + Clone + Hash + Debug,
    Head: Clone,
{
    /// Transformed a UnresolvedCoreRule into a CanonicalizedCoreRule.
    /// In particular, it removes equality checks between variables and
    /// other arguments, and turns equality checks between non-variable arguments
    /// into a primitive equality check `value-eq`.
    pub(crate) fn canonicalize(
        self,
        // Users need to pass in a substitute for equality constraints.
        value_eq: impl Fn(&GenericAtomTerm<Leaf>, &GenericAtomTerm<Leaf>) -> Head,
    ) -> GenericCoreRule<Head, Head, Leaf> {
        let mut result_rule = self;
        loop {
            let mut to_subst = None;
            for atom in result_rule.body.atoms.iter() {
                if atom.head.is_eq() && atom.args[0] != atom.args[1] {
                    match &atom.args[..] {
                        [GenericAtomTerm::Var(_, x), y] | [y, GenericAtomTerm::Var(_, x)] => {
                            to_subst = Some((x, y));
                            break;
                        }
                        _ => (),
                    }
                }
            }
            if let Some((x, y)) = to_subst {
                let subst = HashMap::from_iter([(x.clone(), y.clone())]);
                result_rule.subst(&subst);
            } else {
                break;
            }
        }

        let atoms = result_rule
            .body
            .atoms
            .into_iter()
            .filter_map(|atom| match atom.head {
                HeadOrEq::Eq => {
                    assert_eq!(atom.args.len(), 2);
                    match (&atom.args[0], &atom.args[1]) {
                        (GenericAtomTerm::Var(_, v1), GenericAtomTerm::Var(_, v2)) => {
                            assert_eq!(v1, v2);
                            None
                        }
                        (GenericAtomTerm::Var(..), _) | (_, GenericAtomTerm::Var(..)) => {
                            panic!("equalities between variable and non-variable arguments should have been canonicalized")
                        }
                        (at1, at2) => {
                            if at1 == at2 {
                                None
                            } else {
                                Some(GenericAtom {
                                    span: atom.span.clone(),
                                    head: value_eq(&atom.args[0], &atom.args[1]),
                                    args: vec![
                                        atom.args[0].clone(),
                                        atom.args[1].clone(),
                                        GenericAtomTerm::Literal(atom.span.clone(), Literal::Unit),
                                    ],
                                })
                            }
                        },
                    }
                }
                HeadOrEq::Head(symbol) => Some(GenericAtom {
                    span: atom.span.clone(),
                    head: symbol,
                    args: atom.args,
                }),
            })
            .collect();
        GenericCoreRule {
            span: result_rule.span,
            body: Query { atoms },
            head: result_rule.head,
        }
    }
}

fn equiv_groups_to_eq_constraints<Head, Leaf>(
    groups: &HashMap<(Head, Vec<GenericAtomTerm<Leaf>>), Vec<GenericAtomTerm<Leaf>>>,
    span: &Span,
) -> Vec<GenericAtom<HeadOrEq<Head>, Leaf>>
where
    Leaf: Eq + Clone + Hash + Debug,
    Head: Clone,
{
    let mut eq_constraints = vec![];
    for group in groups.values() {
        let first = &group[0];
        for other in &group[1..] {
            if first == other {
                continue;
            }
            eq_constraints.push(GenericAtom {
                span: span.clone(),
                head: HeadOrEq::Eq,
                args: vec![first.clone(), other.clone()],
            });
        }
    }
    eq_constraints
}

impl<Head, Leaf> GenericCoreRule<Head, Head, Leaf>
where
    Leaf: Eq + Clone + Hash + Debug,
    Head: Clone + Eq + Hash,
{
    /// Functions in egglog follow functional dependency, and this pass removes
    /// duplicate variables based on functional dependencies.
    /// For example, if we have two atoms `R(x, y, z1)` and `R(x, y, z2)`,
    /// then we can remove one of them and add an equality constraint `z1 = z2`.
    /// This is done until fixpoint, so it is kind of like rebuilding.
    pub(crate) fn remove_dup_vars(
        mut self,
        value_eq: impl Fn(&GenericAtomTerm<Leaf>, &GenericAtomTerm<Leaf>) -> Head,
    ) -> Self {
        // Maps function calls to sets of equivalent variables to be deduplicated
        let mut groups: HashMap<(Head, Vec<GenericAtomTerm<Leaf>>), Vec<GenericAtomTerm<Leaf>>> =
            HashMap::default();

        // Remove entries wit identical (head, inputs) pair and mark respective outputs to be merged.
        self.body.atoms.retain(|atom| {
            let (out, inp) = atom.args.split_last().unwrap();
            let key = (atom.head.clone(), inp.to_owned());
            let group = groups.entry(key).or_default();
            group.push(out.clone());
            group.len() == 1
        });

        let new_atoms = equiv_groups_to_eq_constraints(&groups, &self.span);

        if new_atoms.is_empty() {
            self
        } else {
            let atoms: Vec<GenericAtom<HeadOrEq<Head>, Leaf>> = new_atoms
                .into_iter()
                .chain(self.body.atoms.into_iter().map(|atom| GenericAtom {
                    span: atom.span,
                    head: HeadOrEq::Head(atom.head),
                    args: atom.args,
                }))
                .collect();

            GenericCoreRule {
                span: self.span,
                body: Query { atoms },
                head: self.head,
            }
            .canonicalize(&value_eq)
            .remove_dup_vars(value_eq)
        }
    }
}

pub(crate) trait GenericRuleExt<Head, Leaf> {
    fn to_core_rule(
        &self,
        typeinfo: &TypeInfo,
        fresh_gen: &mut impl FreshGen<Head, Leaf>,
        union_to_set_optimization: bool,
    ) -> Result<GenericCoreRule<HeadOrEq<Head>, Head, Leaf>, TypeError>
    where
        Head: Clone + Display + IsFunc + HeadOps,
        Leaf: Clone + PartialEq + Eq + Display + Hash + Debug;
}

impl<Head, Leaf> GenericRuleExt<Head, Leaf> for GenericRule<Head, Leaf>
where
    Head: Clone + Display + IsFunc + HeadOps,
    Leaf: Clone + PartialEq + Eq + Display + Hash + Debug,
{
    fn to_core_rule(
        &self,
        typeinfo: &TypeInfo,
        fresh_gen: &mut impl FreshGen<Head, Leaf>,
        union_to_set_optimization: bool,
    ) -> Result<GenericCoreRule<HeadOrEq<Head>, Head, Leaf>, TypeError>
    where
        Head: Clone + Display + IsFunc + HeadOps,
        Leaf: Clone + PartialEq + Eq + Display + Hash + Debug,
    {
        let (body, _correspondence) = Facts(self.body.clone()).to_query(typeinfo, fresh_gen);
        let mut binding = body.vars().collect::<IndexSet<_>>();
        let mut ctx =
            CoreActionContext::new(typeinfo, &mut binding, fresh_gen, union_to_set_optimization);
        let (head, _correspondence) = self.head.to_core_actions(&mut ctx)?;
        Ok(GenericCoreRule {
            span: self.span.clone(),
            body,
            head,
        })
    }
}

pub(crate) trait ResolvedRuleExt {
    fn to_canonicalized_core_rule(
        &self,
        typeinfo: &TypeInfo,
        fresh_gen: &mut SymbolGen,
        union_to_set_optimization: bool,
    ) -> Result<ResolvedCoreRule, TypeError>;
}

impl ResolvedRuleExt for ResolvedRule {
    fn to_canonicalized_core_rule(
        &self,
        typeinfo: &TypeInfo,
        fresh_gen: &mut SymbolGen,
        union_to_set_optimization: bool,
    ) -> Result<ResolvedCoreRule, TypeError> {
        let value_eq = &typeinfo.get_prims("value-eq").unwrap()[0];
        let value_eq = |at1: &ResolvedAtomTerm, at2: &ResolvedAtomTerm| {
            ResolvedCall::Primitive(SpecializedPrimitive {
                prim_with_id: value_eq.clone(),
                input: vec![atom_term_sort(at1), atom_term_sort(at2)],
                output: UnitSort.to_arcsort(),
            })
        };

        let rule = self.to_core_rule(typeinfo, fresh_gen, union_to_set_optimization)?;

        // The groundedness check happens before canonicalization, because canonicalization
        // may turn ungrounded variables in a query to unbounded variables in actions (e.g.,
        // `(rule ((= x y)) ((R x y)))`) but unboundedness is only checked during type checking.
        grounded_check(&rule)?;

        let rule = rule.canonicalize(&value_eq);

        let rule = rule.remove_dup_vars(value_eq);

        Ok(rule)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    type TestCoreRule = GenericCoreRule<String, String, String>;

    fn make_var(name: &str) -> GenericAtomTerm<String> {
        GenericAtomTerm::Var(span!(), name.to_string())
    }

    fn make_atom(head: &str, args: Vec<&str>) -> GenericAtom<String, String> {
        GenericAtom {
            span: span!(),
            head: head.to_string(),
            args: args.into_iter().map(make_var).collect(),
        }
    }

    fn value_eq_string(_at1: &GenericAtomTerm<String>, _at2: &GenericAtomTerm<String>) -> String {
        "value-eq".to_string()
    }

    #[test]
    fn test_remove_dup_vars_basic() {
        let rule = TestCoreRule {
            span: span!(),
            body: Query {
                atoms: vec![
                    make_atom("R", vec!["x", "y", "z1"]),
                    make_atom("R", vec!["x", "y", "z2"]),
                    make_atom("R", vec!["x", "z3"]),
                    make_atom("R", vec!["a", "b", "z4"]),
                    make_atom("R", vec!["c", "d", "z5"]),
                ],
            },
            head: GenericCoreActions::default(),
        };

        let result = rule.remove_dup_vars(value_eq_string);

        assert_eq!(result.body.atoms.len(), 4);
        assert_eq!(result.body.atoms[0].head, "R");
        assert_eq!(result.body.atoms[0].args[0], make_var("x"));
        assert_eq!(result.body.atoms[0].args[1], make_var("y"));
        assert_eq!(result.body.atoms[1].args.len(), 2);
    }

    #[test]
    fn test_remove_dup_vars_fixpoint() {
        // Test: R(x, y, z1), R(x, y, z2), R(x, y, z3) should all get unified
        // This tests that the fixpoint iteration works correctly
        let rule = TestCoreRule {
            span: span!(),
            body: Query {
                atoms: vec![
                    make_atom("R", vec!["x", "y", "z1"]),
                    make_atom("R", vec!["x", "y", "z2"]),
                    make_atom("R", vec!["x", "y", "z3"]),
                    make_atom("S", vec!["z1", "z2", "z3"]),
                    make_atom("S", vec!["z2", "z1", "z4"]),
                ],
            },
            head: GenericCoreActions::default(),
        };

        let result = rule.remove_dup_vars(value_eq_string);

        assert_eq!(result.body.atoms.len(), 2);
        assert_eq!(result.body.atoms[0].head, "R");
        assert_eq!(result.body.atoms[0].args[0], make_var("x"));
        assert_eq!(result.body.atoms[0].args[1], make_var("y"));
        assert_eq!(result.body.atoms[1].args[0], result.body.atoms[1].args[1]);

        let rule = TestCoreRule {
            span: span!(),
            body: Query {
                atoms: vec![
                    make_atom("R", vec!["x", "y", "z1"]),
                    make_atom("R", vec!["x", "y", "z2"]),
                    make_atom("R", vec!["x", "y", "z3"]),
                    make_atom("R", vec!["z1", "z2", "z1"]),
                    make_atom("R", vec!["z2", "z1", "x"]),
                    make_atom("R", vec!["z2", "z2", "y"]),
                ],
            },
            head: GenericCoreActions::default(),
        };

        let result = rule.remove_dup_vars(value_eq_string);

        assert_eq!(result.body.atoms.len(), 1);
        assert_eq!(result.body.atoms[0].head, "R");
        assert_eq!(result.body.atoms[0].args[0], result.body.atoms[0].args[1]);
        assert_eq!(result.body.atoms[0].args[0], result.body.atoms[0].args[2]);
    }

    #[test]
    fn test_remove_dup_vars_with_actions_using_removed_var() {
        let rule = TestCoreRule {
            span: span!(),
            body: Query {
                atoms: vec![
                    make_atom("R", vec!["x", "y", "z1"]),
                    make_atom("R", vec!["x", "y", "z2"]),
                ],
            },
            head: GenericCoreActions(vec![GenericCoreAction::Union(
                span!(),
                make_var("z2"),
                make_var("z1"),
            )]),
        };

        let result = rule.remove_dup_vars(value_eq_string);

        assert_eq!(result.body.atoms.len(), 1);
        assert!(matches!(
            &result.head.0.as_slice(),
            &[
                GenericCoreAction::LetAtomTerm(_, _, _),
                GenericCoreAction::Union(_, _, _)
            ]
        ));
    }
}
