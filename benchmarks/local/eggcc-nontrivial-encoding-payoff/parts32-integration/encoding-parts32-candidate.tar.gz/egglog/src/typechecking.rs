use std::hash::Hasher;

use crate::Context;
use crate::proofs::proof_container_rebuild::register_container_rebuild_from_spec;
use crate::{
    core::{CoreActionContext, GenericActionsExt, ResolvedCall},
    *,
};
use ast::{
    MappedExprExt, ResolvedAction, ResolvedExpr, ResolvedFact, ResolvedRule, ResolvedVar, Rule,
    RuleEvalMode,
};
use core_relations::ExternalFunction;
use egglog_ast::generic_ast::GenericAction;
use egglog_bridge::{ActionRegistry, SharedActionRegistry};
use enum_map::EnumMap;
use std::sync::Arc;

// `ExternalFunction` wrapper for `PurePrim`. Holds the primitive
// directly so the dispatch chain `external_funcs[id].invoke(...)` →
// `T::apply(...)` is just one vtable hop plus a direct call — no
// closure indirection that defeats inlining.
#[derive(Clone)]
struct PurePrimWrapper<T> {
    prim: T,
    /// The call-site [`Context`] this wrapper stamps onto the
    /// `PureState` before dispatching. `register_per_context` commits
    /// one wrapper per valid `Context` for the trait, so the
    /// typechecker's pick at each call site is encoded directly here.
    ctx: Context,
}

impl<T: PurePrim + Clone> ExternalFunction for PurePrimWrapper<T> {
    fn invoke(&self, exec_state: &mut ExecutionState, args: &[Value]) -> Option<Value> {
        self.prim.apply(PureState::wrap(exec_state, self.ctx), args)
    }
}

// `ExternalFunction` wrapper for primitives that need the
// `ActionRegistry` (`ReadPrim`, `WritePrim`, `FullPrim`). One generic
// over the `Wrap` strategy that knows how to construct the right
// state type and dispatch to the primitive's `apply`.
#[derive(Clone)]
struct RegistryPrimWrapper<T, S> {
    prim: T,
    registry: SharedActionRegistry,
    /// Stamped onto the state wrapper.
    ctx: Context,
    _wrap: std::marker::PhantomData<fn() -> S>,
}

trait RegistryWrap<T>: Clone + Send + Sync {
    fn invoke(
        prim: &T,
        exec_state: &mut ExecutionState,
        ctx: Context,
        args: &[Value],
        registry: &ActionRegistry,
    ) -> Option<Value>;
}

#[derive(Clone)]
struct WrapRead;
impl<T: ReadPrim> RegistryWrap<T> for WrapRead {
    #[inline]
    fn invoke(
        prim: &T,
        exec_state: &mut ExecutionState,
        ctx: Context,
        args: &[Value],
        registry: &ActionRegistry,
    ) -> Option<Value> {
        prim.apply(ReadState::wrap(exec_state, registry, ctx), args)
    }
}
#[derive(Clone)]
struct WrapWrite;
impl<T: WritePrim> RegistryWrap<T> for WrapWrite {
    #[inline]
    fn invoke(
        prim: &T,
        exec_state: &mut ExecutionState,
        ctx: Context,
        args: &[Value],
        registry: &ActionRegistry,
    ) -> Option<Value> {
        prim.apply(WriteState::wrap(exec_state, registry, ctx), args)
    }
}
#[derive(Clone)]
struct WrapFull;
impl<T: FullPrim> RegistryWrap<T> for WrapFull {
    #[inline]
    fn invoke(
        prim: &T,
        exec_state: &mut ExecutionState,
        ctx: Context,
        args: &[Value],
        registry: &ActionRegistry,
    ) -> Option<Value> {
        prim.apply(FullState::wrap(exec_state, registry, ctx), args)
    }
}

impl<T: Clone + Send + Sync + 'static, S: RegistryWrap<T> + 'static> ExternalFunction
    for RegistryPrimWrapper<T, S>
{
    fn invoke(&self, exec_state: &mut ExecutionState, args: &[Value]) -> Option<Value> {
        let registry = self.registry.read();
        S::invoke(&self.prim, exec_state, self.ctx, args, &registry)
    }
}

#[derive(Clone, Debug)]
pub struct FuncType {
    pub name: String,
    pub subtype: FunctionSubtype,
    pub input: Vec<ArcSort>,
    /// The output (value-column) sorts, primary first. A tuple-output function has more than one;
    /// ordinary functions have exactly one. Always non-empty.
    pub outputs: Vec<ArcSort>,
}

impl FuncType {
    /// The primary (first) output sort.
    pub fn output(&self) -> &ArcSort {
        &self.outputs[0]
    }

    /// The number of output (value) columns.
    pub fn num_outputs(&self) -> usize {
        self.outputs.len()
    }

    /// Whether this function has more than one output column.
    pub fn is_tuple_output(&self) -> bool {
        self.outputs.len() > 1
    }
}

impl PartialEq for FuncType {
    fn eq(&self, other: &Self) -> bool {
        if self.name == other.name
            && self.subtype == other.subtype
            && self.num_outputs() == other.num_outputs()
            && self
                .outputs
                .iter()
                .zip(other.outputs.iter())
                .all(|(a, b)| a.name() == b.name())
        {
            if self.input.len() != other.input.len() {
                return false;
            }
            for (a, b) in self.input.iter().zip(other.input.iter()) {
                if a.name() != b.name() {
                    return false;
                }
            }
            true
        } else {
            false
        }
    }
}

impl Eq for FuncType {}

impl Hash for FuncType {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.name.hash(state);
        self.subtype.hash(state);
        for out in &self.outputs {
            out.name().hash(state);
        }
        for inp in &self.input {
            inp.name().hash(state);
        }
    }
}
/// Validators take a termdag and arguments (as TermIds) and return
/// a newly computed TermId if the primitive application is valid,
/// or None if it is invalid.
pub type PrimitiveValidator = Arc<dyn Fn(&mut TermDag, &[TermId]) -> Option<TermId> + Send + Sync>;

#[derive(Clone)]
pub struct PrimitiveWithId {
    pub(crate) primitive: Arc<dyn Primitive>,
    pub(crate) validator: Option<PrimitiveValidator>,
    /// Runtime entrypoints for the contexts this primitive is valid in.
    /// The primitive definition is stored once, while each context keeps
    /// its own runtime id so higher-order dispatch can still recover the
    /// application context at runtime.
    pub(crate) context_ids: EnumMap<Context, Option<ExternalFunctionId>>,
}

impl PrimitiveWithId {
    /// Takes the full signature of a primitive (both input and output types).
    /// Returns whether the primitive is compatible with this signature.
    pub fn accept(&self, tys: &[Arc<dyn Sort>], typeinfo: &TypeInfo) -> bool {
        let mut constraints = vec![];
        let lits: Vec<_> = (0..tys.len())
            .map(|i| AtomTerm::Literal(Span::Panic, Literal::Int(i as i64)))
            .collect();
        for (lit, ty) in lits.iter().zip(tys.iter()) {
            constraints.push(constraint::assign(lit.clone(), ty.clone()))
        }
        constraints.extend(
            self.primitive
                .get_type_constraints(&Span::Panic)
                .get(&lits, typeinfo),
        );
        let problem = Problem {
            constraints,
            range: HashSet::default(),
        };
        problem.solve(|sort| sort.name()).is_ok()
    }

    /// Returns whether this primitive has a runtime entrypoint for `context`.
    pub fn is_valid_in_context(&self, context: Context) -> bool {
        self.context_ids[context].is_some()
    }
}

impl Debug for PrimitiveWithId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Prim({})", self.primitive.name())
    }
}

/// Stores resolved typechecking information.
#[derive(Clone, Default)]
pub struct TypeInfo {
    mksorts: HashMap<String, MkSort>,
    // TODO(yz): I want to get rid of this as now we have user-defined primitives and constraint based type checking
    reserved_primitives: HashSet<&'static str>,
    pub(crate) sorts: HashMap<String, Arc<dyn Sort>>,
    primitives: HashMap<String, Vec<PrimitiveWithId>>,
    func_types: HashMap<String, Arc<FuncType>>,
    pub(crate) global_sorts: HashMap<String, ArcSort>,
    /// Sorts that do not allow union (e.g., from `:no-union` sorts or relations).
    pub(crate) non_unionable_sorts: HashSet<String>,
    /// Declared indexes, by the name their atoms are written with.
    pub(crate) indexes: HashMap<String, IndexInfo>,
    /// Function declarations hidden from user-facing table listings.
    pub(crate) hidden_functions: HashSet<String>,
}

/// A declared index: a read-only relation over the rows of `function`, holding
/// each value appearing in `any_of` followed by the whole row.
#[derive(Clone, Debug)]
pub struct IndexInfo {
    pub function: String,
    /// Column indices of `function`'s row (its inputs then its outputs), read
    /// disjunctively.
    pub any_of: Vec<usize>,
}

// These methods need to be on the `EGraph` in order to register sorts and
// primitives with the runtime.
impl EGraph {
    /// Add a user-defined sort to the e-graph.
    ///
    /// Also look at [`prelude::add_base_sort`] for a convenience method for adding user-defined sorts
    pub fn add_sort<S: Sort + 'static>(&mut self, sort: S, span: Span) -> Result<(), TypeError> {
        self.add_arcsort(Arc::new(sort), span)
    }

    /// Declare a sort. This corresponds to the `sort` keyword in egglog.
    /// It can either declares a new [`EqSort`] if `presort_and_args` is not provided,
    /// or an instantiation of a presort (e.g., containers like `Vec`).
    pub fn declare_sort(
        &mut self,
        name: impl Into<String>,
        presort_and_args: &Option<(String, Vec<Expr>)>,
        span: Span,
    ) -> Result<(), TypeError> {
        let name = name.into();
        if self.type_info.func_types.contains_key(&name) {
            return Err(TypeError::FunctionAlreadyBound(name, span));
        }

        let sort = match presort_and_args {
            None => Arc::new(EqSort { name }),
            Some((presort, args)) => {
                if let Some(mksort) = self.type_info.mksorts.get(presort) {
                    mksort(&mut self.type_info, name, args, span.clone())?
                } else {
                    return Err(TypeError::PresortNotFound(presort.clone(), span));
                }
            }
        };

        self.add_arcsort(sort, span)
    }

    /// Add a user-defined sort to the e-graph.
    pub fn add_arcsort(&mut self, sort: ArcSort, span: Span) -> Result<(), TypeError> {
        sort.register_type(&mut self.backend);

        let name = sort.name();
        match self.type_info.sorts.entry(name.to_owned()) {
            HEntry::Occupied(_) => Err(TypeError::SortAlreadyBound(name.to_owned(), span)),
            HEntry::Vacant(e) => {
                e.insert(sort.clone());
                // A sort's primitives already reach the term-encoding typechecker
                // through its OWN `add_arcsort` when it typechecks the sort
                // command, so don't propagate them again from here (that would
                // double-register and make primitive resolution ambiguous).
                // Detach the typechecker while the sort registers, so only direct
                // `add_*_primitive` calls propagate to it.
                let saved = self.proof_state.original_typechecking.take();
                sort.register_primitives(self);
                self.proof_state.original_typechecking = saved;
                Ok(())
            }
        }
    }

    /// Register a [`PurePrim`]. Pass `None` for the validator if not
    /// using the proof checker.
    ///
    /// Pick the trait whose state wrapper matches the body's needs:
    /// [`PurePrim`] for pure ops, [`WritePrim`] for writes,
    /// [`ReadPrim`] for table reads, [`FullPrim`] for both. The Rust
    /// type checker enforces the body only uses methods the chosen
    /// state allows.
    pub fn add_pure_primitive<T>(&mut self, x: T, validator: Option<PrimitiveValidator>)
    where
        T: PurePrim + Clone,
    {
        self.register_per_context(
            x,
            validator,
            PureState::valid_contexts(),
            |egraph, x, ctx| {
                egraph.register_external_func(Box::new(PurePrimWrapper { prim: x, ctx }))
            },
        );
    }

    /// Register a [`WritePrim`]. Pass `None` for the validator if not
    /// using the proof checker.
    pub fn add_write_primitive<T>(&mut self, x: T, validator: Option<PrimitiveValidator>)
    where
        T: WritePrim + Clone,
    {
        self.register_registry_primitive::<T, WrapWrite>(
            x,
            validator,
            WriteState::valid_contexts(),
        );
    }

    /// Register a [`ReadPrim`]. Pass `None` for the validator if not
    /// using the proof checker.
    pub fn add_read_primitive<T>(&mut self, x: T, validator: Option<PrimitiveValidator>)
    where
        T: ReadPrim + Clone,
    {
        self.register_registry_primitive::<T, WrapRead>(x, validator, ReadState::valid_contexts());
    }

    /// Register a [`FullPrim`]. Pass `None` for the validator if not
    /// using the proof checker.
    pub fn add_full_primitive<T>(&mut self, x: T, validator: Option<PrimitiveValidator>)
    where
        T: FullPrim + Clone,
    {
        self.register_registry_primitive::<T, WrapFull>(x, validator, FullState::valid_contexts());
    }

    fn register_registry_primitive<T, S>(
        &mut self,
        x: T,
        validator: Option<PrimitiveValidator>,
        valid_ctxs: &[Context],
    ) where
        T: Primitive + Clone,
        S: RegistryWrap<T> + 'static,
    {
        self.register_per_context(x, validator, valid_ctxs, |egraph, x, ctx| {
            let registry = egraph.action_registry().clone();
            egraph.register_external_func(Box::new(RegistryPrimWrapper::<T, S> {
                prim: x,
                registry,
                ctx,
                _wrap: std::marker::PhantomData,
            }))
        });
    }

    /// Register an internal term-encoding primitive. `prim` supplies only the
    /// type constraints; `make_id` creates its runtime entrypoint on each
    /// e-graph in the typechecker chain.
    pub(crate) fn add_internal_primitive<T, F>(
        &mut self,
        prim: T,
        valid_ctxs: &[Context],
        mut make_id: F,
    ) where
        T: Primitive + Clone,
        F: FnMut(&mut egglog_bridge::EGraph, Context) -> ExternalFunctionId,
    {
        self.register_per_context(prim, None, valid_ctxs, move |egraph, _x, ctx| {
            make_id(egraph, ctx)
        });
    }

    /// Shared registration engine. Stores one primitive definition, plus
    /// one runtime id per valid [`Context`]. Each wrapper carries its
    /// specific context stamped onto the state wrapper at invoke time.
    ///
    /// The typechecker filters by the context-id mask at each call site;
    /// an `unstable-fn` value built around the primitive bakes *all*
    /// signature-matching context ids, and `FunctionContainer::apply`
    /// picks the one whose context matches the application ctx — so
    /// values flow freely across contexts.
    fn register_per_context<T, F>(
        &mut self,
        x: T,
        validator: Option<PrimitiveValidator>,
        valid_ctxs: &[Context],
        mut build_wrapper: F,
    ) where
        T: Primitive + Clone,
        F: FnMut(&mut egglog_bridge::EGraph, T, Context) -> ExternalFunctionId,
    {
        // Register on this e-graph AND every term-encoding typechecker down the
        // chain. Each typechecker is a separate e-graph that typechecks the
        // encoded program (see `typecheck_program`); a primitive added after
        // construction is otherwise unknown to it and reported as unbound. A
        // typechecker only typechecks and never evaluates, so the wrapper's
        // runtime state is irrelevant there, and — since both e-graphs register
        // the same built-ins during construction — a primitive added to both
        // gets the same `ExternalFunctionId`.
        let mut eg: &mut EGraph = self;
        loop {
            let primitive: Arc<dyn Primitive> = Arc::new(x.clone());
            let name = primitive.name().to_owned();
            let context_ids = EnumMap::from_fn(|ctx| {
                valid_ctxs
                    .contains(&ctx)
                    .then(|| build_wrapper(&mut eg.backend, x.clone(), ctx))
            });
            eg.type_info
                .primitives
                .entry(name)
                .or_default()
                .push(PrimitiveWithId {
                    primitive,
                    validator: validator.clone(),
                    context_ids,
                });
            match eg.proof_state.original_typechecking.as_deref_mut() {
                Some(next) => eg = next,
                None => break,
            }
        }
    }
}

impl EGraph {
    pub(crate) fn typecheck_program(
        &mut self,
        program: &Vec<NCommand>,
    ) -> Result<Vec<ResolvedNCommand>, TypeError> {
        let mut result = vec![];
        for command in program {
            result.push(self.typecheck_command(command)?);
        }
        Ok(result)
    }

    /// Validate an index declaration and register it as a read-only relation
    /// `(value, <row of `function`>)`, so its atoms resolve like any other.
    fn typecheck_index(
        &mut self,
        span: &Span,
        name: &str,
        function: &str,
        any_of: &[usize],
    ) -> Result<(), TypeError> {
        if self.type_info.func_types.contains_key(name) {
            return Err(TypeError::FunctionAlreadyBound(
                name.to_owned(),
                span.clone(),
            ));
        }
        // An index is a view over a function's table; it has no table of its own
        // for a second index to read.
        if self.type_info.indexes.contains_key(function) {
            return Err(TypeError::IndexOfIndex(
                name.to_owned(),
                function.to_owned(),
                span.clone(),
            ));
        }
        let ft = self
            .type_info
            .get_func_type(function)
            .ok_or_else(|| TypeError::UnboundFunction(function.to_owned(), span.clone()))?;
        // The indexable row is the function's inputs followed by its outputs.
        let row: Vec<ArcSort> = ft.input.iter().chain(ft.outputs.iter()).cloned().collect();
        if any_of.is_empty() {
            return Err(TypeError::EmptyIndex(name.to_owned(), span.clone()));
        }
        let mut value_sort: Option<ArcSort> = None;
        for &col in any_of {
            let sort = row.get(col).ok_or_else(|| {
                TypeError::IndexColumnOutOfRange(name.to_owned(), col, row.len(), span.clone())
            })?;
            match &value_sort {
                None => value_sort = Some(sort.clone()),
                Some(prev) if prev.name() == sort.name() => {}
                Some(prev) => {
                    return Err(TypeError::IndexColumnSortMismatch(
                        name.to_owned(),
                        prev.name().to_owned(),
                        sort.name().to_owned(),
                        span.clone(),
                    ));
                }
            }
        }
        let mut input = vec![value_sort.expect("any_of is non-empty")];
        input.extend(row);
        let unit = self.type_info.sorts.get("Unit").expect("Unit sort").clone();
        self.type_info.func_types.insert(
            name.to_owned(),
            Arc::new(FuncType {
                name: name.to_owned(),
                subtype: FunctionSubtype::Custom,
                input,
                outputs: vec![unit],
            }),
        );
        self.type_info.indexes.insert(
            name.to_owned(),
            IndexInfo {
                function: function.to_owned(),
                any_of: any_of.to_vec(),
            },
        );
        Ok(())
    }

    fn typecheck_command(&mut self, command: &NCommand) -> Result<ResolvedNCommand, TypeError> {
        let symbol_gen = &mut self.parser.symbol_gen;

        let command: ResolvedNCommand = match command {
            NCommand::Function(fdecl) => {
                let resolved = self.type_info.typecheck_function(symbol_gen, fdecl)?;
                // An FD view (a function marked `:internal-view`, with a tuple
                // `(eclass, proof)` output) gets a `set-if-empty` primitive (+ a
                // proof-column reader) so the encoding can canonicalize a term to
                // the view's e-class at insertion time. Registered here so it
                // survives re-parse of the desugared program.
                if resolved.internal_view.is_some()
                    && let Some(ft) = self.type_info.get_func_type(&resolved.name)
                    && ft.outputs.len() >= 2
                {
                    let (name, input, outputs) =
                        (resolved.name.clone(), ft.input.clone(), ft.outputs.clone());
                    crate::proofs::proof_fresh::register_set_if_empty(self, &name, input, outputs);
                }
                // An internal proof-node relation (whose last input is the minted
                // id) gets a mint primitive, so the encoding writes a node in one
                // statement. Registered here for the same reason as `set-if-empty`
                // above.
                if resolved.internal_term_node
                    && let Some(ft) = self.type_info.get_func_type(&resolved.name)
                    && let Some((id_sort, arg_sorts)) = ft.input.split_last()
                    && id_sort.is_eq_sort()
                {
                    // `register_mint` stages one `Unit` value column, so a proof-node
                    // relation must declare exactly that.
                    debug_assert!(
                        matches!(ft.outputs.as_slice(), [out] if out.name() == "Unit"),
                        "proof-node relation `{}` must declare one `Unit` value column, got {:?}",
                        resolved.name,
                        ft.outputs.iter().map(|out| out.name()).collect::<Vec<_>>(),
                    );
                    let (name, id_sort, arg_sorts) =
                        (resolved.name.clone(), id_sort.clone(), arg_sorts.to_vec());
                    crate::proofs::proof_fresh::register_mint(self, &name, arg_sorts, id_sort);
                }
                // If this is a let binding, add it to global_sorts
                // This preserves behavior for lets after desugaring
                if resolved.internal_let {
                    let output_sort = self.type_info.sorts.get(fdecl.schema.output()).unwrap();
                    self.type_info
                        .global_sorts
                        .insert(fdecl.name.clone(), output_sort.clone());
                }
                ResolvedNCommand::Function(resolved)
            }
            NCommand::NormRule { rule } => ResolvedNCommand::NormRule {
                rule: self
                    .type_info
                    .typecheck_rule(symbol_gen, rule, self.seminaive)?,
            },
            NCommand::Sort {
                span,
                name,
                presort_and_args,
                uf,
                container_rebuild,
                proof_constructors,
                unionable,
            } => {
                // Note this is bad since typechecking should be pure and idempotent
                // Otherwise typechecking the same program twice will fail
                self.declare_sort(name.clone(), presort_and_args, span.clone())?;
                // Mark as non-unionable if the sort declaration says so
                if !unionable {
                    self.type_info.non_unionable_sorts.insert(name.clone());
                }
                // Record this sort's UF table and the global proof-constructor
                // names in proof_state (as run_command also does) so the
                // container rebuild registration below can recover them.
                if let Some((uf_ctor, _uf_index)) = uf {
                    self.proof_state
                        .uf_parent
                        .insert(name.clone(), uf_ctor.clone());
                    // The rebuild rules canonicalize a term in their action
                    // through these, derived from the sort's `@UF_<S>` table.
                    // Proof mode is on exactly when the encoding's `Proof` sort
                    // has been declared, which the proof header does before any
                    // encoded sort.
                    let proofs = self
                        .type_info
                        .sorts
                        .contains_key(&self.proof_state.proof_names.proof_datatype);
                    crate::proofs::proof_container_rebuild::register_uf_canon(
                        self, name, uf_ctor, proofs,
                    );
                }
                // The Proof sort records the global proof constructors; restore
                // them into proof_state so container rebuild can recover them
                // (the `Proof` datatype name is this sort's own name).
                if let Some(pc) = proof_constructors {
                    let names = &mut self.proof_state.proof_names;
                    names.proof_datatype = name.clone();
                    names.congr_constructor = pc.congr.clone();
                    names.congr_all_constructor = pc.congr_all.clone();
                    names.eq_trans_constructor = pc.trans.clone();
                    names.eq_sym_constructor = pc.sym.clone();
                    names.container_normalize_constructor = pc.normalize.clone();
                    names.fiat_prefix = pc.fiat.clone();
                    names.proj_constructor = pc.proj.clone();
                    names.proj_prim_prefix = pc.proj_prim.clone();
                }
                // A container sort under the term/proof encoding carries a spec
                // for its rebuild primitives; register them here so they are
                // available both during encoding and when the desugared program
                // is re-parsed.
                if let Some(spec) = container_rebuild {
                    register_container_rebuild_from_spec(self, name, spec);
                }
                ResolvedNCommand::Sort {
                    span: span.clone(),
                    name: name.clone(),
                    presort_and_args: presort_and_args.clone(),
                    uf: uf.clone(),
                    container_rebuild: container_rebuild.clone(),
                    proof_constructors: proof_constructors.clone(),
                    unionable: *unionable,
                }
            }
            NCommand::CoreAction(action @ Action::Let(span, var, _)) => {
                let action = self.type_info.typecheck_standalone_action(
                    symbol_gen,
                    action,
                    &Default::default(),
                    Context::Full,
                )?;
                self.ensure_global_name_prefix(span, var)?;
                let ResolvedAction::Let(_, resolved_var, _) = &action else {
                    unreachable!("typechecking an Action::Let should return ResolvedAction::Let")
                };
                self.type_info
                    .global_sorts
                    .insert(resolved_var.name.clone(), resolved_var.sort.clone());
                ResolvedNCommand::CoreAction(action)
            }
            NCommand::CoreAction(action) => {
                ResolvedNCommand::CoreAction(self.type_info.typecheck_standalone_action(
                    symbol_gen,
                    action,
                    &Default::default(),
                    Context::Full,
                )?)
            }
            NCommand::CoreActions(actions) => {
                ResolvedNCommand::CoreActions(self.type_info.typecheck_standalone_actions(
                    symbol_gen,
                    actions,
                    &Default::default(),
                    Context::Full,
                )?)
            }
            NCommand::LetBegin(span, name, actions) => {
                let resolved = self.type_info.typecheck_standalone_actions(
                    symbol_gen,
                    actions,
                    &Default::default(),
                    Context::Full,
                )?;
                self.ensure_global_name_prefix(span, name)?;
                // The parser guarantees a trailing expression; its type is the
                // global's.
                let Some(ResolvedAction::Expr(_, value)) = resolved.0.last() else {
                    unreachable!("(let _ (begin ...)) must end with an expression")
                };
                let sort = value.output_type();
                self.type_info
                    .global_sorts
                    .insert(name.clone(), sort.clone());
                let resolved_var = ResolvedVar {
                    name: name.clone(),
                    sort,
                    is_global_ref: false,
                };
                ResolvedNCommand::LetBegin(span.clone(), resolved_var, resolved)
            }
            NCommand::Extract(span, expr, variants) => {
                // A tuple-output function returns more than one value, so it can't be extracted as a
                // single term; surface a clear error instead of a confusing arity mismatch.
                if let GenericExpr::Call(_, head, _) = expr
                    && self
                        .type_info
                        .get_func_type(head)
                        .is_some_and(|t| t.is_tuple_output())
                {
                    return Err(TypeError::CannotExtractTupleOutput(
                        head.clone(),
                        span.clone(),
                    ));
                }
                let res_expr = self.type_info.typecheck_standalone_expr(
                    symbol_gen,
                    expr,
                    &Default::default(),
                    Context::Full,
                )?;

                let res_variants = self.type_info.typecheck_standalone_expr(
                    symbol_gen,
                    variants,
                    &Default::default(),
                    Context::Full,
                )?;
                if res_variants.output_type().name() != I64Sort.name() {
                    return Err(TypeError::Mismatch {
                        expr: variants.clone(),
                        expected: I64Sort.to_arcsort(),
                        actual: res_variants.output_type(),
                    });
                }

                ResolvedNCommand::Extract(span.clone(), res_expr, res_variants)
            }
            NCommand::Check(span, facts) => ResolvedNCommand::Check(
                span.clone(),
                self.type_info.typecheck_facts(symbol_gen, facts)?,
            ),
            NCommand::Fail(span, cmds) => ResolvedNCommand::Fail(
                span.clone(),
                cmds.iter()
                    .map(|cmd| self.typecheck_command(cmd))
                    .collect::<Result<_, _>>()?,
            ),
            NCommand::RunSchedule(schedule) => ResolvedNCommand::RunSchedule(
                self.type_info.typecheck_schedule(symbol_gen, schedule)?,
            ),
            NCommand::Pop(span, n) => ResolvedNCommand::Pop(span.clone(), *n),
            NCommand::Push(n) => ResolvedNCommand::Push(*n),
            NCommand::Index {
                span,
                name,
                function,
                any_of,
            } => {
                self.typecheck_index(span, name, function, any_of)?;
                ResolvedNCommand::Index {
                    span: span.clone(),
                    name: name.clone(),
                    function: function.clone(),
                    any_of: any_of.clone(),
                }
            }
            NCommand::AddRuleset(span, ruleset) => {
                ResolvedNCommand::AddRuleset(span.clone(), ruleset.clone())
            }
            NCommand::UnstableCombinedRuleset(span, name, sub_rulesets) => {
                ResolvedNCommand::UnstableCombinedRuleset(
                    span.clone(),
                    name.clone(),
                    sub_rulesets.clone(),
                )
            }
            NCommand::PrintOverallStatistics(span, file) => {
                ResolvedNCommand::PrintOverallStatistics(span.clone(), file.clone())
            }
            NCommand::PrintFunction(span, table, size, file, mode) => {
                ResolvedNCommand::PrintFunction(
                    span.clone(),
                    table.clone(),
                    *size,
                    file.clone(),
                    *mode,
                )
            }
            NCommand::PrintSize(span, n) => {
                // Should probably also resolve the function symbol here
                ResolvedNCommand::PrintSize(span.clone(), n.clone())
            }
            NCommand::ProveExists(span, constructor) => {
                // prove-exists targets a table: a constructor, or the view
                // standing in for one under the term/proof encoding.
                // `get_func_type` already rejects primitives/unbound names.
                let func_type = self
                    .type_info
                    .get_func_type(constructor)
                    .ok_or_else(|| TypeError::UnboundFunction(constructor.clone(), span.clone()))?;
                ResolvedNCommand::ProveExists(span.clone(), ResolvedCall::Func(func_type.clone()))
            }
            NCommand::Output { span, file, exprs } => {
                let exprs = exprs
                    .iter()
                    .map(|expr| {
                        self.type_info.typecheck_standalone_expr(
                            symbol_gen,
                            expr,
                            &Default::default(),
                            Context::Full,
                        )
                    })
                    .collect::<Result<Vec<_>, _>>()?;
                ResolvedNCommand::Output {
                    span: span.clone(),
                    file: file.clone(),
                    exprs,
                }
            }
            NCommand::Input {
                span,
                name,
                file,
                proof_base,
            } => ResolvedNCommand::Input {
                span: span.clone(),
                name: name.clone(),
                file: file.clone(),
                proof_base: *proof_base,
            },
            NCommand::UserDefined(span, name, exprs) => {
                ResolvedNCommand::UserDefined(span.clone(), name.clone(), exprs.clone())
            }
        };
        if let ResolvedNCommand::NormRule { rule } = &command {
            self.warn_for_prefixed_non_globals_in_rule(rule)?;
        }
        Ok(command)
    }

    fn warn_for_prefixed_non_globals_in_var(
        &mut self,
        span: &Span,
        var: &ResolvedVar,
    ) -> Result<(), TypeError> {
        if var.is_global_ref {
            return Ok(());
        }
        if var.name.starts_with(crate::GLOBAL_NAME_PREFIX) {
            self.warn_prefixed_non_globals(span, &var.name)?;
        }
        Ok(())
    }

    fn warn_for_prefixed_non_globals_in_rule(
        &mut self,
        rule: &ResolvedRule,
    ) -> Result<(), TypeError> {
        let mut res: Result<(), TypeError> = Ok(());

        for fact in &rule.body {
            fact.visit_vars(&mut |span, var| {
                if res.is_ok() {
                    res = self.warn_for_prefixed_non_globals_in_var(span, var);
                }
            });
        }

        rule.head.visit_vars(&mut |span, var| {
            if res.is_ok() {
                res = self.warn_for_prefixed_non_globals_in_var(span, var);
            }
        });
        res
    }
}

impl TypeInfo {
    /// Adds a sort constructor to the typechecker's known set of types.
    pub fn add_presort<S: Presort>(&mut self, span: Span) -> Result<(), TypeError> {
        let name = S::presort_name();
        match self.mksorts.entry(name.to_owned()) {
            HEntry::Occupied(_) => Err(TypeError::SortAlreadyBound(name.to_owned(), span)),
            HEntry::Vacant(e) => {
                e.insert(S::make_sort);
                self.reserved_primitives.extend(S::reserved_primitives());
                Ok(())
            }
        }
    }

    /// Returns all sorts that satisfy the type and predicate.
    pub fn get_sorts_by<S: Sort>(&self, pred: impl Fn(&Arc<S>) -> bool) -> Vec<Arc<S>> {
        let mut results = Vec::new();
        for sort in self.sorts.values() {
            let sort = sort.clone().as_arc_any();
            if let Ok(sort) = Arc::downcast(sort)
                && pred(&sort)
            {
                results.push(sort);
            }
        }
        results
    }

    /// Returns all sorts based on the type.
    pub fn get_sorts<S: Sort>(&self) -> Vec<Arc<S>> {
        self.get_sorts_by(|_| true)
    }

    /// Returns a sort that satisfies the type and predicate.
    pub fn get_sort_by<S: Sort>(&self, pred: impl Fn(&Arc<S>) -> bool) -> Arc<S> {
        let results = self.get_sorts_by(pred);
        assert_eq!(
            results.len(),
            1,
            "Expected exactly one sort for type {}",
            std::any::type_name::<S>()
        );
        results.into_iter().next().unwrap()
    }

    /// Returns a sort based on the type.
    pub fn get_sort<S: Sort>(&self) -> Arc<S> {
        self.get_sort_by(|_| true)
    }

    /// Returns all sorts that satisfy the predicate.
    pub fn get_arcsorts_by(&self, f: impl Fn(&ArcSort) -> bool) -> Vec<ArcSort> {
        self.sorts.values().filter(|&x| f(x)).cloned().collect()
    }

    /// Returns a sort based on the predicate.
    pub fn get_arcsort_by(&self, f: impl Fn(&ArcSort) -> bool) -> ArcSort {
        let results = self.get_arcsorts_by(f);
        assert_eq!(
            results.len(),
            1,
            "Expected exactly one sort matching the given predicate"
        );
        results.into_iter().next().unwrap()
    }

    /// Returns the unique sort whose runtime values have Rust type `T`.
    pub fn get_arcsort_for_value_type<T: 'static>(&self) -> ArcSort {
        let results = self.get_arcsorts_by(|s| s.value_type() == Some(std::any::TypeId::of::<T>()));
        assert_eq!(
            results.len(),
            1,
            "Expected exactly one sort for type `{}`",
            std::any::type_name::<T>()
        );
        results.into_iter().next().unwrap()
    }

    /// Check if a sort allows union operations.
    /// A sort is unionable if it's an eq_sort and not marked as non-unionable
    /// (e.g., from `(sort Foo :no-union)` or relation desugaring).
    pub fn is_sort_unionable(&self, sort: &ArcSort) -> bool {
        sort.is_eq_sort() && !self.non_unionable_sorts.contains(sort.name())
    }

    fn function_to_functype(&self, func: &FunctionDecl) -> Result<FuncType, TypeError> {
        let resolve = |name: &String| -> Result<ArcSort, TypeError> {
            self.sorts
                .get(name)
                .cloned()
                .ok_or_else(|| TypeError::UndefinedSort(name.clone(), func.span.clone()))
        };
        let input = func
            .schema
            .input
            .iter()
            .map(&resolve)
            .collect::<Result<Vec<_>, _>>()?;
        let outputs = func
            .schema
            .outputs
            .iter()
            .map(&resolve)
            .collect::<Result<Vec<_>, _>>()?;

        Ok(FuncType {
            name: func.name.clone(),
            subtype: func.subtype,
            input,
            outputs,
        })
    }

    /// Validate and register a function signature. Macros may use this on a
    /// cloned environment to infer commands that depend on generated declarations.
    pub fn typecheck_function(
        &mut self,
        symbol_gen: &mut SymbolGen,
        fdecl: &FunctionDecl,
    ) -> Result<ResolvedFunctionDecl, TypeError> {
        if self.sorts.contains_key(&fdecl.name) {
            return Err(TypeError::SortAlreadyBound(
                fdecl.name.clone(),
                fdecl.span.clone(),
            ));
        }
        if self.is_primitive(&fdecl.name) {
            return Err(TypeError::PrimitiveAlreadyBound(
                fdecl.name.clone(),
                fdecl.span.clone(),
            ));
        }
        // View tables must have at least one input (the e-class), except the
        // proof-mode functional-dependency tuple view `(children) -> (eclass, proof)`, which keys on
        // children only (a 0-arg constructor's view then has no inputs).
        if fdecl.internal_view.is_some()
            && fdecl.schema.input.is_empty()
            && !fdecl.schema.is_tuple_output()
        {
            return Err(TypeError::ViewTableNoInputs(
                fdecl.name.clone(),
                fdecl.span.clone(),
            ));
        }
        let ftype = self.function_to_functype(fdecl)?;
        if self
            .func_types
            .insert(fdecl.name.clone(), Arc::new(ftype))
            .is_some()
        {
            return Err(TypeError::FunctionAlreadyBound(
                fdecl.name.clone(),
                fdecl.span.clone(),
            ));
        }
        let outputs: Vec<ArcSort> = fdecl
            .schema
            .outputs
            .iter()
            .map(|name| self.sorts.get(name).unwrap().clone())
            .collect();
        let is_tuple = fdecl.schema.is_tuple_output();

        // Tuple outputs are only meaningful for custom functions (which carry a functional
        // dependency from keys to a tuple of values). Constructors mint a single e-class id, so they
        // may not be tuple-output. The proof encoder declares its internal views as functions with
        // `(children) -> (source output, proof)`, so those views may be tuple-output.
        if is_tuple && fdecl.subtype == FunctionSubtype::Constructor {
            return Err(TypeError::TupleOutputNotAllowed(
                fdecl.name.clone(),
                fdecl.span.clone(),
            ));
        }
        if fdecl.subtype == FunctionSubtype::Constructor && !outputs[0].is_eq_sort() {
            return Err(TypeError::ConstructorOutputNotSort(
                fdecl.name.clone(),
                fdecl.span.clone(),
            ));
        }

        // For single-output functions the merge expression refers to `old`/`new`. For
        // tuple-output functions it refers to `old0`, `new0`, `old1`, `new1`, ... (one pair per
        // output column), and the whole merge is a `(values ...)` form.
        let mut bound_vars = IndexMap::default();
        let tuple_var_names: Vec<(String, String)> = (0..outputs.len())
            .map(|i| (format!("old{i}"), format!("new{i}")))
            .collect();
        if is_tuple {
            for (i, (old_name, new_name)) in tuple_var_names.iter().enumerate() {
                bound_vars.insert(old_name.as_str(), (fdecl.span.clone(), outputs[i].clone()));
                bound_vars.insert(new_name.as_str(), (fdecl.span.clone(), outputs[i].clone()));
            }
        } else {
            bound_vars.insert("old", (fdecl.span.clone(), outputs[0].clone()));
            bound_vars.insert("new", (fdecl.span.clone(), outputs[0].clone()));
        }

        // A `:merge` is a value-producing action block: the `actions` run (writes are allowed, but
        // live DB reads would be untracked by seminaive rule execution), then `result` produces the
        // merged value(s). Both are typechecked with `old`/`new` (`old0`/`new0`/... for tuple)
        // bound; the actions go through the same action typechecker as rule bodies.
        let merge = match &fdecl.merge {
            Some(merge) => {
                let actions = self.typecheck_standalone_actions(
                    symbol_gen,
                    &merge.actions,
                    &bound_vars,
                    Context::Write,
                )?;
                // The result is evaluated after the actions, so any `let`-bound variable is in
                // scope for it. Extend the binding with each `let`'s solved type before checking
                // the result. `let_bindings` owns the names so `result_scope` can borrow them.
                let let_bindings: Vec<(String, Span, ArcSort)> = actions
                    .0
                    .iter()
                    .filter_map(|a| match a {
                        GenericAction::Let(span, var, _) => {
                            Some((var.name.as_str().to_owned(), span.clone(), var.sort.clone()))
                        }
                        _ => None,
                    })
                    .collect();
                let mut result_scope = bound_vars.clone();
                for (name, span, sort) in &let_bindings {
                    result_scope.insert(name.as_str(), (span.clone(), sort.clone()));
                }
                let result = if is_tuple {
                    self.typecheck_tuple_merge(
                        symbol_gen,
                        fdecl,
                        &merge.result,
                        &outputs,
                        &result_scope,
                    )?
                } else {
                    self.typecheck_standalone_expr(
                        symbol_gen,
                        &merge.result,
                        &result_scope,
                        Context::Write,
                    )?
                };
                Some(ResolvedMerge { actions, result })
            }
            None => None,
        };

        Ok(ResolvedFunctionDecl {
            name: fdecl.name.clone(),
            subtype: fdecl.subtype,
            schema: fdecl.schema.clone(),

            merge,
            cost: fdecl.cost,
            unextractable: fdecl.unextractable,
            internal_hidden: fdecl.internal_hidden,
            internal_let: fdecl.internal_let,
            span: fdecl.span.clone(),
            internal_view: fdecl.internal_view,
            identity_vals: fdecl.identity_vals,
            internal_term_node: fdecl.internal_term_node,
        })
    }

    /// Typecheck the `(values e0 e1 ...)` merge of a tuple-output function. Each `ei` is checked
    /// with `old0`/`new0`/... bound to the corresponding output columns, and must have the type of
    /// output column `i`. The result is a resolved `values` call carrying the output sorts.
    fn typecheck_tuple_merge(
        &self,
        symbol_gen: &mut SymbolGen,
        fdecl: &FunctionDecl,
        merge: &Expr,
        outputs: &[ArcSort],
        bound_vars: &IndexMap<&str, (Span, ArcSort)>,
    ) -> Result<ResolvedExpr, TypeError> {
        let args = match merge {
            GenericExpr::Call(_, head, args) if head.as_str() == "values" => args,
            _ => {
                return Err(TypeError::TupleMergeNotValues(
                    fdecl.name.clone(),
                    fdecl.span.clone(),
                ));
            }
        };
        if args.len() != outputs.len() {
            return Err(TypeError::TupleMergeArity {
                name: fdecl.name.clone(),
                expected: outputs.len(),
                actual: args.len(),
                span: fdecl.span.clone(),
            });
        }
        let mut resolved_args = Vec::with_capacity(args.len());
        for (arg, expected) in args.iter().zip(outputs) {
            let resolved =
                self.typecheck_standalone_expr(symbol_gen, arg, bound_vars, Context::Write)?;
            let actual = resolved.output_type();
            if actual.name() != expected.name() {
                return Err(TypeError::Mismatch {
                    expr: arg.clone(),
                    expected: expected.clone(),
                    actual,
                });
            }
            resolved_args.push(resolved);
        }
        Ok(GenericExpr::Call(
            merge.span(),
            ResolvedCall::Values(outputs.to_vec()),
            resolved_args,
        ))
    }

    fn typecheck_schedule(
        &self,
        symbol_gen: &mut SymbolGen,
        schedule: &Schedule,
    ) -> Result<ResolvedSchedule, TypeError> {
        let schedule = match schedule {
            Schedule::Repeat(span, times, schedule) => ResolvedSchedule::Repeat(
                span.clone(),
                *times,
                Box::new(self.typecheck_schedule(symbol_gen, schedule)?),
            ),
            Schedule::Sequence(span, schedules) => {
                let schedules = schedules
                    .iter()
                    .map(|schedule| self.typecheck_schedule(symbol_gen, schedule))
                    .collect::<Result<Vec<_>, _>>()?;
                ResolvedSchedule::Sequence(span.clone(), schedules)
            }
            Schedule::Saturate(span, schedule) => ResolvedSchedule::Saturate(
                span.clone(),
                Box::new(self.typecheck_schedule(symbol_gen, schedule)?),
            ),
            Schedule::Run(span, RunConfig { ruleset, until }) => {
                let until = until
                    .as_ref()
                    .map(|facts| self.typecheck_facts(symbol_gen, facts))
                    .transpose()?;
                ResolvedSchedule::Run(
                    span.clone(),
                    ResolvedRunConfig {
                        ruleset: ruleset.clone(),
                        until,
                    },
                )
            }
        };

        Result::Ok(schedule)
    }

    /// Infer a rule's body and head together. Command macros can use the resolved
    /// expressions before emitting actions, which are typechecked again normally.
    pub fn typecheck_rule(
        &self,
        symbol_gen: &mut SymbolGen,
        rule: &Rule,
        global_seminaive: bool,
    ) -> Result<ResolvedRule, TypeError> {
        let Rule {
            span,
            head,
            body,
            name,
            ruleset,
            eval_mode,
            no_decomp,
            include_subsumed,
        } = rule;
        // Compile with the permissive Read/Full primitive contexts (so the RHS
        // can read the database) when the whole EGraph is non-seminaive, or the
        // rule's own mode requires it (`:naive` / `:unsafe-seminaive`).
        let read_contexts = !global_seminaive
            || matches!(
                eval_mode,
                RuleEvalMode::Naive | RuleEvalMode::UnsafeSeminaive
            );
        let (query_ctx, action_ctx) = if read_contexts {
            (Context::Read, Context::Full)
        } else {
            (Context::Pure, Context::Write)
        };

        let (query, mapped_query) = Facts(body.clone()).to_query(self, symbol_gen);
        let mut problem = Problem::default();
        problem.add_query(&query, self, query_ctx)?;

        let mut binding = query.vars().collect::<IndexSet<_>>();
        // We lower to core actions with `union_to_set_optimization`
        // later in the pipeline. For typechecking we do not need it.
        let mut ctx = CoreActionContext::new(self, &mut binding, symbol_gen, false);
        let (actions, mapped_action) = head.to_core_actions(&mut ctx)?;
        problem.add_actions(&actions, self, symbol_gen, action_ctx)?;

        let assignment = problem
            .solve(|sort: &ArcSort| sort.name())
            .map_err(|e| e.to_type_error())?;

        let body: Vec<ResolvedFact> = assignment.annotate_facts(&mapped_query, self, query_ctx)?;
        let actions: ResolvedActions =
            assignment.annotate_actions(&mapped_action, self, action_ctx)?;

        // Function lookups in actions need the `Full` action context; the
        // `Write` context (`!read_contexts`) can't express them.
        if !read_contexts {
            self.check_no_function_lookups_in_actions(&actions)?;
        }

        Ok(ResolvedRule {
            span: span.clone(),
            body,
            head: actions,
            name: name.clone(),
            ruleset: ruleset.clone(),
            eval_mode: *eval_mode,
            no_decomp: *no_decomp,
            include_subsumed: *include_subsumed,
        })
    }

    fn check_lookup_expr(&self, expr: &ResolvedExpr) -> Result<(), TypeError> {
        if let Some(span) = self.expr_has_function_lookup(expr) {
            return Err(TypeError::LookupInRuleDisallowed(
                "function".to_string(),
                span,
            ));
        }
        Ok(())
    }

    fn check_no_function_lookups_in_actions(
        &self,
        actions: &ResolvedActions,
    ) -> Result<(), TypeError> {
        for action in actions.iter() {
            match action {
                GenericAction::Let(_, _, rhs) => self.check_lookup_expr(rhs)?,
                GenericAction::Set(_, _, args, rhs) => {
                    for arg in args.iter() {
                        self.check_lookup_expr(arg)?;
                    }
                    self.check_lookup_expr(rhs)?;
                }
                GenericAction::Union(_, lhs, rhs) => {
                    self.check_lookup_expr(lhs)?;
                    self.check_lookup_expr(rhs)?;
                }
                GenericAction::Change(_, _, _, args) => {
                    for arg in args.iter() {
                        self.check_lookup_expr(arg)?;
                    }
                }
                GenericAction::Panic(..) => {}
                GenericAction::Expr(_, expr) => self.check_lookup_expr(expr)?,
            }
        }
        Ok(())
    }

    pub fn typecheck_facts(
        &self,
        symbol_gen: &mut SymbolGen,
        facts: &[Fact],
    ) -> Result<Vec<ResolvedFact>, TypeError> {
        let (query, mapped_facts) = Facts(facts.to_vec()).to_query(self, symbol_gen);
        let mut problem = Problem::default();
        // Top-level query-shaped commands (e.g. `check`) are read-only:
        // primitives may inspect the database but not write to it.
        problem.add_query(&query, self, Context::Read)?;
        let assignment = problem
            .solve(|sort: &ArcSort| sort.name())
            .map_err(|e| e.to_type_error())?;
        let annotated_facts = assignment.annotate_facts(&mapped_facts, self, Context::Read)?;
        Ok(annotated_facts)
    }

    /// Infer an expression's sort for a command macro, including rule-local bindings.
    /// Generated actions still pass through ordinary typechecking afterwards.
    pub fn infer_expr_sort(
        &self,
        symbol_gen: &mut SymbolGen,
        expr: &Expr,
        bindings: &[(String, Span, ArcSort)],
        context: Context,
    ) -> Result<ArcSort, TypeError> {
        let mut binding_map = IndexMap::default();
        for (name, span, sort) in bindings {
            if binding_map
                .insert(name.as_str(), (span.clone(), sort.clone()))
                .is_some()
            {
                return Err(TypeError::AlreadyDefined(name.clone(), span.clone()));
            }
        }
        Ok(self
            .typecheck_standalone_expr(symbol_gen, expr, &binding_map, context)?
            .output_type())
    }

    /// Infer a whole action block, including constraints on local bindings.
    /// Top-level commands pass `Full`; function `:merge` uses `Write` because
    /// merge expressions run during table updates.
    pub fn typecheck_standalone_actions(
        &self,
        symbol_gen: &mut SymbolGen,
        actions: &Actions,
        binding: &IndexMap<&str, (Span, ArcSort)>,
        context: Context,
    ) -> Result<ResolvedActions, TypeError> {
        let mut binding_set: IndexSet<String> =
            binding.keys().copied().map(str::to_string).collect();
        // We lower to core actions with `union_to_set_optimization`
        // later in the pipeline. For typechecking we do not need it.
        let mut ctx = CoreActionContext::new(self, &mut binding_set, symbol_gen, false);
        let (actions, mapped_action) = actions.to_core_actions(&mut ctx)?;
        let mut problem = Problem::default();

        problem.add_actions(&actions, self, symbol_gen, context)?;

        // add bindings from the context
        for (var, (span, sort)) in binding {
            problem.assign_local_var_type(var, span.clone(), sort.clone())?;
        }

        let assignment = problem
            .solve(|sort: &ArcSort| sort.name())
            .map_err(|e| e.to_type_error())?;

        let annotated_actions = assignment.annotate_actions(&mapped_action, self, context)?;
        Ok(annotated_actions)
    }

    fn typecheck_standalone_expr(
        &self,
        symbol_gen: &mut SymbolGen,
        expr: &Expr,
        binding: &IndexMap<&str, (Span, ArcSort)>,
        context: Context,
    ) -> Result<ResolvedExpr, TypeError> {
        let action = Action::Expr(expr.span(), expr.clone());
        let typechecked_action =
            self.typecheck_standalone_action(symbol_gen, &action, binding, context)?;
        match typechecked_action {
            ResolvedAction::Expr(_, expr) => Ok(expr),
            _ => unreachable!(),
        }
    }

    pub(crate) fn typecheck_expr_with_output(
        &self,
        symbol_gen: &mut SymbolGen,
        expr: &Expr,
        binding: &IndexMap<&str, (Span, ArcSort)>,
        output_sort: ArcSort,
        context: Context,
    ) -> Result<ResolvedExpr, TypeError> {
        let action = Action::Expr(expr.span(), expr.clone());
        let mut binding_set: IndexSet<String> =
            binding.keys().copied().map(str::to_string).collect();
        let mut ctx = CoreActionContext::new(self, &mut binding_set, symbol_gen, false);
        let (actions, mapped_action) = Actions::singleton(action).to_core_actions(&mut ctx)?;
        let mut problem = Problem::default();

        problem.add_actions(&actions, self, symbol_gen, context)?;

        for (var, (span, sort)) in binding {
            problem.assign_local_var_type(var, span.clone(), sort.clone())?;
        }

        let [GenericAction::Expr(_, mapped_expr)] = mapped_action.0.as_slice() else {
            unreachable!("typechecking an expression should produce one expression action")
        };
        let output_atom = mapped_expr.get_corresponding_var_or_lit(self);
        problem.add_binding(output_atom, output_sort.clone());

        let assignment = problem
            .solve(|sort: &ArcSort| sort.name())
            .map_err(|e| e.to_type_error())?;

        let annotated_actions = assignment.annotate_actions(&mapped_action, self, context)?;
        match annotated_actions.0.into_iter().next().unwrap() {
            ResolvedAction::Expr(_, resolved_expr) => {
                let actual = resolved_expr.output_type();
                if actual.name() != output_sort.name() {
                    return Err(TypeError::Mismatch {
                        expr: expr.clone(),
                        expected: output_sort,
                        actual,
                    });
                }
                Ok(resolved_expr)
            }
            _ => unreachable!(),
        }
    }

    fn typecheck_standalone_action(
        &self,
        symbol_gen: &mut SymbolGen,
        action: &Action,
        binding: &IndexMap<&str, (Span, ArcSort)>,
        context: Context,
    ) -> Result<ResolvedAction, TypeError> {
        self.typecheck_standalone_actions(
            symbol_gen,
            &Actions::singleton(action.clone()),
            binding,
            context,
        )
        .map(|v| {
            assert_eq!(v.len(), 1);
            v.0.into_iter().next().unwrap()
        })
    }

    pub fn get_sort_by_name(&self, sym: &str) -> Option<&ArcSort> {
        self.sorts.get(sym)
    }

    pub fn get_prims(&self, sym: &str) -> Option<&[PrimitiveWithId]> {
        self.primitives.get(sym).map(Vec::as_slice)
    }

    pub fn is_primitive(&self, sym: &str) -> bool {
        self.primitives.contains_key(sym) || self.reserved_primitives.contains(sym)
    }

    pub fn primitive_has_validator(&self, id: ExternalFunctionId) -> bool {
        self.primitives
            .values()
            .flat_map(|v| v.iter())
            .any(|p| p.context_ids.iter().any(|(_, pid)| *pid == Some(id)) && p.validator.is_some())
    }

    /// The shared signature declared for `sym`, or `None` if no function with
    /// that name is declared. Clone it to keep it past the borrow.
    pub fn get_func_type(&self, sym: &str) -> Option<&Arc<FuncType>> {
        self.func_types.get(sym)
    }

    /// Record a signature for a function that did not come through
    /// typechecking — desugaring generates some (global bindings, proof
    /// tables) directly.
    pub(crate) fn declare_func_type(&mut self, func_type: Arc<FuncType>) {
        self.func_types.insert(func_type.name.clone(), func_type);
    }

    pub fn is_constructor(&self, sym: &str) -> bool {
        self.get_func_type(sym)
            .is_some_and(|f| f.subtype == FunctionSubtype::Constructor)
    }

    pub fn get_global_sort(&self, sym: &str) -> Option<&ArcSort> {
        self.global_sorts.get(sym)
    }

    pub fn is_global(&self, sym: &str) -> bool {
        self.global_sorts.contains_key(sym)
    }

    /// Check if an expression contains non-global function lookups (FunctionSubtype::Custom calls).
    /// Global function calls are allowed since they get desugared to constructors.
    /// Returns Some(span) if a lookup is found, None otherwise.
    pub fn expr_has_function_lookup(&self, expr: &ResolvedExpr) -> Option<Span> {
        use ast::GenericExpr;

        expr.find(&mut |e| {
            if let GenericExpr::Call(span, ResolvedCall::Func(func_type), _) = e
                && func_type.subtype == FunctionSubtype::Custom
                && !self.is_global(&func_type.name)
            {
                return Some(span.clone());
            }
            None
        })
    }
}

#[derive(Debug, Clone, Error)]
pub enum TypeError {
    #[error("{}\nArity mismatch, expected {expected} args: {expr}", .expr.span())]
    Arity { expr: Expr, expected: usize },
    #[error(
        "{}\n Expect expression {expr} to have type {}, but get type {}",
        .expr.span(), .expected.name(), .actual.name(),
    )]
    Mismatch {
        expr: Expr,
        expected: ArcSort,
        actual: ArcSort,
    },
    #[error("{1}\nIndex {0} lists no columns to index")]
    EmptyIndex(String, Span),
    #[error("{3}\nIndex {0} refers to column {1}, but the indexed row has {2} columns")]
    IndexColumnOutOfRange(String, usize, usize, Span),
    #[error("{3}\nIndex {0} mixes columns of sort {1} and {2}; an index reads one sort")]
    IndexColumnSortMismatch(String, String, String, Span),
    #[error(
        "{2}\nIndex {0} is looked up by {1}, which no other function atom binds. An index atom is probed, so its value must be bound elsewhere in the query by a function's rows; a body primitive runs after the join, so it cannot bind it."
    )]
    IndexValueUnbound(String, String, Span),
    #[error("{1}\nIndex {0} is maintained by the database and cannot be written to")]
    IndexIsReadOnly(String, Span),
    #[error(
        "{2}\nIndex {0} indexes {1}, which is itself an index; an index has no rows of its own"
    )]
    IndexOfIndex(String, String, Span),
    #[error("{1}\nUnbound symbol {0}")]
    Unbound(String, Span),
    #[error(
        "{1}\nVariable {0} is ungrounded. A variable is grounded when it appears as an argument to a constructor or function in the query, not just under primitives or equalities."
    )]
    Ungrounded(String, Span),
    #[error("{1}\nUndefined sort {0}")]
    UndefinedSort(String, Span),
    #[error("{1}\nUnbound function {0}")]
    UnboundFunction(String, Span),
    #[error("{1}\nFunction already bound {0}")]
    FunctionAlreadyBound(String, Span),
    #[error("{1}\nSort {0} already declared.")]
    SortAlreadyBound(String, Span),
    #[error("{1}\nPrimitive {0} already declared.")]
    PrimitiveAlreadyBound(String, Span),
    #[error("Function type mismatch: expected {} => {}, actual {} => {}", .1.iter().map(|s| s.name().to_string()).collect::<Vec<_>>().join(", "), .0.name(), .3.iter().map(|s| s.name().to_string()).collect::<Vec<_>>().join(", "), .2.name())]
    FunctionTypeMismatch(ArcSort, Vec<ArcSort>, ArcSort, Vec<ArcSort>),
    #[error("{1}\nPresort {0} not found.")]
    PresortNotFound(String, Span),
    #[error("{1}\nInvalid arguments to sort constructor `{0}`")]
    BadPresortArguments(String, Span),
    #[error("{}\nFailed to infer a type for: {}", .0.span(), .0)]
    InferenceFailure(Expr),
    #[error("{1}\nVariable {0} was already defined")]
    AlreadyDefined(String, Span),
    #[error("{1}\nThe output type of constructor function {0} must be sort")]
    ConstructorOutputNotSort(String, Span),
    #[error("{1}\nValue lookup of non-constructor function {0} in rule is disallowed.")]
    LookupInRuleDisallowed(String, Span),
    #[error("{1}\nCannot set constructor {0}. Use `union` instead or declare {0} as a function.")]
    SetConstructorDisallowed(String, Span),
    #[error("All alternative definitions considered failed\n{}", .0.iter().map(|e| format!("  {e}\n")).collect::<Vec<_>>().join(""))]
    AllAlternativeFailed(Vec<TypeError>),
    #[error("{}\nCannot union values of sort {}", .1, .0.name())]
    NonEqsortUnion(ArcSort, Span),
    #[error("{}\nCannot union values of sort {} because it is marked as non-unionable (e.g. from a relation)", .1, .0.name())]
    NonUnionableSort(ArcSort, Span),
    #[error("{1}\nView table {0} with :internal-view must have at least one input (the e-class).")]
    ViewTableNoInputs(String, Span),
    #[error(
        "{span}\nNon-global variable `{name}` must not start with `{}`.",
        crate::GLOBAL_NAME_PREFIX
    )]
    NonGlobalPrefixed { name: String, span: Span },
    #[error(
        "{span}\nGlobal `{name}` must start with `{}`.",
        crate::GLOBAL_NAME_PREFIX
    )]
    GlobalMissingPrefix { name: String, span: Span },
    #[error(
        "{1}\nFunction {0} has a tuple output, which is only allowed for plain functions (not constructors, relations, or view tables)."
    )]
    TupleOutputNotAllowed(String, Span),
    #[error(
        "{1}\nThe :merge of tuple-output function {0} must be a `(values ...)` form with one expression per output column."
    )]
    TupleMergeNotValues(String, Span),
    #[error(
        "{span}\nThe :merge of tuple-output function {name} has {actual} columns but the function has {expected} output columns."
    )]
    TupleMergeArity {
        name: String,
        expected: usize,
        actual: usize,
        span: Span,
    },
    #[error(
        "{1}\nCannot extract tuple-output function {0}: extraction yields a single term, but a tuple-output function has more than one output column. Read its columns in a rule with `(= (values ...) ({0} ...))` instead."
    )]
    CannotExtractTupleOutput(String, Span),
    #[error(
        "{span}\nAmbiguous primitive resolution for `{name}` in {ctx:?} context: multiple registered primitives match the same signature."
    )]
    AmbiguousPrimitive {
        name: String,
        ctx: crate::Context,
        span: Span,
    },
    #[error("{span}\nNo resolution for `{name}` in {ctx:?} context.")]
    UnresolvedPrimitive {
        name: String,
        ctx: crate::Context,
        span: Span,
    },
}

#[cfg(test)]
mod test {
    use crate::{EGraph, Error, typechecking::TypeError};

    #[test]
    fn test_arity_mismatch() {
        let mut egraph = EGraph::default();

        let prog = "
            (relation f (i64 i64))
            (rule ((f a b c)) ())
       ";
        let res = egraph.parse_and_run_program(None, prog);
        match res {
            Err(Error::TypeError(TypeError::Arity {
                expected: 2,
                expr: e,
            })) => {
                assert_eq!(e.span().string(), "(f a b c)");
            }
            _ => panic!("Expected arity mismatch, got: {res:?}"),
        }
    }
}
