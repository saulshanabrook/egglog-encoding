//! Implementation of the `keep-best` command.
//!
//! `(keep-best "table1" "table2" ... [:extractor greedy-dag])` extracts the
//! best representative found by the selected extractor for every entry in each
//! named table and then clears the existing term and fact rows. It rebuilds the
//! selected tuples along with any constructor rows needed by their extracted values.
//! This "compacts" the e-graph to the best solutions found so far.
//!
//! Each argument must evaluate to a `String` that names an existing function.

use crate::DynamicCostModel;
use crate::greedy_dag_extract::{extract_best_greedy_dag, split_trailing_extractor};
use egglog::{
    CommandOutput, EGraph, Error, RawValues, TermDag, TermId, UserDefinedCommand, Value, Write,
    ast::{Expr, FunctionSubtype, ParseError},
    extract::TreeCostModelFromDag,
    sort::S,
    span,
};

use crate::table_rows::{for_each_table_row, table_layout};

/// User-defined command implementing `(keep-best "table"...)`.
///
/// For every row in the named tables, the command extracts the best term for
/// each value. It then clears the term and fact tables and rebuilds
/// the extracted rows from the named tables, including any constructor rows
/// needed to represent their values.
pub struct KeepBestCommand;

impl UserDefinedCommand for KeepBestCommand {
    fn update(&self, egraph: &mut EGraph, args: &[Expr]) -> Result<Vec<CommandOutput>, Error> {
        let (args, use_greedy_dag) = split_trailing_extractor(args)?;

        if args.is_empty() {
            return Err(Error::ParseError(ParseError(
                span!(),
                "keep-best expects at least one table name".into(),
            )));
        }

        // Step 1: evaluate each argument to a table name string.
        let table_names: Vec<String> = args
            .iter()
            .map(|arg| {
                let (_, val) = egraph.eval_expr(arg)?;
                Ok(egraph.value_to_base::<S>(val).0)
            })
            .collect::<Result<_, Error>>()?;

        // Step 2: for each table, collect all rows and extract the best
        // term for every column value.
        let extracted = collect_and_extract(egraph, &table_names, use_greedy_dag)?;

        // Step 3: clear the term and fact tables in bulk.
        //
        // `clear_function` drops the entire row buffer for a table in
        // O(1)-in-row-count time and bumps the table's generation so cached
        // indexes/subsets are lazily rebuilt. That's strictly faster than
        // staging a `remove` per row, which is what we used to do here.
        let all_funcs: Vec<String> = egraph.get_function_names();
        for name in &all_funcs {
            // Injectivity markers describe declarations, not collected data.
            if name != crate::injectivity::MARKED_CONSTRUCTORS {
                egraph.clear_function(name)?;
            }
        }

        // Step 4: re-insert the selected tuples. Evaluate each extracted term
        // via eval_expr so that constructor sub-terms are re-created bottom-up,
        // then stage all target-table inserts in one update call.
        let mut rows_to_insert: Vec<(String, FunctionSubtype, Vec<Value>)> = Vec::new();
        for (table_name, subtype, extracted_rows, termdag) in &extracted {
            for term_ids in extracted_rows {
                let values = eval_terms(egraph, termdag, term_ids)?;
                rows_to_insert.push((table_name.clone(), *subtype, values));
            }
        }

        egraph.update(|mut state| {
            for (table_name, subtype, values) in &rows_to_insert {
                match subtype {
                    FunctionSubtype::Custom => {
                        let (output, inputs) = values
                            .split_last()
                            .expect("keep-best function rows have at least one output value");
                        state.set(table_name, RawValues(inputs.to_vec()), *output)?;
                    }
                    FunctionSubtype::Constructor => {
                        state.add(table_name, RawValues(values.clone()))?;
                    }
                }
            }
            Ok(())
        })?;

        Ok(vec![])
    }
}

type ExtractedTable = (String, FunctionSubtype, Vec<Vec<TermId>>, TermDag);

/// For each table, collect all rows and extract the best term for each value.
/// Returns `(table_name, rows, termdag)` triples where each row is a list of
/// `TermId`s (inputs followed by output) into the shared `termdag`.
fn collect_and_extract(
    egraph: &EGraph,
    table_names: &[String],
    use_greedy_dag: bool,
) -> Result<Vec<ExtractedTable>, Error> {
    let mut result = Vec::new();

    for table_name in table_names {
        let layout = table_layout(egraph, table_name, span!())?;
        let subtype = layout.subtype;
        let all_sorts = layout.extraction_sorts();

        let mut raw_rows: Vec<Vec<Value>> = Vec::new();
        for_each_table_row(egraph, table_name, &layout, false, |row| raw_rows.push(row))?;

        let roots = raw_rows
            .iter()
            .flat_map(|row_vals| {
                row_vals
                    .iter()
                    .zip(all_sorts.iter())
                    .map(|(val, sort)| (sort.clone(), *val))
            })
            .collect();
        let extracted = if use_greedy_dag {
            extract_best_greedy_dag(egraph, roots, DynamicCostModel)
        } else {
            egraph.extract_best_with_cost_model(roots, TreeCostModelFromDag(DynamicCostModel))
        }
        .map_err(|err| {
            Error::ExtractError(format!(
                "keep-best: could not extract value in table {table_name}: {err}"
            ))
        })?;
        let termdag = extracted.termdag;
        let extract_error = format!("keep-best: could not extract value in table {table_name}");
        let mut terms = extracted.terms.into_iter().map(move |root| {
            root.ok_or_else(|| Error::ExtractError(extract_error.clone()))
                .map(|root| root.term)
        });
        let mut extracted_rows: Vec<Vec<TermId>> = Vec::new();

        for row_vals in &raw_rows {
            let mut term_ids = Vec::new();
            for _ in row_vals {
                term_ids.push(terms.next().expect("one term per extracted table cell")?);
            }
            extracted_rows.push(term_ids);
        }

        result.push((table_name.clone(), subtype, extracted_rows, termdag));
    }

    Ok(result)
}

/// Evaluate a list of `TermId`s from `termdag` using `eval_expr`, returning
/// the resulting `Value`s in the same order.
fn eval_terms(
    egraph: &mut EGraph,
    termdag: &TermDag,
    term_ids: &[TermId],
) -> Result<Vec<Value>, Error> {
    term_ids
        .iter()
        .map(|tid| {
            let expr = termdag.term_to_expr(
                tid,
                egglog::prelude::Span::Rust(std::sync::Arc::new(egglog::prelude::RustSpan {
                    file: file!(),
                    line: line!(),
                    column: column!(),
                })),
            );
            let (_, val) = egraph.eval_expr(&expr)?;
            Ok(val)
        })
        .collect()
}
