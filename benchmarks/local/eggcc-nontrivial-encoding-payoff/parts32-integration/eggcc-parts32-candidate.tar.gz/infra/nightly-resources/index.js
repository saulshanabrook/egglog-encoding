// copied from profile.py
const GLOBAL_DATA = {
  checkedModes: new Set(),
  checkedSuites: new Set(),
  checkedBenchmarks: new Set(),
  warnings: new Set(),
  currentRun: [],
  baselineRun: [],
  chart: {
    chart: undefined,
    mode: "normalized",
    sortBy: undefined,
  },
};

function treatments() {
  let treatments = dedup(GLOBAL_DATA.currentRun.map((x) => x.runMethod));
  // exclude ILP treatment
  treatments = treatments.filter(
    (treatment) => treatment !== "eggcc-ILP-O0-O0",
  );
  return treatments;
}

// filter to all the benchmark names that are enabled
// using checkedSuites and checkedBenchmarks
function enabledBenchmarks() {
  return Array.from(GLOBAL_DATA.checkedBenchmarks).filter((benchmark) =>
    GLOBAL_DATA.checkedSuites.has(getRow(benchmark, BASELINE_MODE).suite),
  );
}

// filter current run for enabled benchmarks
// and by checked run modes
function enabledSubsetOfCurrentRun() {
  const benchmarks = enabledBenchmarks();
  return GLOBAL_DATA.currentRun.filter(
    (entry) =>
      GLOBAL_DATA.checkedModes.has(entry.runMethod) &&
      benchmarks.includes(entry),
  );
}

function addWarning(warning) {
  GLOBAL_DATA.warnings.add(warning);
}

function clearWarnings() {
  GLOBAL_DATA.warnings.clear();
}

function addTableTo(element, data, title) {
  // add a h2 element with the title
  const h2 = document.createElement("h2");
  h2.innerText = title;
  element.appendChild(h2);

  // add a button that copies latex for table
  const copyButton = document.createElement("button");
  copyButton.innerText = "Copy Latex";
  copyButton.onclick = () => {
    const table = jsonToLatexTable(data);
    navigator.clipboard.writeText(table);
  };

  element.appendChild(copyButton);

  // add a new div for the table
  const tableDiv = document.createElement("div");
  tableDiv.innerHTML = ConvertJsonToTable(data);
  element.appendChild(tableDiv);
}

function benchmarksInSuite(suite) {
  return enabledBenchmarks().filter(
    (benchmark) => getRow(benchmark, BASELINE_MODE).suite === suite,
  );
}

function tableForSuite(suite) {
  const byBench = {};
  benchmarksInSuite(suite).forEach((benchmark) => {
    byBench[benchmark] = getDataForBenchmark(benchmark);
  });
  const tableData = Object.keys(byBench).map((bench) => ({
    name: `<a target="_blank" rel="noopener noreferrer" href="https://github.com/egraphs-good/eggcc/tree/main/${getBrilPathForBenchmark(
      bench,
    )}">${bench}</a>`,
    executions: { data: byBench[bench] },
  }));
  tableData.sort((l, r) => l.name - r.name);
  return tableData;
}

function dedup(arr) {
  return Array.from(new Set(arr));
}

function getSuites() {
  return dedup(GLOBAL_DATA.currentRun.map((benchmark) => benchmark.suite));
}

function refreshView() {
  if (!GLOBAL_DATA.baselineRun) {
    addWarning("no baseline to compare to");
  }

  // clear the tables element
  while (document.getElementById("tables").firstChild) {
    document
      .getElementById("tables")
      .removeChild(document.getElementById("tables").firstChild);
  }

  // fill in the overall stats table
  const overallStats = getOverallStatistics(undefined);
  addTableTo(document.getElementById("tables"), overallStats, "Overall Stats");

  var latexMacros = "";
  latexMacros =
    latexMacros + jsonToLatexMacros(overallStats, "Treatment", "overall");

  for (const suite of getSuites()) {
    const tableData = getOverallStatistics(suite);
    addTableTo(
      document.getElementById("tables"),
      tableData,
      suite + " Overall Stats",
    );
    latexMacros =
      latexMacros +
      jsonToLatexMacros(tableData, "Treatment", suite + "Overall");
  }

  for (const suite of getSuites()) {
    const tableData = tableForSuite(suite);
    addTableTo(document.getElementById("tables"), tableData, suite + " Stats");
    latexMacros =
      latexMacros +
      nestedJsonToLatexMacros(tableData, "name", "executions", "runMethod");
  }

  renderWarnings();
  refreshChart();
  refreshLatexMacros(latexMacros);
}

function renderWarnings() {
  const toggle = document.getElementById("warnings-toggle");
  toggle.innerText = `\u25B6 Show ${GLOBAL_DATA.warnings.size} Warnings`;

  const warningContainer = document.getElementById("warnings");
  warningContainer.innerHTML = "";
  GLOBAL_DATA.warnings.forEach((warning) => {
    const warningElement = document.createElement("p");
    warningElement.innerText = warning;
    warningContainer.appendChild(warningElement);
  });
}

/// Manipulating UI elements:

function makeCheckbox(parent, mode) {
  // make a check box for enabling this mode
  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.id = mode;
  checkbox.checked = true;
  parent.appendChild(checkbox);
  // make a label for the checkbox
  const label = document.createElement("label");
  label.htmlFor = mode;
  label.innerText = mode;
  parent.appendChild(label);
  // make a line break
  parent.appendChild(document.createElement("br"));
  return checkbox;
}

function makeSelectors() {
  treatments().forEach((mode) => {
    const checkbox = makeCheckbox(
      document.getElementById("modeCheckboxes"),
      mode,
    );
    checkbox.onchange = () => toggleCheckbox(mode, GLOBAL_DATA.checkedModes);
  });

  const suites = getSuites();
  suites.forEach((suite) => {
    const checkbox = makeCheckbox(
      document.getElementById("suiteCheckboxes"),
      suite,
    );
    checkbox.onchange = () => toggleCheckbox(suite, GLOBAL_DATA.checkedSuites);
  });

  const benchmarks = Array.from(
    new Set(GLOBAL_DATA.currentRun.map((o) => o.benchmark)),
  ).sort();
  benchmarks.forEach((benchmark) => {
    const checkbox = makeCheckbox(
      document.getElementById("benchmarkCheckboxes"),
      benchmark,
    );
    checkbox.onchange = () =>
      toggleCheckbox(benchmark, GLOBAL_DATA.checkedBenchmarks);
  });
}

async function buildNightlyDropdown(element, previousRuns, initialIdx) {
  const select = document.getElementById(element);

  const formatRun = (run) =>
    `${run.branch} - ${run.commit} - ${new Date(
      run.date * 1000,
    ).toDateString()}`;

  previousRuns.forEach((nightly) => {
    const option = document.createElement("option");
    option.innerText = formatRun(nightly);
    select.appendChild(option);
  });

  select.onchange = () => loadBaseline(previousRuns[select.selectedIndex].url);

  select.selectedIndex = initialIdx;
  select.value = formatRun(previousRuns[initialIdx]);
}

async function refreshLatexMacros(tableMacros) {
  const latexMacrosTextArea = document.getElementById("latex-macros-text");
  let latexMacros = "";

  // Check if file exists first using HEAD request to avoid 404 error in console
  try {
    const headResponse = await fetch("paper/nightlymacros.tex", {
      method: "HEAD",
    });
    if (!headResponse.ok) {
      console.info(
        "nightlymacros.tex not found. This is expected if running without Gurobi (--use-gurobi) or with UNSAFE_TREATMENTS.",
      );
    } else {
      try {
        const response = await fetch("paper/nightlymacros.tex");
        latexMacros = await response.text();
      } catch (error) {
        console.error("Could not load nightlymacros.tex:", error);
      }
    }
  } catch (error) {
    console.info("Could not check nightlymacros.tex:", error);
  }
  latexMacrosTextArea.value = tableMacros + latexMacros;
}

function addGraphs() {
  const container = document.getElementById("plots");
  if (!container) {
    console.error("Missing #plots element to attach graphs list");
    return;
  }

  container.innerHTML = "";

  // Check if file exists first using HEAD request to avoid 404 error in console
  fetch("graphs.json", { method: "HEAD" })
    .then((headResponse) => {
      if (!headResponse.ok) {
        console.info(
          "graphs.json not found. This is expected if running without Gurobi (--use-gurobi) or with UNSAFE_TREATMENTS.",
        );
        return null;
      }
      return fetch("graphs.json");
    })
    .then((response) => {
      if (!response) return null;
      return response.json();
    })
    .then((data) => {
      if (!data) return;

      const sortedPlots = data.slice().sort((a, b) => a.localeCompare(b));

      const list = document.createElement("ul");
      list.classList.add("graph-links");
      list.style.listStyle = "none";
      list.style.margin = "0";
      list.style.paddingLeft = "0";

      sortedPlots.forEach((plot) => {
        const item = document.createElement("li");
        item.classList.add("graph-link-item");
        item.style.marginBottom = "0.5rem";

        const link = document.createElement("a");
        link.href = `paper/${plot}`;
        link.innerText = plot;
        link.target = "_blank";
        link.rel = "noopener noreferrer";

        item.appendChild(link);
        list.appendChild(item);
      });

      container.appendChild(list);
    })
    .catch((error) => {
      console.info("Could not load graphs.json:", error);
    });
}

// on page load, add graphs
window.addEventListener("load", addGraphs);
