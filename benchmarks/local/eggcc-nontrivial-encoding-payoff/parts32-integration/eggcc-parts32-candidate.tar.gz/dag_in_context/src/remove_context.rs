#[derive(Clone, Debug, PartialEq, Eq)]
enum SExpr {
    Atom(String),
    List(Vec<SExpr>),
}

fn tokenize(input: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut i = 0;
    let bytes = input.as_bytes();
    while i < bytes.len() {
        let c = bytes[i] as char;
        // Skip whitespace
        if c.is_whitespace() {
            i += 1;
            continue;
        }
        // Skip line comments starting with ';'
        if c == ';' {
            while i < bytes.len() && (bytes[i] as char) != '\n' {
                i += 1;
            }
            continue;
        }
        if c == '(' || c == ')' {
            tokens.push(c.to_string());
            i += 1;
            continue;
        }
        if c == '"' {
            // string literal, keep quotes
            let start = i;
            i += 1;
            while i < bytes.len() {
                let ch = bytes[i] as char;
                if ch == '\\' {
                    // skip escaped next char if present
                    i += 2;
                    continue;
                }
                if ch == '"' {
                    i += 1; // include closing quote
                    break;
                }
                i += 1;
            }
            tokens.push(input[start..i].to_string());
            continue;
        }
        // symbol/number token
        let start = i;
        while i < bytes.len() {
            let ch = bytes[i] as char;
            if ch.is_whitespace() || ch == '(' || ch == ')' || ch == ';' {
                break;
            }
            i += 1;
        }
        tokens.push(input[start..i].to_string());
    }
    tokens
}

fn parse(tokens: &[String]) -> Vec<SExpr> {
    let mut stack: Vec<Vec<SExpr>> = vec![Vec::new()];
    let mut i = 0;
    while i < tokens.len() {
        match tokens[i].as_str() {
            "(" => stack.push(Vec::new()),
            ")" => {
                let list = stack.pop().expect("Unbalanced parentheses: too many )");
                stack
                    .last_mut()
                    .expect("Unbalanced parentheses: empty stack")
                    .push(SExpr::List(list));
            }
            atom => stack
                .last_mut()
                .expect("Parser stack empty")
                .push(SExpr::Atom(atom.to_string())),
        }
        i += 1;
    }
    if stack.len() != 1 {
        // Unbalanced parentheses; return input as a single atom to avoid crash
        return vec![SExpr::Atom(tokens.join(" "))];
    }
    stack.pop().unwrap()
}

fn sexpr_head(list: &SExpr) -> Option<&str> {
    if let SExpr::List(items) = list {
        if let Some(SExpr::Atom(h)) = items.first() {
            return Some(h.as_str());
        }
    }
    None
}

fn query_uses_context(expr: &SExpr) -> bool {
    match expr {
        SExpr::Atom(_) => false,
        SExpr::List(items) => {
            if let Some(head) = sexpr_head(expr) {
                if matches!(head, "InLoop" | "InSwitch" | "InIf") {
                    return true;
                }
            }
            items.iter().any(query_uses_context)
        }
    }
}

fn replace_context_with_dummy(expr: &SExpr) -> SExpr {
    match expr {
        SExpr::Atom(a) => SExpr::Atom(a.clone()),
        SExpr::List(items) => {
            if let Some(head) = sexpr_head(expr) {
                let is_ctx = matches!(head, "InFunc" | "InLoop" | "InSwitch" | "InIf");
                if is_ctx {
                    return SExpr::Atom("DUMMYCTX".to_string());
                }
            }
            SExpr::List(items.iter().map(replace_context_with_dummy).collect())
        }
    }
}

fn list_is_relies_on_context(list: &[SExpr]) -> bool {
    if list.len() == 1 {
        if let SExpr::Atom(atom) = &list[0] {
            return atom == "RELIESONCONTEXT";
        }
    }
    false
}

fn contains_relies_on_context(expr: &SExpr) -> bool {
    match expr {
        SExpr::Atom(_) => false,
        SExpr::List(items) => {
            if list_is_relies_on_context(items) {
                return true;
            }
            items.iter().any(contains_relies_on_context)
        }
    }
}

fn rule_relies_on_context(items: &[SExpr]) -> bool {
    items.iter().skip(1).any(contains_relies_on_context)
}

fn transform(expr: &SExpr) -> Option<SExpr> {
    use SExpr::*;
    match expr {
        Atom(a) => Some(Atom(a.clone())),
        List(items) => {
            // Special-case rule structure: (rule (query ...) (body ...) ...)
            if let Some(Atom(h)) = items.first() {
                if h == "rule" {
                    if rule_relies_on_context(items) {
                        return None;
                    }
                    let mut out: Vec<SExpr> = Vec::with_capacity(items.len());
                    out.push(Atom("rule".to_string()));
                    // Query: recurse without replacement to normalize
                    let query_has_ctx = query_uses_context(&items[1]);
                    out.push(items[1].clone());
                    // Body handling depends on whether query references context
                    let body = &items[2];
                    let new_body = if query_has_ctx {
                        List(vec![List(vec![
                            Atom("panic".to_string()),
                            Atom("\"context should not be present\"".to_string()),
                        ])])
                    } else {
                        // Query doesn't use context: replace contexts in body with DUMMYCTX
                        replace_context_with_dummy(body)
                    };
                    out.push(new_body);
                    // Any trailing attrs or metadata
                    for extra in items.iter().skip(3) {
                        out.push(extra.clone());
                    }
                    return Some(List(out));
                }
            }

            Some(List(items.clone()))
        }
    }
}

fn print_sexpr(expr: &SExpr) -> String {
    match expr {
        SExpr::Atom(a) => a.clone(),
        SExpr::List(items) => {
            let inner = items.iter().map(print_sexpr).collect::<Vec<_>>().join(" ");
            format!("({inner})")
        }
    }
}

pub(crate) fn remove_new_contexts(s: &str) -> String {
    log::info!("removing context...");
    let tokens = tokenize(s);
    let parsed = parse(&tokens);
    let transformed: Vec<SExpr> = parsed.iter().filter_map(transform).collect();
    transformed
        .iter()
        .map(print_sexpr)
        .collect::<Vec<_>>()
        .join("\n")
}
