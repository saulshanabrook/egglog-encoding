#include "time_ilp.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <fstream>
#include <optional>
#include <random>
#include <thread>
#include <unordered_set>
#include <iostream>

#include "greedy.h"
#include "ilp.h"
#include "main.h"
#include "regionalize.h"
#include "tiger.h"


using Clock = chrono::steady_clock;

static long long measure_tiger_duration(const EGraph &gr, EClassId root,
                    const vector<vector<Cost>> &rstatewalk_cost,
                    bool use_liveness,
                    bool use_satellite_opt) {
  auto tiger_start = Clock::now();
  extract_regionalized_egraph_tiger(gr, root, rstatewalk_cost, use_liveness,
                  use_satellite_opt);
  auto tiger_end = Clock::now();
  return chrono::duration_cast<chrono::nanoseconds>(tiger_end - tiger_start)
    .count();
}


void compute_tiger_metrics(ExtractRegionTiming &sample, const EGraph &gr,
                           EClassId root,
                           const vector<vector<Cost>> &rstatewalk_cost) {
  sample.tiger_duration_liveon_satelliteon_ns =
    measure_tiger_duration(gr, root, rstatewalk_cost, true, true);
  sample.tiger_duration_liveon_satelliteoff_ns =
    measure_tiger_duration(gr, root, rstatewalk_cost, true, false);
  sample.tiger_duration_liveoff_satelliteon_ns =
    measure_tiger_duration(gr, root, rstatewalk_cost, false, true);
  sample.tiger_duration_liveoff_satelliteoff_ns =
    measure_tiger_duration(gr, root, rstatewalk_cost, false, false);

  StatewalkWidthReports res =
    get_stat_regionalized_egraph_tiger(gr, root, rstatewalk_cost);
  sample.statewalk_width_liveon_satelliteon_max =
    res.liveon_satelliteon.max_width;
  sample.statewalk_width_liveon_satelliteon_avg =
    res.liveon_satelliteon.avg_width;
  sample.statewalk_width_liveon_satelliteoff_max =
    res.liveon_satelliteoff.max_width;
  sample.statewalk_width_liveon_satelliteoff_avg =
    res.liveon_satelliteoff.avg_width;
  sample.statewalk_width_liveoff_satelliteon_max =
    res.liveoff_satelliteon.max_width;
  sample.statewalk_width_liveoff_satelliteon_avg =
    res.liveoff_satelliteon.avg_width;
  sample.statewalk_width_liveoff_satelliteoff_max =
    res.liveoff_satelliteoff.max_width;
  sample.statewalk_width_liveoff_satelliteoff_avg =
    res.liveoff_satelliteoff.avg_width;
}

namespace {
struct SolverMetrics {
  std::optional<long long> duration_ns;
  bool timed_out;
  bool infeasible;
  size_t encoding_vars;
};

SolverMetrics run_solver_for_metrics(const EGraph &gr, EClassId root,
                                     const vector<vector<Cost>> &rstatewalk_cost,
                                     bool use_gurobi) {
  Extraction extraction;
  bool timed_out = false;
  bool infeasible = false;
  size_t encoding_vars = 0;
  long long ns = extract_region_ilp_with_timing(gr, root, rstatewalk_cost,
                                                extraction, timed_out,
                                                infeasible, encoding_vars,
                                                use_gurobi);
  std::optional<long long> duration;
  if (!timed_out) {
    duration = ns;
  }
  return SolverMetrics{duration, timed_out, infeasible, encoding_vars};
}
}

void compute_ilp_metrics(ExtractRegionTiming &sample, const EGraph &gr,
                         EClassId root,
                         const vector<vector<Cost>> &rstatewalk_cost) {
    sample.ilp_ran = g_config.time_ilp_run_gurobi;
    if (sample.ilp_ran) {
      SolverMetrics gurobi_metrics =
        run_solver_for_metrics(gr, root, rstatewalk_cost, true);
      sample.ilp_timed_out = gurobi_metrics.timed_out;
      sample.ilp_infeasible = gurobi_metrics.infeasible;
      sample.ilp_encoding_num_vars = gurobi_metrics.encoding_vars;
      sample.ilp_duration_ns = gurobi_metrics.duration_ns;
    } else {
      // Gurobi was skipped (e.g. gurobi_cl not installed): leave the ilp_* fields
      // empty. The encoding size is solver-independent, so take it from CBC below.
      sample.ilp_timed_out = false;
      sample.ilp_infeasible = false;
      sample.ilp_duration_ns = std::nullopt;
    }

    SolverMetrics cbc_metrics = run_solver_for_metrics(gr, root, rstatewalk_cost, false);
    sample.cbc_ilp_duration_ns = cbc_metrics.duration_ns;
    sample.cbc_ilp_timed_out = cbc_metrics.timed_out;
    sample.cbc_ilp_infeasible = cbc_metrics.infeasible;
    if (!sample.ilp_ran) {
      sample.ilp_encoding_num_vars = cbc_metrics.encoding_vars;
    }
}

vector<ExtractRegionTiming>
compute_extract_region_timings(const EGraph &g,
                               const vector<EClassId> &fun_roots) {
  vector<EClassId> region_roots = find_all_region_roots(g, fun_roots);

  if (region_roots.empty()) {
    return {};
  }

  // Select a random subset of regions based on percent_regions BEFORE preparing them
  // Calculate the number of regions to run on (rounded up)
  size_t num_regions_to_run = static_cast<size_t>(
    std::ceil(region_roots.size() * g_config.percent_regions / 100.0));
  if (num_regions_to_run == 0) {
    num_regions_to_run = 1; // Always run at least one region if there are any
  }

  // Create indices and shuffle them to get random selection
  vector<size_t> region_indices(region_roots.size());
  for (size_t i = 0; i < region_roots.size(); ++i) {
    region_indices[i] = i;
  }
  
  // Only shuffle and subset if we're not running all regions
  if (num_regions_to_run < region_roots.size()) {
    std::random_device rd;
    std::mt19937 rng(rd());
    std::shuffle(region_indices.begin(), region_indices.end(), rng);
    region_indices.resize(num_regions_to_run);
  }

  vector<vector<Cost>> statewalk_cost = compute_statewalk_cost(g);

  // timings only contains entries for the regions we are actually measuring
  vector<ExtractRegionTiming> timings(region_indices.size());

  struct PreparedRegion {
    EGraph egraph;
    EClassId root;
    size_t timings_index; // index into the timings vector
    vector<vector<Cost>> statewalk_cost;
  };

  vector<PreparedRegion> prepared_regions;
  prepared_regions.reserve(region_indices.size());

  for (size_t timings_idx = 0; timings_idx < region_indices.size(); ++timings_idx) {
    size_t region_idx = region_indices[timings_idx];
    auto regionalized = construct_regionalized_egraph(g, region_roots[region_idx]);
    PreparedRegion prepared{};
    prepared.egraph = std::move(regionalized.first);
    prepared.root = regionalized.second.first;
    prepared.timings_index = timings_idx;

    const EGraphMapping &gr2g = regionalized.second.second;
    prepared.statewalk_cost = project_statewalk_cost(gr2g, statewalk_cost);

    ExtractRegionTiming sample{};

    // compute egraph size: number of nodes in the regionalized egraph
    size_t egraph_size = 0;
    for (const auto &eclass : prepared.egraph.eclasses) {
      egraph_size += eclass.enodes.size();
    }

    sample.egraph_size = egraph_size;
    compute_tiger_metrics(sample, prepared.egraph, prepared.root,
                          prepared.statewalk_cost);
    timings[timings_idx] = sample;

    prepared_regions.push_back(std::move(prepared));
  }

  unsigned int hardware_threads = std::thread::hardware_concurrency();
  unsigned int usable_threads = hardware_threads == 0 ? 1 : hardware_threads;

  // divide by 11, we spin up 10 benchmarks at once in profile.py
  if (usable_threads >= 20) {
    usable_threads /= 11;
  }

  
  size_t worker_count = min<size_t>(usable_threads, prepared_regions.size());
  if (worker_count == 0) {
    worker_count = 1;
  }

  std::atomic<size_t> next_index{0};

  cerr << "Running ILP timing on " << region_indices.size() << "/" << region_roots.size() << " regions, one dot per region:";
  auto worker = [&]() {
    while (true) {
      size_t work_idx = next_index.fetch_add(1, std::memory_order_relaxed);
      if (work_idx >= prepared_regions.size()) {
        break;
      }
      cerr << ".";
      cerr.flush();
      const PreparedRegion &prepared = prepared_regions[work_idx];
      ExtractRegionTiming &sample = timings[prepared.timings_index];
      compute_ilp_metrics(sample, prepared.egraph, prepared.root,
          prepared.statewalk_cost);
    }
  };
  cerr << "\n";

  vector<std::thread> threads;
  threads.reserve(worker_count);
  for (size_t i = 0; i < worker_count; ++i) {
    threads.emplace_back(worker);
  }
  for (auto &thread : threads) {
    thread.join();
  }

  return timings;
}

bool write_extract_region_timings_json(
    const vector<ExtractRegionTiming> &timings, const string &path) {
  ofstream out(path.c_str());
  if (!out.good()) {
    return false;
  }

  out << "{\n  \"rows\": [";
  if (!timings.empty()) {
    for (size_t i = 0; i < timings.size(); ++i) {
      const auto &sample = timings[i];
      out << (i == 0 ? "\n" : ",\n");
    out << "    {\"egraph_size\": " << sample.egraph_size
      << ", \"tiger_duration_liveon_satelliteon_ns\": "
      << sample.tiger_duration_liveon_satelliteon_ns
      << ", \"tiger_duration_liveon_satelliteoff_ns\": "
      << sample.tiger_duration_liveon_satelliteoff_ns
      << ", \"tiger_duration_liveoff_satelliteon_ns\": "
      << sample.tiger_duration_liveoff_satelliteon_ns
      << ", \"tiger_duration_liveoff_satelliteoff_ns\": "
      << sample.tiger_duration_liveoff_satelliteoff_ns
          << ", \"ilp_ran\": "
          << (sample.ilp_ran ? "true" : "false")
          << ", \"ilp_duration_ns\": ";
      if (sample.ilp_duration_ns.has_value()) {
        out << sample.ilp_duration_ns.value();
      } else {
        out << "null";
      }
      out << ", \"ilp_timed_out\": "
          << (sample.ilp_timed_out ? "true" : "false")
          << ", \"ilp_infeasible\": "
          << (sample.ilp_infeasible ? "true" : "false")
          << ", \"cbc_ilp_duration_ns\": ";
      if (sample.cbc_ilp_duration_ns.has_value()) {
        out << sample.cbc_ilp_duration_ns.value();
      } else {
        out << "null";
      }
      out << ", \"cbc_ilp_timed_out\": "
          << (sample.cbc_ilp_timed_out ? "true" : "false")
          << ", \"cbc_ilp_infeasible\": "
          << (sample.cbc_ilp_infeasible ? "true" : "false")
      << ", \"ilp_encoding_num_vars\": "
      << sample.ilp_encoding_num_vars
          << ", \"statewalk_width_liveon_satelliteon_max\": "
          << sample.statewalk_width_liveon_satelliteon_max
          << ", \"statewalk_width_liveon_satelliteon_avg\": "
          << sample.statewalk_width_liveon_satelliteon_avg
          << ", \"statewalk_width_liveon_satelliteoff_max\": "
          << sample.statewalk_width_liveon_satelliteoff_max
          << ", \"statewalk_width_liveon_satelliteoff_avg\": "
          << sample.statewalk_width_liveon_satelliteoff_avg
          << ", \"statewalk_width_liveoff_satelliteon_max\": "
          << sample.statewalk_width_liveoff_satelliteon_max
          << ", \"statewalk_width_liveoff_satelliteon_avg\": "
          << sample.statewalk_width_liveoff_satelliteon_avg
          << ", \"statewalk_width_liveoff_satelliteoff_max\": "
          << sample.statewalk_width_liveoff_satelliteoff_max
          << ", \"statewalk_width_liveoff_satelliteoff_avg\": "
          << sample.statewalk_width_liveoff_satelliteoff_avg << "}";
    }
    out << "\n  ";
  }
  out << "]\n}\n";
  return true;
}
