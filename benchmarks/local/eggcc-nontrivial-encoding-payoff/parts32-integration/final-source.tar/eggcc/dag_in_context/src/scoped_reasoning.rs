//! A private, exact-scope Parts32 experiment. Only a checked final Eq=false
//! leaves the sidecar; no word or branch equality enters the compiler graph.
use crate::schema::{Assumption, BaseType, BinaryOp, Constant, Expr, RcExpr, TreeProgram, Type};
use egglog::{new_experimental_egraph_with_options, DisequalityEncoding, Error};
use serde_json::json;
use std::{
    collections::BTreeSet,
    path::Path,
    sync::atomic::{AtomicUsize, Ordering},
};
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum Word {
    Slot(usize),
    Constant(i64),
    Low(Box<Word>, i64),
    Difference(Box<Word>, Box<Word>),
    High(Box<Word>, i64, i64),
}
#[derive(Clone, Debug, PartialEq, Eq)]
enum Transport {
    Slot(usize),
    Unknown,
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum Shape {
    Scalar(Transport),
    Tuple(Vec<Transport>),
}

struct Invariant {
    scope: Assumption,
    index: usize,
    value: i64,
}

/// Expand exact tuple projections and If input bindings. A slot survives an If
/// only when BOTH branches forward that same lexical input slot. Arithmetic is
/// deliberately unknown: even `slot + 0` is outside this structural proof.
fn transport(expr: &RcExpr, scope: &Assumption, input: &[Transport]) -> Option<Shape> {
    match expr.as_ref() {
        Expr::Arg(Type::TupleT(fields), ctx) if ctx == scope && fields.len() == input.len() => {
            Some(Shape::Tuple(input.to_vec()))
        }
        Expr::Get(tuple, index) => {
            let Shape::Tuple(values) = transport(tuple, scope, input)? else {
                return None;
            };
            Some(Shape::Scalar(values.get(*index)?.clone()))
        }
        Expr::Single(value) => {
            let Shape::Scalar(value) = transport(value, scope, input)? else {
                return None;
            };
            Some(Shape::Tuple(vec![value]))
        }
        Expr::Concat(left, right) => {
            let Shape::Tuple(mut values) = transport(left, scope, input)? else {
                return None;
            };
            let Shape::Tuple(right) = transport(right, scope, input)? else {
                return None;
            };
            values.extend(right);
            Some(Shape::Tuple(values))
        }
        Expr::Empty(_, ctx) if ctx == scope => Some(Shape::Tuple(Vec::new())),
        Expr::Const(_, _, ctx) if ctx == scope => Some(Shape::Scalar(Transport::Unknown)),
        Expr::Bop(..) | Expr::Uop(..) | Expr::Top(..) => Some(Shape::Scalar(Transport::Unknown)),
        Expr::If(pred, branch_input, yes, no) => {
            if pred.get_ctx() != scope || branch_input.get_ctx() != scope {
                return None;
            }
            let Shape::Tuple(values) = transport(branch_input, scope, input)? else {
                return None;
            };
            let yes_ctx = Assumption::InIf(true, pred.clone(), branch_input.clone());
            let no_ctx = Assumption::InIf(false, pred.clone(), branch_input.clone());
            match (
                transport(yes, &yes_ctx, &values)?,
                transport(no, &no_ctx, &values)?,
            ) {
                (Shape::Tuple(a), Shape::Tuple(b)) if a.len() == b.len() => Some(Shape::Tuple(
                    a.into_iter()
                        .zip(b)
                        .map(|(x, y)| if x == y { x } else { Transport::Unknown })
                        .collect(),
                )),
                (Shape::Scalar(a), Shape::Scalar(b)) => {
                    Some(Shape::Scalar(if a == b { a } else { Transport::Unknown }))
                }
                _ => None,
            }
        }
        _ => None,
    }
}

/// Induction admitted only for a literal initial projection and unchanged
/// same-index body output. DoWhile body output 0 is its predicate, so slot i is
/// carried by body output i+1. Other-index forwarding and updates are rejected.
fn loop_invariants(program: &TreeProgram) -> Vec<Invariant> {
    let mut stack = vec![program.entry.clone()];
    stack.extend(program.functions.clone());
    let mut seen = BTreeSet::new();
    let mut result = Vec::new();
    while let Some(expr) = stack.pop() {
        if !seen.insert(std::rc::Rc::as_ptr(&expr)) {
            continue;
        }
        stack.extend(expr.children_exprs());
        let Expr::DoWhile(initial, body) = expr.as_ref() else {
            continue;
        };
        let Type::TupleT(fields) = body.get_arg_type() else {
            continue;
        };
        let scope = body.get_ctx();
        let slots = (0..fields.len()).map(Transport::Slot).collect::<Vec<_>>();
        let Some(Shape::Tuple(outputs)) = transport(body, scope, &slots) else {
            continue;
        };
        if outputs.len() != fields.len() + 1 {
            continue;
        }
        for (index, ty) in fields.iter().enumerate() {
            if ty != &BaseType::IntT || outputs[index + 1] != Transport::Slot(index) {
                continue;
            }
            let Some(value) = project(initial, index) else {
                continue;
            };
            let literal = match value.as_ref() {
                Expr::Const(Constant::Int(value), _, ctx) if ctx == initial.get_ctx() => {
                    Some(*value)
                }
                Expr::Get(arg, i) => match arg.as_ref() {
                    Expr::Arg(Type::TupleT(fields), ctx)
                        if ctx == initial.get_ctx() && fields.get(*i) == Some(&BaseType::IntT) =>
                    {
                        constant_slot(ctx, *i, &[])
                    }
                    _ => None,
                },
                _ => None,
            };
            let Some(value) = literal else { continue };
            result.push(Invariant {
                scope: scope.clone(),
                index,
                value,
            });
        }
    }
    result
}

/// Transport a proved loop constant through exact enclosing If inputs.
fn constant_slot(scope: &Assumption, index: usize, invariants: &[Invariant]) -> Option<i64> {
    if let Some(value) = invariants
        .iter()
        .find(|x| x.scope == *scope && x.index == index)
    {
        return Some(value.value);
    }
    let Assumption::InIf(_, _, input) = scope else {
        return None;
    };
    let value = project(input, index)?;
    match value.as_ref() {
        Expr::Const(Constant::Int(k), _, ctx) if ctx == input.get_ctx() => Some(*k),
        Expr::Get(arg, i) => {
            let Expr::Arg(Type::TupleT(fields), ctx) = arg.as_ref() else {
                return None;
            };
            if fields.get(*i) != Some(&BaseType::IntT) || ctx != input.get_ctx() {
                return None;
            }
            constant_slot(ctx, *i, invariants)
        }
        _ => None,
    }
}

fn tuple_length(expr: &RcExpr) -> Option<usize> {
    match expr.as_ref() {
        Expr::Single(_) => Some(1),
        Expr::Concat(a, b) => Some(tuple_length(a)? + tuple_length(b)?),
        Expr::Empty(_, _) => Some(0),
        Expr::Arg(Type::TupleT(fields), _) => Some(fields.len()),
        _ => None,
    }
}

/// Exact structural projection through the branch's declared input tuple.
/// Unsupported expressions remain unknown; they are never treated as fresh values.
fn project(expr: &RcExpr, index: usize) -> Option<RcExpr> {
    match expr.as_ref() {
        Expr::Single(value) if index == 0 => Some(value.clone()),
        Expr::Concat(left, right) => {
            let length = tuple_length(left)?;
            if index < length {
                project(left, index)
            } else {
                project(right, index - length)
            }
        }
        Expr::Arg(Type::TupleT(fields), _) if index < fields.len() => {
            Some(RcExpr::new(Expr::Get(expr.clone(), index)))
        }
        _ => None,
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Mode {
    Off,
    SeedOnly,
    PrimitiveOnly,
    ForwardOff,
    ReverseOff,
    IdentityOff,
    Rescue,
    QueryOff,
    Manual,
    Encoding,
    BridgeOff,
    ConsumerOff,
    IfConsumerOff,
}
impl Mode {
    fn from_env() -> Self {
        match std::env::var("EGGCC_SCOPED_MODE")
            .as_deref()
            .unwrap_or("off")
        {
            "off" => Self::Off,
            "seed-only" => Self::SeedOnly,
            "primitive-only" => Self::PrimitiveOnly,
            "forward-off" => Self::ForwardOff,
            "reverse-off" => Self::ReverseOff,
            "identity-off" => Self::IdentityOff,
            "high-rescue" => Self::Rescue,
            "query-off" => Self::QueryOff,
            "manual" => Self::Manual,
            "encoding" => Self::Encoding,
            "bridge-off" => Self::BridgeOff,
            "consumer-off" => Self::ConsumerOff,
            "if-consumer-off" => Self::IfConsumerOff,
            other => panic!("Unknown EGGCC_SCOPED_MODE: {other}"),
        }
    }
}
/// Follow exact nested If input bindings back to one lexical root. No tuple
/// position is equated across contexts without its actual branch input.
fn translate(
    expr: &RcExpr,
    scope: &Assumption,
    expected: &Assumption,
    invariants: &[Invariant],
) -> Option<Word> {
    if expr.get_ctx() != expected {
        return None;
    }
    match expr.as_ref() {
        Expr::Const(Constant::Int(v), _, _) => Some(Word::Constant(*v)),
        Expr::Arg(Type::Base(BaseType::IntT), ctx) if ctx == scope => Some(Word::Slot(0)),
        Expr::Get(arg, i) => {
            let Expr::Arg(Type::TupleT(fields), ctx) = arg.as_ref() else {
                return None;
            };
            if fields.get(*i) != Some(&BaseType::IntT) {
                return None;
            }
            if ctx == scope {
                Some(
                    constant_slot(ctx, *i, invariants)
                        .map(Word::Constant)
                        .unwrap_or(Word::Slot(*i)),
                )
            } else if let Assumption::InIf(_, _, input) = ctx {
                translate(&project(input, *i)?, scope, input.get_ctx(), invariants)
            } else {
                None
            }
        }
        Expr::Bop(BinaryOp::Bitand, a, b) => {
            let (a, b) = (
                translate(a, scope, expected, invariants)?,
                translate(b, scope, expected, invariants)?,
            );
            match (a, b) {
                (Word::Constant(k), x) | (x, Word::Constant(k)) => Some(Word::Low(Box::new(x), k)),
                _ => None,
            }
        }
        Expr::Bop(BinaryOp::Sub, a, b) => Some(Word::Difference(
            Box::new(translate(a, scope, expected, invariants)?),
            Box::new(translate(b, scope, expected, invariants)?),
        )),
        Expr::Bop(BinaryOp::Div, a, b) => {
            let Word::Constant(d) = translate(b, scope, expected, invariants)? else {
                return None;
            };
            let Word::Difference(x, low) = translate(a, scope, expected, invariants)? else {
                return None;
            };
            let Word::Low(y, m) = *low else { return None };
            if x == y {
                Some(Word::High(x, m, d))
            } else {
                None
            }
        }
        _ => None,
    }
}
/// A finite generic closure, using the same committed rows, equality seeds,
/// representation unions and marked constructor as the encoding graph.
fn manual(
    marked: bool,
    reverse: bool,
    identity: bool,
    seeded: bool,
    rescue: bool,
) -> ([bool; 4], bool) {
    // outputs 0..9: x,y,lx,ly,hx,hy,Parts(x),Parts(y),Pair(lx,hx),Pair(ly,hy)
    type ApplicationRow = (&'static str, Vec<usize>, Vec<i64>, usize, bool);
    let rows: Vec<ApplicationRow> = vec![
        ("Low", vec![0], vec![4294967295], 2, false),
        ("Low", vec![1], vec![4294967295], 3, false),
        ("High", vec![0], vec![4294967295, 4294967296], 4, false),
        ("High", vec![1], vec![4294967295, 4294967296], 5, false),
        ("Parts32", vec![0], vec![], 6, marked),
        ("Parts32", vec![1], vec![], 7, marked),
        ("Pair", vec![2, 4], vec![], 8, false),
        ("Pair", vec![3, 5], vec![], 9, false),
    ];
    let mut equality = (0..10).collect::<Vec<_>>();
    if identity {
        for (a, b) in [(6, 8), (7, 9)] {
            let old = equality[b];
            let new = equality[a];
            for x in &mut equality {
                if *x == old {
                    *x = new
                }
            }
        }
    }
    if seeded {
        equality[3] = equality[2]
    }
    let mut neq = BTreeSet::new();
    if seeded {
        neq.insert((0, 1));
    }
    if rescue {
        neq.insert((4, 5));
    }
    loop {
        let before = (equality.clone(), neq.clone());
        for (an, ac, ap, ao, am) in &rows {
            for (bn, bc, bp, bo, _) in &rows {
                if an != bn || ap != bp {
                    continue;
                }
                let equal = ac.iter().zip(bc).all(|(a, b)| equality[*a] == equality[*b]);
                if equal {
                    let old = equality[*bo];
                    let new = equality[*ao];
                    for x in &mut equality {
                        if *x == old {
                            *x = new
                        }
                    }
                }
                if *am && equality[*ao] == equality[*bo] {
                    for (a, b) in ac.iter().zip(bc) {
                        let old = equality[*b];
                        let new = equality[*a];
                        for x in &mut equality {
                            if *x == old {
                                *x = new
                            }
                        }
                    }
                }
            }
        }
        neq = neq
            .into_iter()
            .map(|(a, b)| {
                let (a, b) = (equality[a], equality[b]);
                if a <= b {
                    (a, b)
                } else {
                    (b, a)
                }
            })
            .collect();
        for (an, ac, ap, ao, am) in &rows {
            for (bn, bc, bp, bo, _) in &rows {
                if an != bn || ap != bp {
                    continue;
                }
                let (a, b) = (equality[*ao], equality[*bo]);
                let output = if a <= b { (a, b) } else { (b, a) };
                for (i, (a, b)) in ac.iter().zip(bc).enumerate() {
                    let (a, b) = (equality[*a], equality[*b]);
                    let child = if a <= b { (a, b) } else { (b, a) };
                    if *am && neq.contains(&child) {
                        neq.insert(output);
                    }
                    if reverse
                        && neq.contains(&output)
                        && ac
                            .iter()
                            .zip(bc)
                            .enumerate()
                            .all(|(j, (a, b))| i == j || equality[*a] == equality[*b])
                    {
                        neq.insert(child);
                    }
                }
            }
        }
        if before == (equality.clone(), neq.clone()) {
            break;
        }
    }
    let known = [(0, 1), (6, 7), (8, 9), (4, 5)].map(|(a, b)| {
        let (a, b) = (equality[a], equality[b]);
        neq.contains(&(a.min(b), a.max(b)))
    });
    (known, neq.iter().any(|(a, b)| a == b))
}
fn query(
    graph: &mut egglog::EGraph,
    name: &str,
    a: &str,
    b: &str,
    reverse: bool,
) -> Result<bool, Error> {
    graph.parse_and_run_program(None,&format!("(relation {name} ())\n(ruleset {name}-query)\n(rule (({} {a} {b})) (({name})) :ruleset {name}-query :naive)\n(run-schedule (run {name}-query))",if reverse{"known-disequal?"}else{"known-disequal-forward-only?"}))?;
    Ok(graph.get_size(name) > 0)
}
fn prove(mode: Mode) -> Result<(bool, serde_json::Value), Error> {
    let marked = !matches!(mode, Mode::ForwardOff | Mode::Rescue);
    let reverse = !matches!(mode, Mode::ReverseOff | Mode::Rescue);
    let identity = mode != Mode::IdentityOff;
    let seeded = true;
    let rescue = mode == Mode::Rescue;
    let mut program=format!("(datatype Scope (ThisScope))\n(datatype Word)\n(datatype Parts)\n(constructor X (Scope) Word)\n(constructor Y (Scope) Word)\n(constructor Low (Word i64) Word)\n(constructor High (Word i64 i64) Word)\n(constructor Parts32 (Word) Parts {})\n(constructor Pair (Word Word) Parts)\n(let x (X (ThisScope)))\n(let y (Y (ThisScope)))\n(let lx (Low x 4294967295))\n(let ly (Low y 4294967295))\n(let hx (High x 4294967295 4294967296))\n(let hy (High y 4294967295 4294967296))\n(let px (Parts32 x))\n(let py (Parts32 y))\n(let pairx (Pair lx hx))\n(let pairy (Pair ly hy))\n",if marked{":injective"}else{""});
    if identity {
        program.push_str("(union px pairx)\n(union py pairy)\n")
    }
    if seeded {
        program.push_str("(disequal x y)\n(union lx ly)\n")
    }
    if rescue {
        program.push_str("(disequal hx hy)\n")
    }
    if !matches!(mode, Mode::SeedOnly | Mode::PrimitiveOnly) {
        program.push_str("(run-schedule (saturate injectivity))\n");
    }
    let mut graph = new_experimental_egraph_with_options(false, DisequalityEncoding::Nee);
    graph.parse_and_run_program(None, &program)?;
    let bottom = if matches!(mode, Mode::SeedOnly | Mode::PrimitiveOnly) {
        false
    } else {
        match graph.parse_and_run_program(None, "(check-contradiction)") {
            Ok(_) => true,
            Err(Error::CheckError(..)) => false,
            Err(e) => return Err(e),
        }
    };
    let manual_result = if matches!(mode, Mode::SeedOnly | Mode::PrimitiveOnly) {
        ([false; 4], false)
    } else {
        manual(marked, reverse, identity, seeded, rescue)
    };
    let mut known = [false; 4];
    if !bottom {
        if mode == Mode::SeedOnly {
            // Deliberately stop after identical graph population and seeds.
        } else if mode == Mode::PrimitiveOnly {
            // Keep the same committed graph and dynamic seeds. A primitive-only
            // conflict detector has no primitive fields on marked Parts32;
            // Low/High metadata belongs to unmarked constructors. Diagnostics
            // retain the asserted word seed, but no equality-sort inference runs.
            known[0] = seeded;
        } else if mode == Mode::Manual {
            known = manual_result.0
        } else {
            for (i, (name, a, b)) in [
                ("WordKnown", "x", "y"),
                ("PartsKnown", "px", "py"),
                ("PairKnown", "pairx", "pairy"),
                ("HighKnown", "hx", "hy"),
            ]
            .into_iter()
            .enumerate()
            {
                if i == 3 && mode == Mode::QueryOff {
                    continue;
                }
                known[i] = query(&mut graph, name, a, b, reverse)?;
            }
        }
    }
    let export = !bottom && known[3] && mode != Mode::BridgeOff;
    Ok((
        export,
        json!({"mode":format!("{mode:?}"),"encoding":"NEE","program":program,"primitive_metadata":{"mask":4294967295_i64,"divisor":4294967296_i64},"word_known":known[0],"parts_known":known[1],"pair_known":known[2],"high_known":if matches!(mode,Mode::QueryOff|Mode::SeedOnly|Mode::PrimitiveOnly){None}else{Some(known[3])},"low_equal":seeded,"bottom":if matches!(mode,Mode::SeedOnly|Mode::PrimitiveOnly){None}else{Some(bottom)},"bottom_checked":!matches!(mode,Mode::SeedOnly|Mode::PrimitiveOnly),"manual_receipts":if matches!(mode,Mode::SeedOnly|Mode::PrimitiveOnly){None}else{Some(manual_result.0)},"manual_bottom":manual_result.1,"export":export,"consumer_enabled":mode!=Mode::ConsumerOff,"reverse_enabled":reverse,"parts32_marked":marked,"representation_identity":identity,"rescue":rescue,"equality_sort_disequality_queries_enabled":!matches!(mode,Mode::PrimitiveOnly|Mode::SeedOnly),"injectivity_saturated":!matches!(mode,Mode::SeedOnly|Mode::PrimitiveOnly),"word_seeded":seeded,"engine_witness_queries_run":!matches!(mode,Mode::SeedOnly|Mode::PrimitiveOnly|Mode::Manual),"manual_closure_run":!matches!(mode,Mode::SeedOnly|Mode::PrimitiveOnly),"primitive_only_marked_fields":[],"primitive_only_witness":false}),
    ))
}
/// Only a target nested under true low equality and false original word Eq can
/// be admitted. Both predicates and all projections are checked in exact scopes.
pub(crate) fn analyze(program: &TreeProgram) -> Vec<RcExpr> {
    let mode = Mode::from_env();
    if mode == Mode::Off {
        return Vec::new();
    }
    static BOUNDARY: AtomicUsize = AtomicUsize::new(0);
    let boundary = BOUNDARY.fetch_add(1, Ordering::Relaxed);
    let types = program.typecheck();
    let invariants = loop_invariants(program);
    let mut stack = vec![program.entry.clone()];
    stack.extend(program.functions.clone());
    let (mut seen, mut exports, mut receipts) = (BTreeSet::new(), Vec::new(), Vec::new());
    while let Some(expr) = stack.pop() {
        if !seen.insert(std::rc::Rc::as_ptr(&expr)) {
            continue;
        }
        stack.extend(expr.children_exprs());
        let Expr::If(target, _, _, _) = expr.as_ref() else {
            continue;
        };
        let Expr::Bop(BinaryOp::Eq, a, b) = target.as_ref() else {
            continue;
        };
        if types.get(&std::rc::Rc::as_ptr(target)) != Some(&Type::Base(BaseType::BoolT)) {
            continue;
        }
        let target_scope = target.get_ctx();
        let Assumption::InIf(true, low_pred, low_input) = target_scope else {
            continue;
        };
        let Expr::Bop(BinaryOp::Eq, la, lb) = low_pred.as_ref() else {
            continue;
        };
        let word_scope = low_pred.get_ctx();
        let Assumption::InIf(false, word_pred, word_input) = word_scope else {
            continue;
        };
        let Expr::Bop(BinaryOp::Eq, wa, wb) = word_pred.as_ref() else {
            continue;
        };
        let root = word_pred.get_ctx();
        let Some(x) = translate(wa, root, root, &invariants) else {
            continue;
        };
        let Some(y) = translate(wb, root, root, &invariants) else {
            continue;
        };
        if x == y || matches!(x, Word::Constant(_)) || matches!(y, Word::Constant(_)) {
            continue;
        }
        let lows = (
            translate(la, root, word_scope, &invariants),
            translate(lb, root, word_scope, &invariants),
        );
        let highs = (
            translate(a, root, target_scope, &invariants),
            translate(b, root, target_scope, &invariants),
        );
        let expected_lows = (
            Some(Word::Low(Box::new(x.clone()), 4294967295)),
            Some(Word::Low(Box::new(y.clone()), 4294967295)),
        );
        let expected_highs = (
            Some(Word::High(Box::new(x.clone()), 4294967295, 4294967296)),
            Some(Word::High(Box::new(y.clone()), 4294967295, 4294967296)),
        );
        let accepted = (lows == expected_lows
            || lows == (expected_lows.1.clone(), expected_lows.0.clone()))
            && (highs == expected_highs
                || highs == (expected_highs.1.clone(), expected_highs.0.clone()));
        if !accepted {
            receipts.push(json!({"accepted":false,"reason":"exact partition, operands or parameter mismatch","lows":format!("{lows:?}"),"highs":format!("{highs:?}"),"source_low":low_pred.to_string(),"source_target":target.to_string(),"loop_invariants":invariants.iter().map(|x|json!({"slot":x.index,"value":x.value})).collect::<Vec<_>>()}));
            continue;
        }
        let (export, mut receipt) = match prove(mode) {
            Ok(v) => v,
            Err(e) => (
                false,
                json!({"analysis_error":format!("{e:?}"),"export":false}),
            ),
        };
        receipt["accepted"] = json!(true);
        receipt["source_target"] = json!(target.to_string());
        receipt["source_word_predicate"] = json!(word_pred.to_string());
        receipt["source_low_predicate"] = json!(low_pred.to_string());
        receipt["root_scope"] = json!(root.to_string());
        receipt["word_scope"] = json!(word_scope.to_string());
        receipt["target_scope"] = json!(target_scope.to_string());
        receipt["word_input"] = json!(word_input.to_string());
        receipt["low_input"] = json!(low_input.to_string());
        receipt["translated_words"] = json!(format!("{x:?},{y:?}"));
        receipt["loop_invariants"]=json!(invariants.iter().map(|x|json!({"scope":x.scope.to_string(),"input_slot":x.index,"body_output_slot":x.index+1,"literal_initial_value":x.value,"proof":"literal initialization through exact enclosing If inputs; unchanged both-branch same-index passthrough"})).collect::<Vec<_>>());
        receipts.push(receipt);
        if export {
            exports.push(target.clone())
        }
    }
    if let Ok(dir) = std::env::var("EGGCC_SCOPED_EVIDENCE") {
        std::fs::create_dir_all(&dir).unwrap();
        let path = Path::new(&dir).join(format!("boundary-{boundary:04}.json"));
        assert!(!path.exists());
        std::fs::write(path,serde_json::to_vec_pretty(&json!({"boundary":boundary,"mode":format!("{mode:?}"),"queries":receipts,"exports":exports.len()})).unwrap()).unwrap();
    }
    exports
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn parts32_generic_chain_causal_controls() {
        for mode in [
            Mode::Encoding,
            Mode::SeedOnly,
            Mode::Manual,
            Mode::ForwardOff,
            Mode::ReverseOff,
            Mode::IdentityOff,
            Mode::Rescue,
            Mode::QueryOff,
            Mode::PrimitiveOnly,
            Mode::BridgeOff,
            Mode::ConsumerOff,
        ] {
            let (export, r) = prove(mode).unwrap();
            assert_eq!(
                export,
                matches!(
                    mode,
                    Mode::Encoding | Mode::Manual | Mode::Rescue | Mode::ConsumerOff
                ),
                "{r}"
            );
            if mode == Mode::SeedOnly {
                assert!(!r["program"].as_str().unwrap().contains("run-schedule"));
                assert_eq!(r["bottom_checked"], false);
                assert_eq!(r["manual_receipts"], serde_json::Value::Null);
                assert_eq!(r["low_equal"], true);
            }
            if mode == Mode::PrimitiveOnly {
                assert_eq!(r["word_seeded"], true);
                assert_eq!(r["low_equal"], true);
                assert_eq!(r["manual_closure_run"], false);
                assert_eq!(r["engine_witness_queries_run"], false);
                assert_eq!(r["primitive_only_marked_fields"], json!([]));
            }
            if mode == Mode::ForwardOff {
                assert_eq!(r["parts_known"], false)
            }
            if mode == Mode::ReverseOff {
                assert_eq!(r["parts_known"], true);
                assert_eq!(r["high_known"], false)
            }
            if mode == Mode::Encoding {
                assert_eq!(r["manual_receipts"], json!([true, true, true, true]));
                assert_eq!(r["bottom"], false)
            }
        }
    }
    #[test]
    fn parts32_manual_closure_respects_missing_edges() {
        assert_eq!(manual(true, true, true, true, false).0, [true; 4]);
        assert_eq!(
            manual(false, true, true, true, false).0,
            [true, false, false, false]
        );
        assert_eq!(
            manual(true, false, true, true, false).0,
            [true, true, true, false]
        );
        assert_eq!(
            manual(true, true, false, true, false).0,
            [true, true, false, false]
        );
        assert_eq!(manual(true, true, true, false, false).0, [false; 4]);
    }
    #[test]
    fn loop_constant_requires_literal_and_same_index_passthrough() {
        use crate::ast::*;
        use crate::{parallel, tuplet};
        let cases = [
            (
                parallel!(int(7), int(8)),
                parallel!(tfalse(), getat(0), getat(1)),
                Some(7),
            ),
            (
                parallel!(int(9), int(8)),
                parallel!(tfalse(), getat(0), getat(1)),
                Some(9),
            ),
            (
                parallel!(arg(), int(8)),
                parallel!(tfalse(), getat(0), getat(1)),
                None,
            ),
            (
                parallel!(int(7), int(8)),
                parallel!(tfalse(), add(getat(0), int(1)), getat(1)),
                None,
            ),
            (
                parallel!(int(7), int(8)),
                parallel!(tfalse(), getat(1), getat(1)),
                None,
            ),
        ];
        for (input, body, expected) in cases {
            let function = function(
                "main",
                base(intt()),
                tuplet!(intt(), intt()),
                dowhile(input, body),
            )
            .func_with_arg_types()
            .func_add_ctx()
            .0;
            let program = function.func_to_program();
            let found = loop_invariants(&program);
            assert_eq!(
                found.iter().find(|x| x.index == 0).map(|x| x.value),
                expected
            );
            assert_eq!(
                found.iter().find(|x| x.index == 1).map(|x| x.value),
                Some(8)
            );
        }
    }

    #[test]
    fn branch_input_transport_is_typed_and_context_exact() {
        use crate::ast::*;
        use crate::{parallel, tuplet};
        let parent_scope = Assumption::InFunc("parent".to_owned());
        let input = parallel!(int(7), int(8))
            .with_arg_types(base(intt()), tuplet!(intt(), intt()))
            .add_ctx(parent_scope.clone())
            .0;
        let predicate = eq(int(0), int(1))
            .with_arg_types(base(intt()), base(boolt()))
            .add_ctx(parent_scope.clone())
            .0;
        let child_scope = Assumption::InIf(false, predicate.clone(), input.clone());
        let value = RcExpr::new(Expr::Get(
            RcExpr::new(Expr::Arg(tuplet!(intt(), intt()), child_scope.clone())),
            0,
        ));
        assert_eq!(
            translate(&value, &parent_scope, &child_scope, &[]),
            Some(Word::Constant(7))
        );
        let sibling = Assumption::InIf(true, predicate, input.clone());
        assert_eq!(translate(&value, &parent_scope, &sibling, &[]), None);
        let invalid = RcExpr::new(Expr::Get(
            RcExpr::new(Expr::Arg(tuplet!(boolt(), intt()), child_scope.clone())),
            0,
        ));
        assert_eq!(translate(&invalid, &parent_scope, &child_scope, &[]), None);
    }

    #[test]
    fn parts32_ee_matches_nee_on_consistent_causal_graphs() {
        for mode in [
            Mode::Encoding,
            Mode::ForwardOff,
            Mode::ReverseOff,
            Mode::IdentityOff,
            Mode::Rescue,
        ] {
            let (_, receipt) = prove(mode).unwrap();
            let mut graph = new_experimental_egraph_with_options(false, DisequalityEncoding::Ee);
            // EE's inherited support rules use global x/y names. Alpha-rename
            // this diagnostic's bindings to avoid that independent collision.
            let mut ee_program = receipt["program"].as_str().unwrap().to_owned();
            for name in [
                "x", "y", "lx", "ly", "hx", "hy", "px", "py", "pairx", "pairy",
            ] {
                ee_program = ee_program.replace(&format!(" {name}"), &format!(" p32-{name}"));
            }
            graph.parse_and_run_program(None, &ee_program).unwrap();
            assert!(matches!(
                graph.parse_and_run_program(None, "(check-contradiction)"),
                Err(Error::CheckError(..))
            ));
            for (name, a, b, field) in [
                ("EEWord", "x", "y", "word_known"),
                ("EEParts", "px", "py", "parts_known"),
                ("EEPair", "pairx", "pairy", "pair_known"),
                ("EEHigh", "hx", "hy", "high_known"),
            ] {
                assert_eq!(
                    query(
                        &mut graph,
                        name,
                        &format!("p32-{a}"),
                        &format!("p32-{b}"),
                        !matches!(mode, Mode::ReverseOff | Mode::Rescue)
                    )
                    .unwrap(),
                    receipt[field].as_bool().unwrap(),
                    "{receipt}"
                );
            }
        }
    }
}
